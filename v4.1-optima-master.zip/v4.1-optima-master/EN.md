## NEOXR-BOT V4.1 (PREMIUM)

Documentation and tutorials in English, read and understand, if there are problems or something you don't understand, contact the creator.

Follow this channel for update notifications. [Update Notification](https://whatsapp.com/channel/0029Vb5ekjf4dTnMuADBHX1j)

### Requirements

- [x] NodeJS >= 20 (Recommended v20.81.1)
- [x] FFMPEG
- [x] Server supports Canvas installation
- [x] Server supports Sharp installation
- [x] Server vCPU/RAM 1/2GB (Min)

### Server

- [x] NAT VPS [Hostdata](https://hostdata.id/nat-vps-usa/)
- [x] Hosting Panel [Voxy Host](https://voxyhost.com/)
- [x] VPS [OVH Hosting](https://www.ovhcloud.com/asia/vps/)
- [x] RDP Windows [RDP Win](https://www.rdpwin.com/rdpbot.php)

### Cloud Database

- [x] PostgreSQL [Supabase](https://supabase.com/pricing) ~ [Setup Tutorial](https://youtu.be/kdyF7cP9E7k?si=YjlxI5OMHBdkSxkw)
- [x] PostgreSQL [Aiven](https://aiven.io) ~ Remove ```?sslmode=required```
- [x] MongoDB [MongoDB](https://www.mongodb.com) ~ [Setup Tutorial](https://youtu.be/-9lfyWz0SdE?si=nmyA6qeBYKbO4R45) (Recommended)

> [!NOTE]  
> If the number of bot users is quite large, use a local database (SQLite) and enable auto-backup. Cloud databases have limitations when fetching data (due to being free) and may cause the bot to experience delays.

### External Session

**External Session** is a feature that functions to save bot sessions into an external database, there are 5 providers that can be used, please read at [https://github.com/neoxr/session](https://github.com/neoxr/session).

Example :

Below is an example when you want to use 2 providers, namely Mongo and Postgres, which will automatically adapt to the `DATABASE_URL` environment

```Javascript
const session = process?.env?.DATABASE_URL ? /mongo/.test(process.env.DATABASE_URL)
   ? require('@neoxr/session/mongo').useMongoAuthState
   : /postgres/.test(process.env.DATABASE_URL)
      ? require('@neoxr/session/postgres').usePostgresAuthState
      : null
   : null
```

What if you want to save resources by only using 1 provider? For example, if you only want to use Mongo, add this module to the `dependencies` in the `package.json` file :

```JSON
{
   "dependencies": {
      "@neoxr/session/mongo": "github:neoxr/session#mongo"
   }
}
```
And the code just needs to be simplified to :

```Javascript
const session = process?.env?.DATABASE_URL ? /mongo/.test(process.env.DATABASE_URL)
   ? require('@neoxr/session/mongo').useMongoAuthState
   : null
```

### Database

**Database** is a feature that functions to store bot data in an external or local database, there are 6 providers that can be used, please read at [https://github.com/neoxr/database](https://github.com/neoxr/databases).

Example :

```Javascript
const database = await (process?.env?.DATABASE_URL ? /mongo/.test(process.env.DATABASE_URL)
   ? require('@neoxr/database/mongo').createDatabase(process.env.DATABASE_URL, env.database, 'database')
   : /postgres/.test(process.env.DATABASE_URL)
      ? require('@neoxr/database/postgres').createDatabase(process.env.DATABASE_URL, env.database)
      : require('@neoxr/database/local').createDatabase(process.env.DATABASE_URL, env.database)
   : require('@neoxr/database/local').createDatabase(env.database))
```

What if you want to save resources by only using 2 providers? For example, if you only want to use Mongo and local, add this module to the `dependencies` in the `package.json` file:

```JSON
{
   "dependencies": {
      "@neoxr/database/local": "github:neoxr/database#local",
      "@neoxr/database/mongo": "github:neoxr/database#mongo"
   }
}
```
And the code just needs to be simplified to :

```Javascript
const database = await (process?.env?.DATABASE_URL ? /mongo/.test(process.env.DATABASE_URL)
   ? require('@neoxr/database/mongo').createDatabase(process.env.DATABASE_URL, env.database, 'database')
   : require('@neoxr/database/local').createDatabase(env.database))
```

### Configuration

There are 3 configurations that need to be set first before running the bot, namely in the `config.json`, `.env` and `config.js` files (optional).

<details>
  <summary>File : config.json</summary>

 What must be set are `owner`, `owner_name` and `pairing.number`, the rest can be left at default.

  ```JSON
  {
   "owner": "6285887776722",
   "owner_name": "Wildan Izzudin",
   "database": "data",
   "limit": 10,
   "limit_game": 50,
   "multiplier": 89,
   "min_reward": 100000,
   "max_reward": 500000,
   "ram_limit": "1.5gb",
   "max_upload": 80,
   "max_upload_free": 25,
   "cooldown": 3,
   "timer": 180000,
   "timeout": 1800000,
   "permanent_threshold": 3,
   "notify_threshold": 4,
   "banned_threshold": 5,
   "blocks": ["994", "221", "263"],
   "evaluate_chars":  ["=>", "~>", "<", ">", "$"],
   "pairing": {
      "state": true,
      "number": 62857035017443,
      "version": [2, 3000, 1017531287]
   },
   "bot_hosting": {
      "slot": 5,
      "session_dir": "sessions",
      "delay": 1500,
      "interval": 3000,
      "host": "127.0.0.1"
   }
}
  ```
</details>

<details>
  <summary>File : .env</summary>

Fill in according to the website listed above, for ```DATABASE_URL``` if left blank the database and bot session will be saved locally in a json file.
  
  ```.env
# Email (Optional)
USER_EMAIL_PROVIDER = 'zoho'
USER_NAME = ''
USER_EMAIL = ''
USER_APP_PASSWORD = ''

# Neoxr API : https://api.neoxr.my.id
API_ENDPOINT = 'https://api.neoxr.my.id/api'
API_KEY = 'your_apikey'

# Database : Mongo / PostgreSql (Optional)
# Leave it empty to use SQLite by default.
DATABASE_URL = ''

# Google API : https://aistudio.google.com
GOOGLE_API = ''

# Prompt System (Choose: "en" or "id")
PROMPT_LANG = 'en'

# Timezone (Important)
TZ = 'Asia/Jakarta'

# Anti Porn : https://api.sightengine.com (Optional)
API_USER = ''
API_SECRET = ''

### Annotations (Optional)
NEWSLETTER_ID = '120363399865638619@newsletter'
### PostID : https://whatsapp.com/channel/0029Vb5ekjf4dTnMuADBHX1j/376 ~> 376
NEWSLETTER_POSTID = 376
NEWSLETTER_NAME = 'NEOXR MUSIC'

### Port (Optional)
PORT = 3000
  ```
</details>

<details>
  <summary>File : config.js</summary>
  Optionally, please just open the file freely to edit without any particular rules ^_^
</details>

> [!NOTE]  
> The term "optional" means it is not required to be filled in.

### Installation & Verification

Ensure the server meets the requirements mentioned above, then run the following command :

```bash
$ yarn install
```

or

```bash
$ npm i
```

After successful installation, verify the server to generate a license by running :

```bash
$ node .
```

After that, enter the registered passcode and stop with `CTRL+C`. This process is only done once unless you move or change the server.

### Running

If running the bot on a VPS, use `pm2` :

```bash
$ npm i -g pm2
```

Use the following command for regular mode (without WhatsApp Gateway) :

```bash
$ pm2 start pm2.config.js --only bot && pm2 logs bot
```

or use advanced mode (with WhatsApp Gateway) :

```bash
$ pm2 start pm2.config.js --only gateway && pm2 logs gateway
```

Check the other commands yourself on the pm2 page [https://www.npmjs.com/package/pm2](https://www.npmjs.com/package/pm2)

### What is WhatsApp Gateway ?

**WhatsApp Gateway** is an intermediary (interface) that allows other systems or applications to automatically send and receive WhatsApp messages through an API (Application Programming Interface). This is very useful for purposes such as:

- Transaction notifications (e.g., payment receipts)
- Schedule reminders
- OTP (One-Time Password)
- etc.

### Web Interface (Dashboard)

You can choose whether or not to install the Web Interface, depending on if you want to manage the database via the web.

<p align="center"><img align="center" width="100%" src="https://qu.ax/SQJDq.png" /></p>

> [!CAUTION]
> Required! to have a domain and run the bot on a VPS.

To configure the dashboard, change the domain in the `./nuxt/nuxt.config.ts` file and in the `.env` file, along with `JWT_SECRET` (for security).

After that, go to the server where the bot script is located, then navigate to the nuxt folder, for example :

```Bash
$ cd v4.1-optima/nuxt
```

Then generate the static files for the dashboard :

```Bash
$ yarn && yarn run generate
```

Done. The last step is to set up a web server like Apache/Nginx. 

A tutorial is not provided because the setup method varies for each server due to many factors such as specifications, OS, OS version, firewall, etc.

So, please use AI for technical assistance regarding setting up a web server using Apache/Nginx and adapt it to your server specifications.

> [!INFO]
> You can try running `$ bash setup.sh <domain> <port>`, that it may only work on certain servers.

Once everything has been done, run the bot using pm2 like this :

```Bash
$ pm2 start pm2.config.js --only gateway
```

### Command Plugin

**Command Plugin** is a plugin that will run using commands.

```Javascript
exports.run = {
   usage: ['ytmp4', 'ytmp3'],
   hidden: ['ytv', 'yta'],
   use: 'link',
   category: 'downloader',
   async: async (m, {
      client,
      args,
      text,
      isPrefix,
      command,
      env,
      Scraper,
      Func
   }) => {
      try {
         // do something
      } catch (e) {
         console.log(e)
         client.reply(m.chat, Func.jsonFormat(e), m)
      }
   },
   error: Boolean,
   limit: Number,
   premium: Boolean,
   restrict: Boolean,
   private: Boolean,
   group: Boolean,
   admin: Boolean,
   botAdmin: Boolean,
   operator: Boolean,
   owner: Boolean,
   moderator: Boolean
}
```

### Event Plugin

**Event Plugin** is a plugin that runs without commands.

```Javascript
exports.run = {
   async: async (m, {
      client,
      body,
      prefixes
   }) => {
      try {
         // do something
      } catch (e) {
         return client.reply(m.chat, Func.jsonFormat(e), m)
      }
   },
   error: Boolean,
   premium: Boolean,
   private: Boolean,
   group: Boolean,
   admin: Boolean,
   botAdmin: Boolean,
   operator: Boolean,
   owner: Boolean,
   moderator: Boolean
}
```

### Disclaimer & TNC

Selling/sharing this script to other people is prohibited. If this is done, the consequences will be **free updates will be deleted** and **apikey will be banned**.

Not accepting feature requests, but if you have suggestions for features to add or errors, please create an issue, thank you.