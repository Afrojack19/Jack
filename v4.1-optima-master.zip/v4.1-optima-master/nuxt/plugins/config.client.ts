class Config {
   adjustLayout() {
      const html = document.documentElement
      if (window.innerWidth <= 1200) {
         html.setAttribute('data-sidebar-size', 'full')
      }
   }

   initWindowSize() {
      window.addEventListener('resize', () => this.adjustLayout())
   }

   init() {
      this.adjustLayout()
      this.initWindowSize()
   }
}

export default defineNuxtPlugin(() => {
   const config = new Config()
   config.init()
})