import NProgress from 'nprogress'
import 'nprogress/nprogress.css'

export default defineNuxtPlugin(nuxtApp => {
   nuxtApp.hook('page:finish', () => {
      NProgress.start()
   })

   nuxtApp.hook('page:finish', () => {
      NProgress.done()
   })

   NProgress.configure({
      showSpinner: false
   })
})