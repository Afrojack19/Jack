<template>
   <div class="d-flex align-items-center justify-content-center vh-100">
      <div class="text-center">
         <h1 class="display-1 fw-bold">{{ error.statusCode }}</h1>
         <p class="fs-3">
            <span class="text-danger">Opps!</span> {{ error.statusMessage || 'Page not found' }}.
         </p>
         <p class="lead">
            Sorry, the page you’re looking for doesn’t exist.
         </p>
         <button class="btn btn-primary" @click="handleClearError">Go Home</button>
      </div>
   </div>
</template>

<script setup lang="ts">
const props = defineProps({
   error: Object as () => ({
      url: string
      statusCode: number
      statusMessage: string
      message: string
      description: string
      data: any
   })
})

useHead({
   title: `${props.error.statusCode} - ${props.error.statusMessage || 'Error'}`
})

definePageMeta({
   layout: 'flex'
})

const handleClearError = () => {
   window.location.href = '/'
}
</script>

<style scoped>
.vh-100 {
   min-height: 100vh;
}
</style>