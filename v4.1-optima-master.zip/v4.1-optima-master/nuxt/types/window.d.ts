declare global {
   interface Window {
      config: LayoutConfig
      defaultConfig: LayoutConfig
   }

   interface LayoutConfig {
      theme: string
      topbar: {
         color: string
      }
      menu: {
         size: string
         color: string
      }
   }
}

export { }