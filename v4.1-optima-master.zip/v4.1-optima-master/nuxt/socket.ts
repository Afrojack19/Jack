// socket-server.ts
import { createServer } from 'http'
import { Server } from 'socket.io'
import os from 'os'

const httpServer = createServer()

const io = new Server(httpServer, {
   cors: {
      origin: '*'
   }
})

io.on('connection', (socket) => {
   console.log('🔌 Client connected:', socket.id)

   const interval = setInterval(() => {
      const cpus = os.cpus()
      let idle = 0
      let total = 0

      for (const cpu of cpus) {
         for (const type in cpu.times) {
            total += cpu.times[type as keyof typeof cpu.times]
         }
         idle += cpu.times.idle
      }

      const idleAvg = idle / cpus.length
      const totalAvg = total / cpus.length
      const usage = 100 - Math.floor((idleAvg / totalAvg) * 100)

      socket.emit('cpu', usage)
   }, 2000)

   socket.on('disconnect', () => {
      clearInterval(interval)
      console.log('❌ Client disconnected:', socket.id)
   })
})

httpServer.listen(4000, () => {
   console.log('✅ Socket.IO server running at http://localhost:4000')
})
