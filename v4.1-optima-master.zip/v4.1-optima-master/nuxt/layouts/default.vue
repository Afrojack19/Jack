<template>
   <div>
      <Preloader />

      <div v-if="isHomePage">
         <NuxtPage />
      </div>

      <div v-else class="wrapper">
         <Topbar />
         <Sidenav />
         <div class="page-content">
            <div class="container-fluid">
               <NuxtPage />
            </div>
            <Footer />
         </div>
      </div>
   </div>
</template>

<script setup lang="ts">
import { computed } from 'vue'
import { useRoute } from '#imports'

const route = useRoute()

const isHomePage = computed(() => route.name === 'index')
</script>