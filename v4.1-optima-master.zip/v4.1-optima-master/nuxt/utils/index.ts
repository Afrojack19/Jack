import { H3Event, send } from 'h3'
import { parsePhoneNumber } from 'libphonenumber-js'

export const formatPhoneAuto = (raw: string): { phone: string, flag: string } => {
   try {
      const phone = parsePhoneNumber('+' + raw)
      if (phone && phone.isValid()) {
         return { phone: phone.formatInternational(), flag: getFlag(phone.country || '') }
      }
   } catch (e) {
      return { phone: '', flag: '' }
   }
   return { phone: '', flag: '' }
}

export const formatSize = (bytes: number, decimals = 2): string => {
   if (bytes === 0) return '0 Bytes'

   const k = 1024
   const dm = decimals < 0 ? 0 : decimals
   const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB']

   const i = Math.floor(Math.log(bytes) / Math.log(k))
   const size = parseFloat((bytes / Math.pow(k, i)).toFixed(dm))

   return `${size} ${sizes[i]}`
}

export const getFlag = (countryCode: string): string => {
   if (!countryCode || countryCode.length !== 2) return ''
   const codePoints = countryCode
      .toUpperCase()
      .split('')
      .map(char => 0x1f1e6 + char.charCodeAt(0) - 'A'.charCodeAt(0))
   return String.fromCodePoint(...codePoints)
}

export const h2k = (num: number | bigint): string => {
   const units = ['K', 'M', 'B', 'T', 'P', 'E', 'Z', 'Y']
   let number = typeof num === 'bigint' ? Number(num) : num

   if (!Number.isFinite(number)) return num.toString()

   let unitIndex = -1
   while (number >= 1000 && unitIndex < units.length - 1) {
      number /= 1000
      unitIndex++
   }

   if (unitIndex === -1) return number.toString()

   return number.toFixed(1).replace(/\.0$/, '') + units[unitIndex]
}

export const formatter = (integer: number | bigint): string => {
   const safeInt = typeof integer === 'bigint' ? integer : BigInt(Math.trunc(integer))
   return safeInt.toLocaleString().replace(/,/g, '.')
}

export const delay = (ms: number): Promise<void> => {
   return new Promise((resolve) => setTimeout(resolve, ms))
}

export const toJid = (phone: string): string => {
   let cleaned = phone.replace(/[\s+]/g, '')
   return cleaned + '@s.whatsapp.net'
}