<template>
   <div class="container">
      <div class="row justify-content-center">
         <div class="col-xl-4 col-md-5">
            <div class="card">
               <div class="card-body p-4">

                  <div class="text-center w-75 mx-auto auth-logo mb-4">
                     <a class='logo-dark' @click.prevent="$router.push('/')">
                        <span><img src="/assets/images/logo-dark.png" alt="" height="22"></span>
                     </a>
                     <a class='logo-light' @click.prevent="$router.push('/')">
                        <span><img src="/assets/images/logo-light.png" alt="" height="22"></span>
                     </a>
                  </div>

                  <div class="d-grid gap-2 mb-3">
                     <div class="btn-group" role="group">
                        <input type="radio" class="btn-check" name="loginMethod" id="btnradio1" autocomplete="off"
                           :checked="loginMethod === 'password'" @change="loginMethod = 'password'">
                        <label class="btn btn-outline-primary" for="btnradio1">Password</label>

                        <input type="radio" class="btn-check" name="loginMethod" id="btnradio2" autocomplete="off"
                           :checked="loginMethod === 'token'" @change="loginMethod = 'token'">
                        <label class="btn btn-outline-primary" for="btnradio2">Token</label>
                     </div>
                  </div>

                  <div v-if="loginMethod === 'password'">
                     <form @submit.prevent="loginByPassword" ref="form">
                        <div class="form-group mb-3">
                           <label class="form-label" for="username">Username</label>
                           <input class="form-control" v-model="username" type="text" id="username"
                              placeholder="Enter your username">
                        </div>

                        <div class="form-group mb-3">
                           <label class="form-label" for="password">Password</label>
                           <input class="form-control" v-model="password" type="password" id="password"
                              placeholder="Enter your password">
                        </div>

                        <div class="form-group mb-3">
                           <div class="">
                              <input class="form-check-input" type="checkbox" id="checkbox-signin" v-model="rememberMe">
                              <label class="form-check-label ms-2" for="checkbox-signin">Remember me</label>
                           </div>
                        </div>

                        <div class="form-group mb-0 text-center">
                           <button class="btn btn-primary w-100" :disabled="loading">
                              <Spinner v-if="loading" />
                              {{ loading ? 'Processing...' : 'Log In' }}
                           </button>
                        </div>
                     </form>
                  </div>

                  <div v-if="loginMethod === 'token'">
                     <div class="alert alert-primary" role="alert">
                        Use this method to quickly access your client dashboard.
                     </div>
                     <form @submit.prevent="loginByToken" ref="form">
                        <div class="mb-3">
                           <label for="token" class="form-label">Token</label>
                           <input class="form-control" v-model="token" type="password" id="token"
                              placeholder="Enter your token">
                        </div>
                        <div class="form-group mb-0 text-center">
                           <button class="btn btn-primary w-100" :disabled="loading">
                              <Spinner v-if="loading" />
                              {{ loading ? 'Processing...' : 'Log In' }}
                           </button>
                        </div>
                     </form>
                  </div>

                  <div v-if="loginMethod === 'otp'">
                     <form @submit.prevent="loginByOtp" ref="form">
                        <div class="mb-3">
                           <label for="phone" class="form-label">WhatsApp Number</label>
                           <div class="input-group">
                              <input type="tel" class="form-control" id="phone" v-model="phone"
                                 placeholder="e.g. 62812xxxx" :disabled="otpSent || otpRequestLoading">
                              <button class="btn btn-outline-secondary" type="button" @click="requestOtp"
                                 :disabled="!phone || otpRequestLoading">
                                 <span v-if="otpRequestLoading" class="spinner-border spinner-border-sm"
                                    aria-hidden="true"></span>
                                 <span v-else>Send OTP</span>
                              </button>
                           </div>
                        </div>

                        <div class="mb-3">
                           <label for="otp" class="form-label">Code</label>
                           <input class="form-control" v-model="otp" type="text" id="otp"
                              placeholder="Enter the OTP code" :disabled="!otpSent">
                        </div>

                        <div class="form-group mb-0 text-center">
                           <button class="btn btn-primary w-100" :disabled="loading || !otpSent">
                              <Spinner v-if="loading" />
                              {{ loading ? 'Processing...' : 'Log In' }}
                           </button>
                        </div>
                     </form>
                  </div>
               </div>
            </div>

         </div>
      </div>
   </div>
</template>

<script setup lang="ts">
import { ref, onMounted } from 'vue'
import Swal from 'sweetalert2'
import { delay } from '@/utils'

definePageMeta({ layout: 'flex' })
useHead({ title: 'Login' })

const { setAuth } = useAuth()
const { $api } = useNuxtApp()

const rememberedUsername = useCookie<string | null>('remembered-username', { maxAge: 60 * 60 * 24 * 30 })

const loginMethod = ref<'password' | 'token' | 'otp'>('password')

const form = ref<HTMLFormElement | null>(null)
const loading = ref(false)

const username = ref('')
const password = ref('')
const rememberMe = ref(true)

const token = ref('')

const phone = ref('')
const otp = ref('')
const otpSent = ref(false)
const otpRequestLoading = ref(false)

onMounted(() => {
   if (rememberedUsername.value) {
      username.value = rememberedUsername.value
      rememberMe.value = true
   } else {
      rememberMe.value = false
   }
})

const navigateOnSuccess = async () => {
   Swal.fire({
      text: 'Login successful!',
      icon: 'success',
      showConfirmButton: false,
      timer: 1100,
      timerProgressBar: true
   })
   await nextTick()
   await delay(1200)
   window.location.href = '/dashboard'
}

const handleLoginError = (e: any) => {
   Swal.fire({
      text: e.data?.msg || e.data?.message || 'Something went wrong!',
      icon: 'error',
      showConfirmButton: false,
      timer: 2000
   })
}

const loginByPassword = async () => {
   if (!username.value || !password.value) {
      Swal.fire({ text: 'Username and Password are required.', icon: 'warning', timer: 1500 })
      return
   }
   loading.value = true
   try {
      const json = await $api('/action/login', {
         method: 'POST',
         body: {
            username: username.value,
            password: password.value,
            type: 1
         }
      })
      if (!json.status) throw { data: json }

      if (rememberMe.value) {
         rememberedUsername.value = username.value
      } else {
         rememberedUsername.value = null
      }

      setAuth({ token: json.data.token, type: json.data.type, avatar: json.data.avatar })
      await navigateOnSuccess()
   } catch (e: any) {
      handleLoginError(e)
   } finally {
      loading.value = false
   }
}

const loginByToken = async () => {
   if (!token.value) {
      Swal.fire({ text: 'Token is required.', icon: 'warning', timer: 1500 })
      return
   }
   loading.value = true
   try {
      const json = await $api('/action/login', {
         method: 'POST',
         body: {
            token: token.value,
            type: 2
         }
      })
      if (!json.status) throw { data: json }

      setAuth({ token: json.data.token, type: json.data.type, avatar: json.data.avatar })
      await navigateOnSuccess()
   } catch (e: any) {
      handleLoginError(e)
   } finally {
      loading.value = false
   }
}
</script>