<template>
   <div class="row">
      <div class="col-md-6 col-xl-6" v-for="(icon, index) in ['bx-dollar-circle', 'bx-group']" :key="index">
         <div class="card">
            <div class="card-body">
               <div class="row">
                  <div class="col-6">
                     <div :class="['avatar-md', 'rounded', ['bg-success', 'bg-primary'][index]]">
                        <i :class="['bx', icon, 'avatar-title', 'fs-24', 'text-white']"></i>
                     </div>
                  </div>
                  <div class="col-6 text-end">
                     <p class="text-muted mb-0 text-truncate">{{ ['Rental', 'Total'][index] }}</p>
                     <h3 class="text-dark mt-1 mb-0">
                        {{ [stats?.rental || 0, stats?.total || 0][index] }}
                     </h3>
                  </div>
               </div>
            </div>
         </div>
      </div>

      <div class="col-xl-12">
         <div class="card">
            <div class="card-body">
               <div class="py-3">

                  <div v-if="load" class="text-center py-5">
                     <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                     </div>
                     <p class="mt-2 text-muted">Fetching data...</p>
                  </div>

                  <div v-else-if="error" class="d-flex justify-content-center align-items-center"
                     style="min-height: 200px">
                     <p class="text-muted">No data available.</p>
                  </div>

                  <div v-else>
                     <div class="modal fade" ref="setupModalEl" tabindex="-1" data-bs-backdrop="static">
                        <div class="modal-dialog modal-dialog-centered">
                           <div class="modal-content">
                              <form @submit.prevent="submitSetup">
                                 <div class="modal-header">
                                    <h5 class="modal-title">Group Setup</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                 </div>
                                 <div class="modal-body">
                                    <div class="mb-3">
                                       <label class="form-label">Group JID</label>
                                       <input :value="setupForm.jid" class="form-control" readonly />
                                    </div>
                                    <div class="mb-3">
                                       <label class="form-label">Subject</label>
                                       <input :value="setupForm.name" class="form-control" readonly />
                                    </div>
                                    <div class="row">
                                       <div class="col-6" v-for="setting in booleanSettings" :key="setting.key">
                                          <div class="form-check form-switch mb-3">
                                             <input class="form-check-input" type="checkbox"
                                                :id="`switch-${setting.key}`" v-model="setupForm[setting.key]">
                                             <label class="form-check-label" :for="`switch-${setting.key}`">{{
                                                setting.label }}</label>
                                          </div>
                                       </div>
                                    </div>
                                    <hr>
                                    <div class="row">
                                       <div class="col-md-6">
                                          <div class="mb-3">
                                             <label for="text_welcome" class="form-label">Welcome Text</label>
                                             <textarea class="form-control" id="text_welcome" rows="3"
                                                v-model="setupForm.text_welcome"></textarea>
                                          </div>
                                       </div>
                                       <div class="col-md-6">
                                          <div class="mb-3">
                                             <label for="text_left" class="form-label">Left Text</label>
                                             <textarea class="form-control" id="text_left" rows="3"
                                                v-model="setupForm.text_left"></textarea>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"
                                       :disabled="isSubmitting">Close</button>
                                    <button class="btn btn-primary" type="submit" :disabled="isSubmitting">
                                       <span v-if="isSubmitting" class="spinner-border spinner-border-sm" role="status"
                                          aria-hidden="true"></span>
                                       <span v-else>Save Changes</span>
                                    </button>
                                 </div>
                              </form>
                           </div>
                        </div>
                     </div>

                     <div class="modal fade" ref="sendMessageModalEl" tabindex="-1" data-bs-backdrop="static">
                        <div class="modal-dialog modal-dialog-centered">
                           <div class="modal-content">
                              <form @submit.prevent="submitSendMessage">
                                 <div class="modal-header">
                                    <h5 class="modal-title">Send Group Message</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                 </div>
                                 <div class="modal-body">
                                    <div class="mb-3">
                                       <label class="form-label">Group Name</label>
                                       <input :value="sendMessageForm.name" class="form-control" readonly />
                                    </div>

                                    <ul class="nav nav-pills nav-justified mb-3" role="tablist">
                                       <li class="nav-item" v-for="tab in messageTabs" :key="tab.id">
                                          <a :class="['nav-link', { active: sendMessageForm.type === tab.id }]"
                                             data-bs-toggle="tab" :href="`#${tab.id}`" role="tab"
                                             @click="sendMessageForm.type = tab.id">
                                             {{ tab.name }}
                                          </a>
                                       </li>
                                    </ul>

                                    <div class="tab-content">
                                       <div class="tab-pane" :class="{ active: sendMessageForm.type === 'text' }"
                                          id="text" role="tabpanel">
                                          <div class="mb-3">
                                             <label for="messageText" class="form-label">Message</label>
                                             <textarea v-model="sendMessageForm.text.message" class="form-control"
                                                id="messageText" rows="5"></textarea>
                                          </div>
                                       </div>
                                       <div class="tab-pane" :class="{ active: sendMessageForm.type === 'media' }"
                                          id="media" role="tabpanel">
                                          <div class="mb-3">
                                             <label for="mediaFile" class="form-label">Media File</label>
                                             <input type="file" ref="mediaFileEl"
                                                @change="handleFileChange($event, 'media')" class="form-control"
                                                id="mediaFile" accept=".jpg,.png,.mp3,.mp4">
                                          </div>
                                          <div class="mb-3">
                                             <label for="mediaCaption" class="form-label">Caption</label>
                                             <textarea v-model="sendMessageForm.media.caption"
                                                class="form-control" id="mediaCaption" rows="3"></textarea>
                                          </div>
                                       </div>
                                       <div class="tab-pane" :class="{ active: sendMessageForm.type === 'file' }"
                                          id="file" role="tabpanel">
                                          <div class="mb-3">
                                             <label for="docFile" class="form-label">Document File</label>
                                             <input type="file" ref="docFileEl"
                                                @change="handleFileChange($event, 'file')" class="form-control"
                                                id="docFile">
                                          </div>
                                          <div class="mb-3">
                                             <label for="fileCaption" class="form-label">Caption</label>
                                             <textarea v-model="sendMessageForm.file.caption" class="form-control"
                                                id="fileCaption" rows="3"></textarea>
                                          </div>
                                       </div>
                                       <div class="tab-pane" :class="{ active: sendMessageForm.type === 'voice' }"
                                          id="voice" role="tabpanel">
                                          <div class="mb-3">
                                             <label for="voiceFile" class="form-label">Voicenote</label>
                                             <input type="file" ref="voiceFileEl"
                                                @change="handleFileChange($event, 'voice')" class="form-control"
                                                id="voiceFile" accept="audio/*">
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="modal-footer d-flex justify-content-between">
                                    <div class="form-check form-switch">
                                       <input class="form-check-input" type="checkbox" id="hidetagSwitch"
                                          v-model="sendMessageForm.hidetag">
                                       <label class="form-check-label" for="hidetagSwitch">Hidetag</label>
                                    </div>
                                    <div>
                                       <button type="button" class="btn btn-secondary me-2" data-bs-dismiss="modal"
                                          :disabled="isSendingMessage">Close</button>
                                       <button class="btn btn-primary" type="submit" :disabled="isSendingMessage">
                                          <span v-if="isSendingMessage" class="spinner-border spinner-border-sm"
                                             role="status" aria-hidden="true"></span>
                                          <span v-else>Submit</span>
                                       </button>
                                    </div>
                                 </div>
                              </form>
                           </div>
                        </div>
                     </div>

                     <div class="d-flex justify-content-end align-items-center mb-3 gap-2 flex-wrap">
                        <select v-model="rentalFilter" class="form-select form-select-sm w-auto">
                           <option value="">All Rentals</option>
                           <option :value="true">Yes</option>
                           <option :value="false">No</option>
                        </select>
                        <div id="grid-search-wrapper"></div>
                     </div>

                     <div id="table-gridjs"></div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</template>

<script setup lang="ts">
import { ref, onMounted, nextTick, computed, watch } from 'vue'
import { useHead, useNuxtApp } from '#imports'
import Swal from 'sweetalert2'

useHead({ title: 'Groups Database' })

const stats = ref<{ rental: number, total: number } | null>(null)
const allGroups = ref<any[]>([])
const load = ref(true)
const error = ref(false)
const errorMessage = ref('')
const isSubmitting = ref(false)
const isSendingMessage = ref(false)
const rentalFilter = ref<boolean | string>('')

const { $api } = useNuxtApp()
let grid: any = null

let setupModalInstance: any = null
const setupModalEl = ref<HTMLElement | null>(null)
let sendMessageModalInstance: any = null
const sendMessageModalEl = ref<HTMLElement | null>(null)

const mediaFileEl = ref<HTMLInputElement | null>(null)
const docFileEl = ref<HTMLInputElement | null>(null)
const voiceFileEl = ref<HTMLInputElement | null>(null)

const booleanSettings = [
   { key: 'adminonly', label: 'Admin Only' },
   { key: 'antidelete', label: 'Antidelete' },
   { key: 'antilink', label: 'Antilink' },
   { key: 'antiporn', label: 'Antiporn' },
   { key: 'antitagsw', label: 'Antitag SW' },
   { key: 'antivirtex', label: 'Antivirtex' },
   { key: 'autosticker', label: 'Autosticker' },
   { key: 'antibot', label: 'Antibot' },
   { key: 'captcha', label: 'Captcha' },
   { key: 'filter', label: 'Filter' },
   { key: 'game', label: 'Game' },
   { key: 'left', label: 'Left' },
   { key: 'localonly', label: 'Local Only' },
   { key: 'mute', label: 'Mute' },
   { key: 'mysterybox', label: 'Mystery Box' },
   { key: 'restrict', label: 'Restrict' },
   { key: 'stay', label: 'Stay' },
   { key: 'welcome', label: 'Welcome' }
]

const setupForm = ref<any>({
   jid: '',
   name: '',
   text_left: '',
   text_welcome: '',
   ...Object.fromEntries(booleanSettings.map(s => [s.key, false]))
})

const messageTabs = [
   { id: 'text', name: 'Text' },
   { id: 'media', name: 'Media' },
   { id: 'file', name: 'File' },
   { id: 'voice', name: 'Voice' }
]

const getInitialSendMessageForm = () => ({
   jid: '',
   name: '',
   type: 'text',
   hidetag: false,
   text: { message: '' },
   media: { file: null as File | null, caption: '' },
   file: { file: null as File | null, caption: '' },
   voice: { file: null as File | null }
})

const sendMessageForm = ref(getInitialSendMessageForm())

const formatTimestamp = (timestamp: number): string => {
   if (!timestamp || timestamp <= 0) return '-'
   return new Date(timestamp).toLocaleString('en-US', {
      year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true
   })
}

const filteredGroups = computed(() => {
   if (rentalFilter.value === '') return allGroups.value
   return allGroups.value.filter(group => group.is_rental === rentalFilter.value)
})

function initializeGrid() {
   const gridContainer = document.getElementById('table-gridjs')
   if (!gridContainer) return

   gridContainer.innerHTML = ''
   const gridjs = (window as any).gridjs
   grid = new gridjs.Grid({
      columns: [
         {
            id: 'jid',
            name: 'JID',
            formatter: (cell: string) => gridjs.h('div', { style: { width: '170px' } }, cell)
         },
         {
            id: 'name',
            name: 'Subject',
            formatter: (cell: string) => gridjs.h('div', { style: { width: '150px' } }, cell)
         },
         {
            id: 'mute', name: 'Mute', width: '100px',
            formatter: (cell: boolean) => gridjs.h('span', { className: `badge bg-${cell ? 'danger' : 'secondary'}` }, cell ? 'Yes' : 'No')
         },
         { id: 'members', name: 'Members', width: '100px' },
         {
            id: 'is_rental', name: 'Rental', width: '100px',
            formatter: (cell: boolean) => gridjs.h('span', { className: `badge bg-${cell ? 'success' : 'secondary'}` }, cell ? 'Yes' : 'No')
         },
         { id: 'expired', name: 'Expired', width: '200px', formatter: (cell: number) => formatTimestamp(cell) },
         { id: 'activity', name: 'Last Activity', width: '200px', formatter: (cell: number) => formatTimestamp(cell) },
         {
            name: 'Actions',
            width: '250px',
            sort: false,
            formatter: (_cell: any, row: any) => {
               const jid = row.cells[0].data as string
               return gridjs.h('div', { className: 'd-flex justify-content-center gap-2' }, [
                  gridjs.h('button', {
                     className: 'btn btn-sm btn-info text-white',
                     onClick: () => openSendMessageModal(jid)
                  }, 'Send'),
                  gridjs.h('button', {
                     className: 'btn btn-sm btn-primary',
                     onClick: () => openSetupModal(jid)
                  }, 'Setup'),
                  gridjs.h('button', {
                     className: 'btn btn-sm btn-danger',
                     onClick: () => handleDelete(jid)
                  }, 'Delete')
               ])
            }
         }
      ],
      pagination: { limit: 10, summary: true },
      sort: true,
      search: {
         container: '#grid-search-wrapper'
      },
      data: () => filteredGroups.value
   }).render(gridContainer)

   watch(rentalFilter, () => {
      grid?.forceRender()
   })
}

async function fetchData() {
   load.value = true
   error.value = false
   errorMessage.value = ''

   try {
      const response = await $api('/data/groups')
      if (!response || !response.status) {
         throw new Error(response?.message || 'Failed to fetch group data')
      }

      stats.value = response.data.stats
      allGroups.value = response.data.groups.map((v: any) => ({
         jid: v.jid,
         name: v.name,
         members: Object.keys(v.member || {}).length,
         is_rental: v.expired > 0,
         expired: v.expired,
         activity: v.activity,
         ...Object.fromEntries(booleanSettings.map(s => [s.key, v[s.key] || false])),
         text_left: v.text_left || '',
         text_welcome: v.text_welcome || ''
      }))

      load.value = false
      await nextTick()

      const Modal = (await import('bootstrap/js/dist/modal')).default

      if (!setupModalInstance && setupModalEl.value) {
         setupModalInstance = new Modal(setupModalEl.value)
      }
      if (!sendMessageModalInstance && sendMessageModalEl.value) {
         sendMessageModalInstance = new Modal(sendMessageModalEl.value)
      }

      if (!grid) {
         initializeGrid()
      } else {
         grid.forceRender()
      }

   } catch (e: any) {
      error.value = true
      errorMessage.value = e.data?.message || e.message || 'An unexpected error occurred'
      load.value = false
      Swal.fire({ text: errorMessage.value, icon: 'error', timer: 2000, showConfirmButton: false })
   }
}

function openSetupModal(jid: string) {
   const group = allGroups.value.find(g => g.jid === jid)
   if (!group) return

   for (const key in setupForm.value) {
      if (group.hasOwnProperty(key)) {
         setupForm.value[key] = group[key]
      }
   }
   setupModalInstance?.show()
}

function openSendMessageModal(jid: string) {
   const group = allGroups.value.find(g => g.jid === jid)
   if (!group) {
      Swal.fire({ text: 'Group not found', icon: 'error', timer: 1500, showConfirmButton: false })
      return
   }

   sendMessageForm.value = getInitialSendMessageForm()
   sendMessageForm.value.jid = group.jid
   sendMessageForm.value.name = group.name
   sendMessageModalInstance?.show()
}

const handleFileChange = (event: Event, type: 'media' | 'file' | 'voice') => {
   const target = event.target as HTMLInputElement
   if (target.files && target.files[0]) {
      sendMessageForm.value[type].file = target.files[0]
   }
}


async function submitSendMessage() {
   if (isSendingMessage.value) return
   isSendingMessage.value = true

   const form = sendMessageForm.value
   let validationError = ''

   switch (form.type) {
      case 'text':
         if (!form.text.message.trim()) {
            validationError = 'Message text cannot be empty'
         }
         break
      case 'media':
         if (!form.media.file) {
            validationError = 'Please select a media file to upload'
         }
         break
      case 'file':
         if (!form.file.file) {
            validationError = 'Please select a document file to upload'
         }
         break
      case 'voice':
         if (!form.voice.file) {
            validationError = 'Please select a audio file to upload'
         }
         break
   }

   if (validationError) {
      Swal.fire({
         text: validationError,
         icon: 'warning',
         timer: 2000,
         showConfirmButton: false
      })
      isSendingMessage.value = false
      return
   }

   try {
      const formData = new FormData()
      formData.append('jid', form.jid)
      formData.append('type', form.type)
      formData.append('hidetag', String(form.hidetag))

      switch (form.type) {
         case 'text':
            formData.append('message', form.text.message)
            break
         case 'media':
            if (form.media.file) formData.append('file', form.media.file)
            formData.append('caption', form.media.caption)
            break
         case 'file':
            if (form.file.file) formData.append('file', form.file.file)
            formData.append('caption', form.file.caption)
            break
         case 'voice':
            if (form.voice.file) formData.append('file', form.voice.file)
            break
      }

      const response = await $api('/action/group-message', {
         method: 'POST',
         body: formData
      })

      if (!response.status) {
         throw new Error(response.message || 'Failed to send message')
      }

      Swal.fire({
         text: 'Message sent successfully!',
         icon: 'success',
         timer: 1500,
         showConfirmButton: false
      })
      sendMessageModalInstance?.hide()

      sendMessageForm.value = getInitialSendMessageForm()
      if (mediaFileEl.value) mediaFileEl.value.value = ''
      if (docFileEl.value) docFileEl.value.value = ''
      if (voiceFileEl.value) voiceFileEl.value.value = ''

   } catch (e: any) {
      Swal.fire({
         text: e.message || 'An unexpected error occurred.',
         icon: 'error',
         timer: 2000,
         showConfirmButton: false
      })
   } finally {
      isSendingMessage.value = false
   }
}

async function submitSetup() {
   if (isSubmitting.value) return
   isSubmitting.value = true

   try {
      const payload = { ...setupForm.value }
      const response = await $api('/action/update-group', {
         method: 'POST',
         body: payload
      })

      if (!response.status) {
         Swal.fire({ text: response.message || 'Failed to update group settings', icon: 'error', timer: 1500, showConfirmButton: false })
         return
      }

      Swal.fire({
         text: 'Group settings updated successfully',
         icon: 'success'
      })

      const groupIndex = allGroups.value.findIndex(g => g.jid === payload.jid)
      if (groupIndex !== -1) {
         allGroups.value[groupIndex] = { ...allGroups.value[groupIndex], ...payload }
      }

      setupModalInstance?.hide()
      grid?.forceRender()

   } catch (e: any) {
      Swal.fire({ text: e.data?.message || 'An unexpected error occurred', icon: 'error', timer: 1500, showConfirmButton: false })
   } finally {
      isSubmitting.value = false
   }
}

async function handleDelete(jid: string) {
   const group = allGroups.value.find(g => g.jid === jid)
   if (!group) {
      Swal.fire({ text: 'Group not found', icon: 'error', timer: 1500, showConfirmButton: false })
      return
   }

   const result = await Swal.fire({
      title: 'Are you sure?',
      text: `You are about to delete the group: ${group.jid}. This cannot be undone!`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#d33',
      cancelButtonColor: '#3085d6',
      confirmButtonText: 'Yes, delete it!'
   })

   if (result.isConfirmed) {
      try {
         const response = await $api('/action/delete', {
            method: 'POST',
            body: { jid: jid, type: '_g' }
         })

         if (!response.status) {
            Swal.fire({ text: response.message || 'Failed to delete group', icon: 'error', timer: 1500, showConfirmButton: false })
            return
         }

         Swal.fire({ text: 'Group has been successfully deleted', icon: 'success' })

         allGroups.value = allGroups.value.filter(g => g.jid !== jid)
         grid?.forceRender()

      } catch (e: any) {
         Swal.fire({ text: e.data?.message || 'An unexpected error occurred', icon: 'error', timer: 1500, showConfirmButton: false })
      }
   }
}

onMounted(() => {
   fetchData()
})
</script>