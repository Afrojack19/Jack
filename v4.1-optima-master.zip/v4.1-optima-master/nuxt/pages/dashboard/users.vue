<template>
   <div class="row">
      <div class="col-md-4 col-xl-4" v-for="(icon, index) in ['spa', 'minus-circle', 'user']" :key="index">
         <div class="card">
            <div class="card-body">
               <div class="row">
                  <div class="col-6">
                     <div :class="['avatar-md', 'rounded', ['bg-success', 'bg-danger', 'bg-primary'][index]]">
                        <i :class="['bx', `bx-${icon}`, 'avatar-title', 'fs-24', 'text-white']"></i>
                     </div>
                  </div>
                  <div class="col-6 text-end">
                     <p class="text-muted mb-0 text-truncate">{{ ['Premium', 'Banned', 'Total'][index] }}</p>
                     <h3 class="text-dark mt-1 mb-0">
                        {{ [stats?.premium || 0, stats?.banned || 0, stats?.total || 0][index] }}
                     </h3>
                  </div>
               </div>
            </div>
         </div>
      </div>

      <div class="col-xl-12">
         <div class="card">
            <div class="card-body">
               <div class="py-3">

                  <div v-if="load" class="text-center py-5">
                     <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                     </div>
                     <p class="mt-2 text-muted">Fetching data...</p>
                  </div>

                  <div v-else-if="error" class="d-flex justify-content-center align-items-center"
                     style="min-height: 200px;">
                     <p class="text-muted">No data available.</p>
                  </div>

                  <div v-else>
                     <div class="modal fade" ref="editModalEl" tabindex="-1">
                        <div class="modal-dialog modal-dialog-centered">
                           <div class="modal-content">
                              <form @submit.prevent="submitEdit">
                                 <div class="modal-header">
                                    <h5 class="modal-title">Edit User</h5>
                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                 </div>
                                 <div class="modal-body">
                                    <div class="mb-3">
                                       <label class="form-label">Number</label>
                                       <input v-model="editForm.phone" class="form-control" readonly />
                                    </div>
                                    <div class="mb-3">
                                       <label class="form-label">Name</label>
                                       <input v-model="editForm.name" class="form-control" readonly />
                                    </div>

                                    <div class="row">
                                       <div class="col-6">
                                          <div class="mb-3">
                                             <label class="form-label">Limit</label>
                                             <input v-model.number="editForm.limit" type="number"
                                                class="form-control" />
                                          </div>
                                       </div>
                                       <div class="col-6">
                                          <div class="mb-3">
                                             <label class="form-label">Limit Game</label>
                                             <input v-model.number="editForm.limit_game" type="number"
                                                class="form-control" />
                                          </div>
                                       </div>
                                    </div>

                                    <div class="row">
                                       <div class="col-6">
                                          <div class="mb-3">
                                             <label class="form-label">Premium</label>
                                             <select v-model="editForm.premium" class="form-select">
                                                <option :value="true">Yes</option>
                                                <option :value="false">No</option>
                                             </select>
                                          </div>
                                       </div>
                                       <div class="col-6">
                                          <div class="mb-3">
                                             <label class="form-label">Banned</label>
                                             <select v-model="editForm.banned" class="form-select">
                                                <option :value="true">Yes</option>
                                                <option :value="false">No</option>
                                             </select>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                                 <div class="modal-footer">
                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal"
                                       :disabled="isSubmitting">Close</button>
                                    <button class="btn btn-primary" type="submit" :disabled="isSubmitting">
                                       <span v-if="isSubmitting" class="spinner-border spinner-border-sm" role="status"
                                          aria-hidden="true"></span>
                                       <span v-else>Save</span>
                                    </button>
                                 </div>
                              </form>
                           </div>
                        </div>
                     </div>

                     <div class="d-flex justify-content-end align-items-center mb-3 gap-2 flex-wrap">
                        <div id="grid-search-wrapper"></div>

                        <select v-model="premiumFilter" class="form-select form-select-sm w-auto">
                           <option value="">All Premium</option>
                           <option value="Yes">Yes</option>
                           <option value="No">No</option>
                        </select>
                        <select v-model="bannedFilter" class="form-select form-select-sm w-auto">
                           <option value="">All Banned</option>
                           <option value="Yes">Yes</option>
                           <option value="No">No</option>
                        </select>
                     </div>

                     <div id="table-gridjs"></div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</template>

<script setup lang="ts">
import { ref, onMounted, nextTick, computed, watch } from 'vue'
import { useHead, useNuxtApp } from '#imports'
import { formatPhoneAuto } from '@/utils'
import Swal from 'sweetalert2'

useHead({ title: 'Users Database' })

const stats = ref<{ premium: number, banned: number, total: number } | null>(null)
const allUsers = ref<any[]>([])
const load = ref(true)
const error = ref(false)
const errorMessage = ref('')

const editForm = ref({
   jid: '',
   phone: '',
   name: '',
   limit: 0,
   limit_game: 0,
   premium: false,
   banned: false
})

const premiumFilter = ref('')
const bannedFilter = ref('')
const isSubmitting = ref(false)

const editModalEl = ref<HTMLElement | null>(null)
let editModalInstance: any = null

const { $api } = useNuxtApp()
let grid: any = null

const filteredUsers = computed(() => {
   if (!allUsers.value) return []

   return allUsers.value.filter(user => {
      const matchPremium = premiumFilter.value ? user.premium === premiumFilter.value : true
      const matchBanned = bannedFilter.value ? user.banned === bannedFilter.value : true
      return matchPremium && matchBanned
   })
})

function initializeGrid() {
   const gridContainer = document.getElementById('table-gridjs')
   if (!gridContainer) return

   gridContainer.innerHTML = ''
   const gridjs = (window as any).gridjs
   grid = new gridjs.Grid({
      columns: [
         { id: 'jid', hidden: true },
         { id: 'flag', name: 'From', width: '80px', formatter: (cell: string) => gridjs.h('div', { style: { textAlign: 'center' } }, cell) },
         { id: 'phone', name: 'Number', formatter: (cell: string) => gridjs.h('div', { style: { width: '150px' } }, cell) },
         { id: 'name', name: 'Name' },
         { id: 'limit', name: 'Limit', width: '100px', formatter: (cell: number) => gridjs.h('div', { style: { textAlign: 'center' } }, cell) },
         { id: 'limit_game', name: 'Limit Game', width: '120px', formatter: (cell: number) => gridjs.h('div', { style: { textAlign: 'center' } }, cell) },
         {
            id: 'premium', name: 'Premium', width: '110px',
            formatter: (cell: string) => gridjs.h('span', { className: `badge bg-${cell === 'Yes' ? 'success' : 'secondary'}` }, cell)
         },
         {
            id: 'banned', name: 'Banned', width: '110px',
            formatter: (cell: string) => gridjs.h('span', { className: `badge bg-${cell === 'Yes' ? 'danger' : 'secondary'}` }, cell)
         },
         {
            name: 'Actions',
            width: '180px',
            sort: false,
            formatter: (_cell: any, row: any) => {
               const jid = row.cells[0].data as string
               return gridjs.h('div', { className: 'd-flex justify-content-center gap-2' }, [
                  gridjs.h('button', {
                     className: 'btn btn-sm btn-primary',
                     onClick: () => openEditModal(jid)
                  }, 'Edit'),
                  gridjs.h('button', {
                     className: 'btn btn-sm btn-danger',
                     onClick: () => handleDelete(jid)
                  }, 'Delete')
               ])
            }
         }
      ],
      pagination: { limit: 20, summary: true },
      sort: true,
      search: {
         container: '#grid-search-wrapper'
      },
      data: () => filteredUsers.value
   }).render(gridContainer)

   watch([premiumFilter, bannedFilter], () => {
      grid?.forceRender()
   })
}

async function fetchData() {
   load.value = true
   error.value = false
   errorMessage.value = ''

   try {
      const response = await $api('/data/users')
      if (!response || !response.status) {
         throw new Error(response?.msg || 'Failed to fetch data from API')
      }

      stats.value = response.data.stats
      allUsers.value = response.data.users.map((v: any) => {
         const formattedPhone = formatPhoneAuto(v.jid?.replace(/@.+/, ''))
         return {
            jid: v.jid,
            flag: formattedPhone.flag,
            phone: formattedPhone.phone,
            name: v.name,
            limit: v?.limit || 0,
            limit_game: v?.limit_game || 0,
            premium: v.premium ? 'Yes' : 'No',
            banned: v.banned ? 'Yes' : 'No'
         }
      })

      load.value = false
      await nextTick()

      if (!editModalInstance && editModalEl.value) {
         const Modal = (await import('bootstrap/js/dist/modal')).default
         editModalInstance = new Modal(editModalEl.value)
      }

      if (!grid) {
         initializeGrid()
      } else {
         grid.forceRender()
      }

   } catch (e: any) {
      load.value = false
      error.value = true
      errorMessage.value = e.data?.message || e.message || 'An unexpected error occurred'
      Swal.fire({ text: errorMessage.value, icon: 'error', timer: 2000, showConfirmButton: false })
   }
}

function openEditModal(jid: string) {
   const user = allUsers.value.find(u => u.jid === jid)
   if (!user) return

   editForm.value = {
      jid: user.jid,
      phone: user.phone,
      name: user.name,
      limit: user.limit,
      limit_game: user.limit_game,
      premium: user.premium === 'Yes',
      banned: user.banned === 'Yes'
   }
   editModalInstance?.show()
}

async function submitEdit() {
   if (isSubmitting.value) return
   isSubmitting.value = true

   try {
      const payload = {
         id: editForm.value.jid,
         name: editForm.value.name,
         limit: editForm.value.limit,
         limit_game: editForm.value.limit_game,
         premium: editForm.value.premium,
         banned: editForm.value.banned,
      }

      const response = await $api('/action/update-user', {
         method: 'POST',
         body: payload
      })

      if (!response.status) {
         Swal.fire({ text: response.message || 'Failed to update user', icon: 'error', timer: 1500, showConfirmButton: false })
         return
      }

      Swal.fire({
         text: 'User has been updated successfully',
         icon: 'success'
      })

      const data = editForm.value
      const userIndex = allUsers.value.findIndex(u => u.jid === data.jid)
      if (userIndex !== -1) {
         allUsers.value[userIndex] = {
            ...allUsers.value[userIndex],
            name: data.name,
            limit: data.limit,
            limit_game: data.limit_game,
            premium: data.premium ? 'Yes' : 'No',
            banned: data.banned ? 'Yes' : 'No'
         }
      }

      editModalInstance?.hide()
      grid?.forceRender()

   } catch (e: any) {
      Swal.fire({ text: e.data?.message || 'An unexpected error occurred', icon: 'error', timer: 1500, showConfirmButton: false })
   } finally {
      isSubmitting.value = false
   }
}

async function handleDelete(jid: string) {
   const user = allUsers.value.find(u => u.jid === jid)
   if (!user) {
      Swal.fire({ text: 'User not found', icon: 'error', timer: 1500, showConfirmButton: false })
      return
   }

   const result = await Swal.fire({
      title: 'Are you sure?',
      text: `Delete user ${user.name} (${user.phone})? This cannot be undone!`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#d33',
      cancelButtonColor: '#3085d6',
      confirmButtonText: 'Yes, delete it!'
   })

   if (result.isConfirmed) {
      try {
         const response = await $api('/action/delete', {
            method: 'POST',
            body: { jid, type: '_u' }
         })

         if (!response.status) {
            Swal.fire({ text: response.message || 'Failed to delete user', icon: 'error', timer: 1500, showConfirmButton: false })
            return
         }

         Swal.fire({ text: 'User has been successfully deleted', icon: 'success' })

         allUsers.value = allUsers.value.filter(u => u.jid !== jid)
         grid?.forceRender()

      } catch (e: any) {
         Swal.fire({ text: e.data?.message || 'An unexpected error occurred', icon: 'error', timer: 1500, showConfirmButton: false })
      }
   }
}

onMounted(() => {
   fetchData()
})
</script>