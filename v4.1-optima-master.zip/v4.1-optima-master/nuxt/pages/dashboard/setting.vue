<template>
   <div>
      <div v-if="isLoading" class="text-center py-5">
         <div class="spinner-border text-primary" role="status">
            <span class="visually-hidden">Loading...</span>
         </div>
         <p class="mt-2 text-muted">Fetching settings...</p>
      </div>

      <div v-else-if="error" class="alert alert-danger">
         <h4 class="alert-heading">Failed to Load Settings</h4>
         <p>{{ error }}</p>
         <button class="btn btn-primary" @click="fetchSettings">Try Again</button>
      </div>

      <div v-else>
         <div class="row mb-3">
            <div class="col-lg-6 mb-3 mb-lg-0">
               <div class="card h-100">
                  <div class="card-header fw-bold">General</div>
                  <div class="card-body">
                     <p class="text-muted small mb-3">
                        Changes in this section are saved automatically
                     </p>
                     <div class="row">
                        <div v-for="key in generalKeys" :key="key" class="col-6 mb-3">
                           <div class="form-check form-switch">
                              <input class="form-check-input" type="checkbox" role="switch" :id="key"
                                 v-model="settings.data[key]">
                              <label class="form-check-label" :for="key">{{ formatLabel(key) }}</label>
                           </div>
                        </div>
                     </div>
                     <div v-if="generalKeys.length === 0" class="text-muted">
                        No general settings available
                     </div>
                  </div>
               </div>
            </div>

            <div class="col-lg-6">
               <div class="card h-100 d-flex flex-column">
                  <div class="card-header fw-bold">Advanced</div>
                  <div class="card-body overflow-auto flex-grow-1" style="max-height: 450px">
                     <div v-for="key in advancedKeys" :key="key" class="mb-4">
                        <div v-if="typeof editedData[key] === 'number'">
                           <label :for="key" class="form-label">{{ formatLabel(key) }} <span
                                 class="badge bg-secondary">{{
                                    editedData[key] }}</span></label>
                           <input type="range" class="form-range" :min="rangeConfig[key]?.min ?? 1"
                              :max="rangeConfig[key]?.max ?? 20" :step="rangeConfig[key]?.step ?? 1" :id="key"
                              v-model.number="editedData[key]">
                        </div>
                        <div v-else-if="isMultiLineString(key)">
                           <label :for="key" class="form-label">{{ formatLabel(key) }}</label>
                           <textarea class="form-control" :id="key" rows="5" v-model="editedData[key]"></textarea>
                        </div>
                        <div v-else-if="isSimpleArray(key)">
                           <label class="form-label">{{ formatLabel(key) }}</label>
                           <div class="d-flex flex-wrap gap-1 mb-2"
                              v-if="editedData[key] && editedData[key].length > 0">
                              <span v-for="(item, index) in editedData[key]" :key="index"
                                 class="badge text-bg-primary d-flex align-items-center">
                                 {{ item }}
                                 <button type="button" class="btn-close btn-close-white ms-2" style="font-size: 0.6em"
                                    @click="removeArrayItem(key, index)" aria-label="Remove"></button>
                              </span>
                           </div>
                           <input type="text" class="form-control form-control-sm" placeholder="Type and press Enter..."
                              @keydown.enter.prevent="addArrayItem(key, $event)">
                        </div>
                        <div v-else-if="typeof editedData[key] === 'object' && editedData[key] !== null">
                           <label :for="key" class="form-label">{{ formatLabel(key) }} <span
                                 class="badge bg-info-subtle text-info-emphasis">Read-only</span></label>
                           <textarea class="form-control font-monospace" :id="key" rows="6"
                              :value="JSON.stringify(editedData[key], null, 2)" readonly></textarea>
                        </div>
                        <div v-else>
                           <label :for="key" class="form-label">{{ formatLabel(key) }}</label>
                           <input type="text" class="form-control" :id="key" v-model="editedData[key]">
                        </div>
                     </div>
                     <div v-if="advancedKeys.length === 0" class="text-muted">
                        No advanced settings available
                     </div>
                  </div>
                  <div class="card-footer text-end">
                     <button class="btn btn-primary" @click="saveAdvancedSettings">
                        Save Advanced Settings
                     </button>
                  </div>
               </div>
            </div>
         </div>

         <div class="row mb-3">
            <div class="col-lg-12">
               <div class="card h-100 d-flex flex-column">
                  <div class="card-header fw-bold">Appearance</div>
                  <div class="card-body overflow-auto flex-grow-1">
                     <div v-for="key in appearanceKeys" :key="key" class="mb-4">
                        <div v-if="typeof editedData[key] === 'number'">
                           <label :for="key" class="form-label">{{ formatLabel(key) }} <span
                                 class="badge bg-secondary">{{
                                    editedData[key] }}</span></label>
                           <input type="range" class="form-range" :min="rangeConfig[key]?.min ?? 1"
                              :max="rangeConfig[key]?.max ?? 20" :step="rangeConfig[key]?.step ?? 1" :id="key"
                              v-model.number="editedData[key]">
                        </div>
                        <div v-else-if="isMultiLineString(key)">
                           <label :for="key" class="form-label">{{ formatLabel(key) }}</label>
                           <textarea class="form-control" :id="key" rows="5" v-model="editedData[key]"></textarea>
                        </div>
                        <div v-else>
                           <label :for="key" class="form-label">{{ formatLabel(key) }}</label>
                           <input type="text" class="form-control" :id="key" v-model="editedData[key]">
                        </div>
                     </div>
                     <div v-if="appearanceKeys.length === 0" class="text-muted">
                        No appearance settings available
                     </div>
                  </div>
                  <div class="card-footer text-end">
                     <button class="btn btn-primary" @click="saveAppearanceSettings">
                        Save Appearance Settings
                     </button>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</template>

<script setup lang="ts">
import { ref, computed, watch, onMounted } from 'vue'
import { useHead, useNuxtApp } from '#imports'
import { useAuth } from '~/composables/useAuth'
import Swal from 'sweetalert2'

const { type } = useAuth()
useHead({ title: 'Settings' })

const { $api } = useNuxtApp()

interface SettingsData { debug: boolean; self: boolean; error: string[]; hidden: string[]; multiprefix: boolean; prefix: string[]; noprefix: boolean; online: boolean; onlyprefix: string; owners: string[]; except: any[]; viewstory: boolean; style: number; msg: string; rules: string; chatbot: boolean; autodownload: boolean; games: boolean; groupmode: boolean; sk_pack: string; sk_author: string; toxic: string[]; link: string; antispam: boolean; verify: boolean; levelup: boolean; moderators: any[]; autobackup: boolean;[key: string]: any }
interface Settings { creator: string; status: boolean; data: SettingsData }

const isLoading = ref(true)
const error = ref<string | null>(null)
const isInitialLoad = ref(true)
const settings = ref<Settings>({ creator: '', status: false, data: {} as SettingsData })
const editedData = ref<SettingsData>({} as SettingsData)

const excludedKeys = computed(() => {
   const operatorOnly = String(type.value) !== '1' ? ['debug', 'autobackup'] : []
   const baseExcludedKeys = [
      'lock', 'silent', 'greeting', 'autoreadpc', 'autoreadgc', '_style',
      '_msg', 'cover', 'dial', 'forwardstory', 'inbound', 'outbound',
      'lastReset', 'rules', 'mimic', 'nlp', 'covergif', 'whitelist',
      'spy', 'receiver', 'product', 'pluginVerified', 'pluginDisable',
      'received', 'sent'
   ]
   return [...operatorOnly, ...baseExcludedKeys]
})

const labelMap: Record<string, string> = { self: 'Self Mode', multiprefix: 'Multi Prefix', noprefix: 'No Prefix', onlyprefix: 'Only Prefix', viewstory: 'View Story', sk_pack: 'Sticker Pack', sk_author: 'Sticker Author', groupmode: 'Group Mode', antispam: 'Anti Spam', verify: 'Verify', levelup: 'Level Up', autodownload: 'Auto Download', autobackup: 'Auto Backup', msg: 'Menu Message', style: 'Menu Style', online: 'Always Online' }
const rangeConfig: Record<string, { min: number; max: number; step: number }> = {
   style: { min: 1, max: 8, step: 1 }
}

const appearanceFieldKeys = ['msg', 'style', 'rules', 'sk_pack', 'sk_author']
const settingKeys = computed(() => Object.keys(settings.value.data))
const generalKeys = computed(() => settingKeys.value.filter(key => typeof settings.value.data[key] === 'boolean' && !appearanceFieldKeys.includes(key)).sort())
const appearanceKeys = computed(() => settingKeys.value.filter(key => appearanceFieldKeys.includes(key)).sort())
const advancedKeys = computed(() => settingKeys.value.filter(key => typeof settings.value.data[key] !== 'boolean' && !appearanceFieldKeys.includes(key)).sort())

const formatLabel = (key: string): string => { if (labelMap[key]) { return labelMap[key] } if (!key) return ''; return key.charAt(0).toUpperCase() + key.slice(1) }
const isMultiLineString = (key: string): boolean => { const value = editedData.value[key]; return typeof value === 'string' && value.includes('\n') }
const isSimpleArray = (key: string): boolean => { const value = editedData.value[key]; if (!Array.isArray(value)) return false; if (value.length === 0) return true; return ['string', 'number'].includes(typeof value[0]) }
const addArrayItem = (key: string, event: KeyboardEvent) => { const input = event.target as HTMLInputElement; const value = input.value.trim(); if (value) { if (!Array.isArray(editedData.value[key])) editedData.value[key] = []; editedData.value[key].push(value); input.value = '' } }
const removeArrayItem = (key: string, index: number) => { editedData.value[key].splice(index, 1) }

const fetchSettings = async () => {
   isLoading.value = true
   isInitialLoad.value = true
   error.value = null
   try {
      const response = await $api('/data/setting')
      if (response.status) {
         const originalData = response.data
         const filteredData = Object.fromEntries(
            Object.entries(originalData).filter(([key]) => !excludedKeys.value.includes(key))
         ) as SettingsData

         settings.value = { ...response, data: filteredData }
         editedData.value = JSON.parse(JSON.stringify(filteredData))

         setTimeout(() => {
            isInitialLoad.value = false
         }, 0)

      } else {
         throw new Error(response.message || 'Failed to fetch settings from API')
      }
   } catch (e: any) {
      error.value = e.message
      console.error(e)
      isInitialLoad.value = false
   } finally {
      isLoading.value = false
   }
}

onMounted(() => {
   fetchSettings()
})

let debounceTimer: ReturnType<typeof setTimeout> | null = null
const updateSettings = async () => {
   if (Swal.isVisible() && Swal.isLoading()) return
   Swal.fire({
      title: 'Saving...',
      text: 'Updating your settings',
      allowOutsideClick: false,
      didOpen: () => Swal.showLoading()
   })
   try {
      const response = await $api('/action/update-setting', {
         method: 'POST',
         body: {
            data: settings.value.data
         }
      })
      if (response.status) {
         editedData.value = JSON.parse(JSON.stringify(settings.value.data))
         Swal.fire({
            icon: 'success',
            title: 'Saved!',
            text: 'Your settings have been updated successfully',
            timer: 1500,
            showConfirmButton: false
         })
      } else {
         throw new Error(response.message || 'An unknown API error occurred')
      }
   } catch (error: any) {
      Swal.fire({
         icon: 'error',
         title: 'Update Failed',
         text: `Failed to save settings: ${error.message || error}`
      })
   }
}

const saveAdvancedSettings = () => {
   for (const key of advancedKeys.value) {
      settings.value.data[key] = editedData.value[key]
   }
   updateSettings()
}

const saveAppearanceSettings = () => {
   for (const key of appearanceKeys.value) {
      settings.value.data[key] = editedData.value[key]
   }
   updateSettings()
}

const generalData = computed(() => {
   const data: { [key: string]: boolean } = {}
   for (const key of generalKeys.value) {
      data[key] = settings.value.data[key]
   }
   return data
})

watch(generalData, (newValue, oldValue) => {
   if (isInitialLoad.value) {
      return
   }

   if (JSON.stringify(newValue) === JSON.stringify(oldValue)) {
      return
   }
   if (debounceTimer) {
      clearTimeout(debounceTimer)
   }
   debounceTimer = setTimeout(() => {
      updateSettings()
   }, 1200)
}, {
   deep: true
})
</script>