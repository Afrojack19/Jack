<template>
   <div class="row">
      <div class="col-xl-12">
         <div class="card">
            <div class="card-body">
               <div class="py-3">

                  <div v-if="load" class="text-center py-5">
                     <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                     </div>
                     <p class="mt-2 text-muted">Fetching data...</p>
                  </div>

                  <div v-else-if="error" class="alert alert-danger">
                     <h4 class="alert-heading">Failed to Load Data</h4>
                     <p>{{ errorMessage }}</p>
                     <button class="btn btn-primary" @click="fetchData">Try Again</button>
                  </div>

                  <div v-else>
                     <div class="d-flex justify-content-end align-items-center mb-3 gap-2 flex-wrap">
                        <div id="grid-search-wrapper"></div>
                     </div>
                     <div id="table-gridjs"></div>
                  </div>

               </div>
            </div>
         </div>
      </div>
   </div>

   <div class="modal fade" id="tokenModal" tabindex="-1" aria-labelledby="tokenModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-dialog-centered">
         <div class="modal-content">
            <div class="modal-header">
               <h5 class="modal-title" id="tokenModalLabel">Token</h5>
               <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
               <div class="input-group">
                  <input type="text" class="form-control" :value="tokenToShow" readonly>
                  <button class="btn btn-outline-secondary" type="button" @click="copyToken" :disabled="isCopying">
                     {{ isCopying ? 'Copied!' : 'Copy' }}
                  </button>
               </div>
            </div>
            <div class="modal-footer">
               <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
            </div>
         </div>
      </div>
   </div>
</template>

<script setup lang="ts">
import { ref, onMounted, nextTick } from 'vue'
import { useHead, useNuxtApp } from '#imports'
import { formatPhoneAuto } from '@/utils'
import Swal from 'sweetalert2'

useHead({ title: 'Sessions' })

const sessions = ref<any[]>([])
const load = ref(true)
const error = ref(false)
const errorMessage = ref('')
const tokenToShow = ref('')
const isCopying = ref(false)
let tokenModalInstance: any = null
const { $api } = useNuxtApp()
let grid: any = null

function initializeGrid() {
   const gridContainer = document.getElementById('table-gridjs')
   if (!gridContainer) return

   gridContainer.innerHTML = ''
   const gridjs = (window as any).gridjs
   grid = new gridjs.Grid({
      columns: [
         { id: '_id', hidden: true },
         { id: 'ownerJid', hidden: true },
         { id: 'flag', name: 'From', width: '70px', formatter: (cell: string) => gridjs.h('div', { className: 'text-center' }, cell) },
         { id: 'bot', name: 'Bot', formatter: (cell: string) => gridjs.h('div', { style: { width: '150px' } }, cell) },
         { id: 'owner', name: 'Owner', formatter: (cell: string) => gridjs.h('div', { style: { width: '150px' } }, cell) },
         { id: 'method', name: 'Method', width: '100px' },
         { id: 'last_connect', name: 'Last Connect', width: '200px' },
         { id: 'connected', name: 'Status', width: '120px', formatter: (cell: boolean) => gridjs.h('div', { className: 'text-center' }, gridjs.h('span', { className: `badge ${cell ? 'bg-success' : 'bg-danger'}` }, cell ? 'ONLINE' : 'OFFLINE')) },
         { id: 'users', name: 'Users', width: '80px', formatter: (cell: number) => gridjs.h('div', { className: 'text-center' }, cell) },
         { id: 'chats', name: 'Chats', width: '80px', formatter: (cell: number) => gridjs.h('div', { className: 'text-center' }, cell) },
         { id: 'groups', name: 'Groups', width: '80px', formatter: (cell: number) => gridjs.h('div', { className: 'text-center' }, cell) },
         {
            name: 'Actions',
            width: '200px',
            sort: false,
            formatter: (_cell: any, row: any) => {
               const id = row.cells[0].data as string
               const ownerJid = row.cells[1].data as string
               const isConnected = row.cells[7].data as boolean

               const actionButton = isConnected
                  ? gridjs.h(
                     'button', {
                     className: 'btn btn-sm btn-warning',
                     onClick: () => handleTerminate(id),
                  },
                     'Terminate'
                  )
                  : gridjs.h(
                     'button', {
                     className: 'btn btn-sm btn-danger',
                     onClick: () => handleDelete(ownerJid),
                  },
                     'Delete'
                  )

               return gridjs.h(
                  'div', { className: 'd-flex justify-content-center gap-2' },
                  [
                     gridjs.h(
                        'button', {
                        className: 'btn btn-sm btn-info',
                        onClick: () => handleGetToken(id),
                     },
                        'Token'
                     ),
                     actionButton,
                  ]
               )
            },
         },
      ],
      pagination: { limit: 10, summary: true },
      sort: true,
      search: { container: '#grid-search-wrapper' },
      data: () => sessions.value
   }).render(gridContainer)
}

async function fetchData() {
   load.value = true
   error.value = false
   errorMessage.value = ''

   try {
      const response = await $api('/data/sessions')
      if (!response.status) {
         throw new Error(response.message || 'Failed to load session data')
      }

      sessions.value = response.data.map((v: any) => ({
         _id: v._id,
         ownerJid: v.sender,
         flag: formatPhoneAuto(v.jid?.replace(/@.+/, '')).flag,
         bot: formatPhoneAuto(v.jid?.replace(/@.+/, '')).phone,
         owner: formatPhoneAuto(v.sender?.replace(/@.+/, '')).phone,
         method: v.method === '--pairing' ? 'Pairing' : v.method === '--qr' ? 'Pairing' : '-',
         last_connect: v.last_connect ? new Date(v.last_connect).toLocaleString('en-US', {
            year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true
         }) : 'N/A',
         connected: v.is_connected,
         users: v.data.users,
         chats: v.data.chats,
         groups: v.data.groups
      }))

      load.value = false
      await nextTick()

      if (!tokenModalInstance) {
         const Modal = (await import('bootstrap/js/dist/modal')).default
         const modalEl = document.getElementById('tokenModal')
         if (modalEl) tokenModalInstance = new Modal(modalEl)
      }

      if (!grid) {
         initializeGrid()
      } else {
         grid.updateConfig({ data: sessions.value }).forceRender()
      }

   } catch (e: any) {
      load.value = false
      error.value = true
      errorMessage.value = e.data?.message || e.message || 'An unexpected error occurred'
      Swal.fire({ text: errorMessage.value, icon: 'error', timer: 2000, showConfirmButton: false })
   }
}

function copyToken() {
   if (isCopying.value) return
   navigator.clipboard.writeText(tokenToShow.value).then(() => {
      isCopying.value = true
      setTimeout(() => { isCopying.value = false }, 2000)
   })
}

async function handleGetToken(id: string) {
   Swal.fire({ title: 'Generating Token...', text: 'Please wait.', allowOutsideClick: false, didOpen: () => Swal.showLoading() })
   try {
      const response = await $api('/action/get-token', { method: 'POST', body: { id } })
      Swal.close()
      if (response.status && response.data?.token) {
         tokenToShow.value = response.data.token
         tokenModalInstance?.show()
      } else {
         Swal.fire({ text: response.message || 'Failed to retrieve token', icon: 'error', timer: 2000, showConfirmButton: false })
      }
   } catch (e: any) {
      Swal.close()
      Swal.fire({ text: e.data?.message || 'An unexpected error occurred', icon: 'error', timer: 2000, showConfirmButton: false })
   }
}

async function handleTerminate(id: string) {
   const session = sessions.value.find(s => s._id === id)
   if (!session) return

   const result = await Swal.fire({
      title: 'Are you sure?',
      text: `Terminate the session for bot: ${session.bot}? This will disconnect the bot.`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#f0ad4e',
      confirmButtonText: 'Yes, terminate it!'
   })

   if (result.isConfirmed) {
      Swal.fire({ title: 'Terminating...', allowOutsideClick: false, didOpen: () => Swal.showLoading() })
      try {
         const response = await $api('/action/terminate', { method: 'POST', body: { id } })
         if (!response.status) {
            Swal.fire({ text: response.message || 'Failed to terminate session', icon: 'error', timer: 2000, showConfirmButton: false })
            return
         }
         Swal.fire({ text: 'The session has been terminated.', icon: 'success', timer: 1500, showConfirmButton: false })
         
         sessions.value = sessions.value.filter(s => s._id !== id);
         grid?.updateConfig({
            data: sessions.value
         }).forceRender()

      } catch (e: any) {
         Swal.fire({ text: e.data?.message || 'An unexpected error occurred', icon: 'error', timer: 2000, showConfirmButton: false })
      }
   }
}

async function handleDelete(ownerJid: string) {
   const session = sessions.value.find(s => s.ownerJid === ownerJid)
   if (!session) return

   const result = await Swal.fire({
      title: 'Delete Session?',
      text: `This will permanently delete the session file for bot: ${session.bot} (Owner: ${session.owner}). This action cannot be undone.`,
      icon: 'error',
      showCancelButton: true,
      confirmButtonColor: '#d33',
      cancelButtonText: 'Cancel',
      confirmButtonText: 'Yes, delete it!'
   })

   if (result.isConfirmed) {
      Swal.fire({ title: 'Deleting...', allowOutsideClick: false, didOpen: () => Swal.showLoading() })
      try {
         const response = await $api('/action/delete', { method: 'POST', body: { jid: ownerJid, type: '_b' } })
         if (!response.status) {
            Swal.fire({ text: response.message || 'Failed to delete session', icon: 'error', timer: 2000, showConfirmButton: false })
            return
         }
         Swal.fire({
            title: 'Deleted!',
            text: 'The session has been permanently deleted.',
            icon: 'success',
            timer: 1500,
            showConfirmButton: false
         })
         sessions.value = sessions.value.filter(s => s.ownerJid !== ownerJid)
         grid?.updateConfig({
            data: sessions.value
         }).forceRender()
      } catch (e: any)
      {
         Swal.fire({ text: e.data?.message || 'An unexpected error occurred', icon: 'error', timer: 2000, showConfirmButton: false })
      }
   }
}

onMounted(() => {
   fetchData()
})
</script>