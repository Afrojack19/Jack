<template>
   <div class="row">
      <div class="col-md-4 col-xl-4" v-for="(icon, index) in ['user', 'group', 'message-square-dots']" :key="index">
         <div class="card">
            <div class="card-body">
               <div class="row">
                  <div class="col-6">
                     <div :class="['avatar-md', 'rounded', ['bg-primary', 'bg-success', 'bg-info'][index]]">
                        <i :class="['bx', `bx-${icon}`, 'avatar-title', 'fs-24', 'text-white']"></i>
                     </div>
                  </div>
                  <div class="col-6 text-end">
                     <p class="text-muted mb-0 text-truncate">{{ ['Personal', 'Group', 'Total'][index] }}</p>
                     <h3 class="text-dark mt-1 mb-0">
                        {{ [stats?.personal || 0, stats?.group || 0, stats?.total || 0][index] }}
                     </h3>
                  </div>
               </div>
            </div>
         </div>
      </div>

      <div class="col-xl-12">
         <div class="card">
            <div class="card-body">
               <div class="py-3">

                  <div v-if="load" class="text-center py-5">
                     <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                     </div>
                     <p class="mt-2 text-muted">Fetching data...</p>
                  </div>

                  <div v-else-if="error" class="d-flex justify-content-center align-items-center"
                     style="min-height: 200px;">
                     <p class="text-muted">No data available.</p>
                  </div>

                  <div v-else>
                     <div class="d-flex justify-content-end align-items-center mb-3 gap-2 flex-wrap">
                        <select class="form-select form-select-sm w-auto" v-model="filterType">
                           <option value="all">All Types</option>
                           <option value="personal">Personal</option>
                           <option value="group">Group</option>
                        </select>
                        <div id="grid-search-wrapper"></div>
                     </div>

                     <div id="table-gridjs"></div>
                  </div>

               </div>
            </div>
         </div>
      </div>
   </div>
</template>

<script setup lang="ts">
import { ref, onMounted, nextTick, computed, watch } from 'vue'
import { useHead, useNuxtApp } from '#imports'
import Swal from 'sweetalert2'
import { formatPhoneAuto } from '@/utils'

useHead({ title: 'Chats Database' })

const stats = ref<{ personal: number, group: number, total: number } | null>(null)
const allChats = ref<any[]>([])
const filterType = ref('all')
const load = ref(true)
const error = ref(false)
const errorMessage = ref('')
const { $api } = useNuxtApp()
let grid: any = null

const formatTimestamp = (timestamp: number): string => {
   if (!timestamp || timestamp <= 0) return '-'
   return new Date(timestamp).toLocaleString('en-US', {
      year: 'numeric', month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit', hour12: true
   })
}

const filteredChats = computed(() => {
   if (filterType.value === 'all') {
      return allChats.value
   }
   return allChats.value.filter(chat => chat.type.toLowerCase() === filterType.value)
})

function initializeGrid() {
   const gridContainer = document.getElementById('table-gridjs')
   if (!gridContainer) return;

   gridContainer.innerHTML = ''
   const gridjs = (window as any).gridjs
   grid = new gridjs.Grid({
      columns: [
         { id: 'jid', hidden: true },
         { name: 'From', id: 'flag', width: '80px', formatter: (cell: string) => gridjs.h('div', { style: { textAlign: 'center' } }, cell) },
         { name: 'Number', id: 'number', formatter: (cell: string) => gridjs.h('div', { style: { width: '150px' } }, cell) },
         { name: 'Type', id: 'type', width: '120px', formatter: (cell: string) => gridjs.h('span', { className: cell === 'Group' ? 'badge bg-success' : 'badge bg-primary' }, cell) },
         { name: 'Chat', id: 'chat' },
         { name: 'Last Chat', id: 'lastchat', formatter: (cell: number) => formatTimestamp(cell) },
         {
            name: 'Actions', width: '120px', sort: false, formatter: (_cell: any, row: any) => {
               const jid = row.cells[0].data as string
               return gridjs.h('div', { className: 'd-flex justify-content-center' },
                  gridjs.h('button', { className: 'btn btn-sm btn-danger', onClick: () => handleDelete(jid) }, 'Delete')
               )
            }
         }
      ],
      pagination: { limit: 20, summary: true },
      sort: { initial: [{ id: 'lastchat', direction: -1 }] },
      search: { container: '#grid-search-wrapper' },
      data: () => filteredChats.value
   }).render(gridContainer)

   watch(filterType, () => {
      grid?.forceRender()
   })
}

async function fetchData() {
   load.value = true
   error.value = false
   errorMessage.value = ''

   try {
      const response = await $api('/data/chats')
      if (!response || !response.status) {
         throw new Error(response?.msg || 'Failed to fetch chats from API')
      }

      stats.value = response.data.stats
      allChats.value = response.data.chats.map((v: any) => {
         const numberOnly = v.jid?.replace(/@.+/, '')
         const isGroup = v.jid.endsWith('@g.us')
         const formattedPhone = formatPhoneAuto(numberOnly)

         return {
            jid: v.jid,
            flag: isGroup ? '🏴‍☠️' : formattedPhone.flag,
            number: isGroup ? v.name || numberOnly : formattedPhone.phone,
            chat: v.chat,
            lastchat: Number(v.lastseen || v.lastchat || 0),
            type: isGroup ? 'Group' : 'Personal'
         }
      })

      load.value = false;
      await nextTick();

      if (!grid) {
         initializeGrid();
      } else {
         grid.forceRender();
      }

   } catch (e: any) {
      load.value = false
      error.value = true
      errorMessage.value = e.data?.message || e.message || 'An unexpected error occurred'
      Swal.fire({ text: errorMessage.value, icon: 'error', timer: 2000, showConfirmButton: false })
   }
}

async function handleDelete(jid: string) {
   const chatToDelete = allChats.value.find(c => c.jid === jid)
   const chatName = chatToDelete ? chatToDelete.number : jid

   const result = await Swal.fire({
      title: 'Are you sure?',
      text: `You are about to delete the chat history with ${chatName}. This action cannot be undone!`,
      icon: 'warning',
      showCancelButton: true,
      confirmButtonColor: '#d33',
      cancelButtonColor: '#3085d6',
      confirmButtonText: 'Yes, delete it!',
      cancelButtonText: 'Cancel'
   })

   if (result.isConfirmed) {
      try {
         const response = await $api('/action/delete', {
            method: 'POST',
            body: { jid, type: '_c' }
         })
         if (!response.status) {
            Swal.fire({ text: response.message || 'Failed to delete chat', icon: 'error', timer: 1500, showConfirmButton: false })
            return
         }

         allChats.value = allChats.value.filter(chat => chat.jid !== jid)
         grid?.forceRender()
         Swal.fire({ text: 'Chat has been successfully deleted', icon: 'success' })

      } catch (e: any) {
         Swal.fire({
            text: e.data?.message || 'An error occurred',
            icon: 'error',
            timer: 1500,
            showConfirmButton: false
         })
      }
   }
}

onMounted(() => {
   fetchData()
})
</script>