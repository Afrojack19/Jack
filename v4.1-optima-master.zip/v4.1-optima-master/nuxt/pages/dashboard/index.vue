<template>
   <Box />

   <div class="row">
      <div class="col-lg-6">
         <div class="card card-height-100">
            <div class="card-header d-flex align-items-center justify-content-between gap-2">
               <h4 class="card-title flex-grow-1">Top 10 Users</h4>
            </div>
            <div class="card-body p-0">
               <div class="table-responsive">

                  <div v-if="load" class="d-flex justify-content-center align-items-center" style="min-height: 200px;">
                     <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                     </div>
                  </div>

                  <table v-else-if="topHit.length > 0" class="table table-hover table-nowrap table-centered m-0">
                     <thead class="bg-light bg-opacity-50">
                        <tr>
                           <th class="text-muted py-1">From</th>
                           <th class="text-muted py-1">Number</th>
                           <th class="text-muted py-1">Name</th>
                           <th class="text-muted py-1">Hits</th>
                           <th class="text-muted py-1">Referral</th>
                        </tr>
                     </thead>
                     <tbody>
                        <tr v-for="(user, index) in topHit" :key="index">
                           <td>{{ formatPhoneAuto(user.jid?.replace(/@.+/, ''))?.flag }}</td>
                           <td>{{ formatPhoneAuto(user.jid?.replace(/@.+/, ''))?.phone }}</td>
                           <td>{{ user.name }}</td>
                           <td>{{ formatter(user.hit) }}</td>
                           <td>{{ user.refcode }}</td>
                        </tr>
                     </tbody>
                  </table>

                  <div v-else class="d-flex justify-content-center align-items-center" style="min-height: 200px;">
                     <p class="text-muted">No user data available.</p>
                  </div>
               </div>
            </div>
         </div>
      </div>

      <div class="col-lg-6">
         <div class="card card-height-100">
            <div class="card-header d-flex align-items-center justify-content-between gap-2">
               <h4 class="card-title flex-grow-1">Top 10 Ranks</h4>
            </div>
             <div class="card-body p-0">
               <div class="table-responsive">

                  <div v-if="load" class="d-flex justify-content-center align-items-center" style="min-height: 200px;">
                     <div class="spinner-border text-primary" role="status">
                        <span class="visually-hidden">Loading...</span>
                     </div>
                  </div>

                  <table v-else-if="topPoint.length > 0" class="table table-hover table-nowrap table-centered m-0">
                     <thead class="bg-light bg-opacity-50">
                        <tr>
                           <th class="text-muted py-1">From</th>
                           <th class="text-muted py-1">Number</th>
                           <th class="text-muted py-1">Name</th>
                           <th class="text-muted py-1">Point</th>
                           <th class="text-muted py-1">Balance</th>
                        </tr>
                     </thead>
                     <tbody>
                        <tr v-for="(user, index) in topPoint" :key="index">
                           <td>{{ formatPhoneAuto(user.jid?.replace(/@.+/, ''))?.flag }}</td>
                           <td>{{ formatPhoneAuto(user.jid?.replace(/@.+/, ''))?.phone }}</td>
                           <td>{{ user.name }}</td>
                           <td>{{ h2k(user.point) }}</td>
                           <td>{{ h2k(user.balance) }}</td>
                        </tr>
                     </tbody>
                  </table>
                  
                  <div v-else class="d-flex justify-content-center align-items-center" style="min-height: 200px;">
                     <p class="text-muted">No rank data available.</p>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</template>

<script setup lang="ts">
useHead({ title: 'Dashboard' })
import { ref, onMounted } from 'vue'
import { formatPhoneAuto, h2k, formatter } from '@/utils'
import Swal from 'sweetalert2'

const topHit = ref<any[]>([])
const topPoint = ref<any[]>([])
const load = ref(true)

const { $api } = useNuxtApp()

async function fetchData() {
   load.value = true
   try {
      const json = await $api('/data/top')
      if (!json.status) {
         Swal.fire({
            title: 'Oops...',
            text: json.msg || 'Failed to fetch top data.',
            icon: 'error',
            showConfirmButton: false,
            timer: 2000
         })
         return
      }
      topHit.value = json.data.top_hit
      topPoint.value = json.data.top_point
   } catch (e: any) {
      Swal.fire({
            title: 'Error',
            text: e.message || 'An unexpected error occurred.',
            icon: 'error',
            showConfirmButton: false,
            timer: 2000
         })
   } finally {
      load.value = false
   }
}

onMounted(() => {
   fetchData()
})
</script>