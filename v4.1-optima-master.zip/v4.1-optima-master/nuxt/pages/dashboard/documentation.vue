<template>
   <div class="row">
      <div class="col-12">
         <!-- Card for API Token -->
         <div class="card mb-4">
            <div class="card-header">
               <h4 class="card-title mb-0">Your API Token</h4>
            </div>
            <div class="card-body">
               <p class="card-text text-muted mb-3">
                  Use this token in the <code>x-neoxr-token</code> header for every API request. This token is
                  confidential.
               </p>
               <div class="input-group">
                  <input type="text" class="form-control" :value="apiToken" readonly placeholder="Loading token...">
                  <button class="btn btn-primary" type="button" @click="copyToken"
                     :disabled="!apiToken || apiToken.includes('Failed')">
                     <i class="bx bx-copy me-1"></i>
                     <span>{{ tokenCopyStatus }}</span>
                  </button>
               </div>
            </div>
         </div>

         <!-- Card for API Documentation -->
         <div class="card">
            <div class="card-header border-bottom">
               <h4 class="card-title mb-0">API Documentation</h4>
            </div>
            <div class="card-body">
               <p class="card-text text-muted">
                  Below is a list of available API endpoints for sending messages. All requests require the
                  <code class="text-danger">x-neoxr-token</code> header containing your bot session token.
               </p>

               <div class="accordion" id="apiAccordion">
                  <div class="accordion-item" v-for="endpoint in endpoints" :key="endpoint.id">
                     <h2 class="accordion-header" :id="`heading-${endpoint.id}`">
                        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse"
                           :data-bs-target="`#collapse-${endpoint.id}`" aria-expanded="false"
                           :aria-controls="`collapse-${endpoint.id}`">
                           <span :class="`badge me-3 bg-${endpoint.methodColor}`">{{ endpoint.method }}</span>
                           <code class="fs-6 fw-medium">{{ endpoint.path }}</code>
                           <span class="ms-auto text-muted fst-italic me-2">{{ endpoint.title }}</span>
                        </button>
                     </h2>
                     <div :id="`collapse-${endpoint.id}`" class="accordion-collapse collapse"
                        :aria-labelledby="`heading-${endpoint.id}`" data-bs-parent="#apiAccordion">
                        <div class="accordion-body">
                           <p>{{ endpoint.description }}</p>

                           <!-- Headers -->
                           <h6>Headers</h6>
                           <div class="table-responsive">
                              <table class="table table-bordered table-sm align-middle">
                                 <thead class="table-light">
                                    <tr>
                                       <th style="width: 25%">Key</th>
                                       <th>Description</th>
                                    </tr>
                                 </thead>
                                 <tbody>
                                    <tr>
                                       <td><code>x-neoxr-token</code></td>
                                       <td>Your bot instance token. <strong>(Required)</strong></td>
                                    </tr>
                                 </tbody>
                              </table>
                           </div>

                           <!-- Body Parameters -->
                           <h6 class="mt-4">Body Parameters (application/json)</h6>
                           <div class="table-responsive">
                              <table class="table table-bordered table-sm align-middle">
                                 <thead class="table-light">
                                    <tr>
                                       <th style="width: 20%">Parameter</th>
                                       <th style="width: 15%">Type</th>
                                       <th style="width: 15%">Status</th>
                                       <th>Description</th>
                                    </tr>
                                 </thead>
                                 <tbody>
                                    <tr v-for="param in endpoint.parameters" :key="param.name">
                                       <td><code>{{ param.name }}</code></td>
                                       <td><code>{{ param.type }}</code></td>
                                       <td>
                                          <span v-if="param.required"
                                             class="badge bg-danger-subtle text-danger-emphasis">Required</span>
                                          <span v-else
                                             class="badge bg-secondary-subtle text-secondary-emphasis">Optional</span>
                                       </td>
                                       <td v-html="param.description"></td>
                                    </tr>
                                 </tbody>
                              </table>
                           </div>

                           <!-- Notes -->
                           <div v-if="endpoint.notes && endpoint.notes.length > 0" class="mt-4">
                              <h6>Notes</h6>
                              <ul class="list-unstyled">
                                 <li v-for="(note, index) in endpoint.notes" :key="index" class="mb-1 d-flex">
                                    <i class="bx bx-info-circle text-primary me-2 mt-1"></i>
                                    <span v-html="note"></span>
                                 </li>
                              </ul>
                           </div>

                           <!-- Curl Example -->
                           <h6 class="mt-4">Example (cURL)</h6>
                           <div class="code-container position-relative">
                              <pre
                                 class="language-bash"><code :id="`code-block-${endpoint.id}`">{{ endpoint.curlExample }}</code></pre>
                              <button class="btn btn-sm btn-light btn-copy"
                                 @click="copyToClipboard(endpoint.curlExample, endpoint.id)">
                                 <i class="bx bx-copy me-1"></i> {{ copyStatus[endpoint.id] || 'Copy' }}
                              </button>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </div>
   </div>
</template>

<script setup lang="ts">
import { ref, onMounted, nextTick } from 'vue'
import Prism from 'prismjs'
import { useHead } from '#imports'

useHead({ title: 'Documentation' })

import 'prismjs/themes/prism-okaidia.css'
import 'prismjs/components/prism-bash'

const { $api } = useNuxtApp()
const apiToken = ref('')
const tokenCopyStatus = ref('Copy')

const copyStatus = ref<{ [key: string]: string }>({})

const copyToken = () => {
   if (!apiToken.value || apiToken.value.includes('Failed')) return
   navigator.clipboard.writeText(apiToken.value).then(() => {
      tokenCopyStatus.value = 'Copied!'
      setTimeout(() => {
         tokenCopyStatus.value = 'Copy'
      }, 2000)
   }).catch(err => {
      console.error('Failed to copy token:', err)
      tokenCopyStatus.value = 'Failed!'
      setTimeout(() => {
         tokenCopyStatus.value = 'Copy'
      }, 2000)
   })
}

const copyToClipboard = (text: string, id: string) => {
   navigator.clipboard.writeText(text).then(() => {
      copyStatus.value[id] = 'Copied!'
      setTimeout(() => {
         delete copyStatus.value[id]
      }, 2000)
   }).catch(err => {
      console.error('Failed to copy text: ', err)
   })
}

const endpoints = ref([
   {
      id: 'send-text',
      title: 'Send Text Message',
      method: 'POST',
      methodColor: 'primary',
      path: '/v1/text',
      description: 'Sends a plain text message to a specified WhatsApp number.',
      parameters: [
         { name: 'number', type: 'string', required: true, description: 'Recipient WhatsApp number with country code (e.g., 62812xxxx).' },
         { name: 'text', type: 'string', required: true, description: 'The text message content.' },
      ],
      notes: [],
      curlExample: `curl -X POST '__BASE_URL__/v1/text' \\
  --header 'x-neoxr-token: __YOUR_TOKEN__' \\
  --header 'Content-Type: application/json' \\
  --data-raw '{
    "number": "6281234567890",
    "text": "Hello, this is a test message."
  }'`
   },
   {
      id: 'send-media',
      title: 'Send Media (Image/Video)',
      method: 'POST',
      methodColor: 'success',
      path: '/v1/media',
      description: 'Sends a media file (image or video) from a URL.',
      parameters: [
         { name: 'number', type: 'string', required: true, description: 'Recipient WhatsApp number.' },
         { name: 'url', type: 'string', required: true, description: 'Publicly accessible URL of the image or video.' },
         { name: 'caption', type: 'string', required: false, description: 'Caption for the media.' },
      ],
      notes: [
         'The system will automatically detect the file type (image/video).',
      ],
      curlExample: `curl -X POST '__BASE_URL__/v1/media' \\
  --header 'x-neoxr-token: __YOUR_TOKEN__' \\
  --header 'Content-Type: application/json' \\
  --data-raw '{
    "number": "6281234567890",
    "url": "https://i.imgur.com/example.jpeg",
    "caption": "This is an image caption."
  }'`
   },
   {
      id: 'send-voice',
      title: 'Send Voice Note',
      method: 'POST',
      methodColor: 'success',
      path: '/v1/voice',
      description: 'Sends an audio file as a voice note (Push-to-Talk).',
      parameters: [
         { name: 'number', type: 'string', required: true, description: 'Recipient WhatsApp number.' },
         { name: 'url', type: 'string', required: true, description: 'Publicly accessible URL of the audio file (e.g., .mp3, .ogg).' },
      ],
      notes: [
         'The audio will be sent as if it were recorded and sent by the user (PTT).'
      ],
      curlExample: `curl -X POST '__BASE_URL__/v1/voice' \\
  --header 'x-neoxr-token: __YOUR_TOKEN__' \\
  --header 'Content-Type: application/json' \\
  --data-raw '{
    "number": "6281234567890",
    "url": "https://example.com/audio.mp3"
  }'`
   },
   {
      id: 'send-file',
      title: 'Send File/Document',
      method: 'POST',
      methodColor: 'success',
      path: '/v1/file',
      description: 'Sends a file as a document attachment.',
      parameters: [
         { name: 'number', type: 'string', required: true, description: 'Recipient WhatsApp number.' },
         { name: 'url', type: 'string', required: true, description: 'Publicly accessible URL of the file.' },
         { name: 'filename', type: 'string', required: true, description: 'The name of the file with its extension (e.g., "report.pdf").' },
         { name: 'caption', type: 'string', required: false, description: 'A short description sent with the document.' },
      ],
      notes: [],
      curlExample: `curl -X POST '__BASE_URL__/v1/file' \\
  --header 'x-neoxr-token: __YOUR_TOKEN__' \\
  --header 'Content-Type: application/json' \\
  --data-raw '{
    "number": "6281234567890",
    "url": "https://example.com/document.pdf",
    "filename": "monthly_report.pdf",
    "caption": "Here is the report you requested."
  }'`
   },
   {
      id: 'send-button',
      title: 'Send Button Message',
      method: 'POST',
      methodColor: 'warning',
      path: '/v1/button',
      description: 'Sends a message with interactive buttons. This feature is not available for WhatsApp Business accounts.',
      parameters: [
         { name: 'number', type: 'string', required: true, description: 'Recipient WhatsApp number.' },
         { name: 'text', type: 'string', required: true, description: 'The main text content of the message.' },
         { name: 'button', type: 'string', required: true, description: 'A JSON string representing an array of button objects.' },
         { name: 'media', type: 'string', required: false, description: 'URL for an image to be displayed above the text.' },
      ],
      notes: [
         'The <code>button</code> parameter must be a valid JSON string.',
         'Example for <code>button</code> parameter: <code>\'[{"text": "Show Runtime", "command": ".runtime"}, {"text": "Check Stats", "command": ".stat"}]\'</code>.',
         'A maximum of 2 buttons is allowed.',
         'This feature does not work for WhatsApp Business accounts.',
      ],
      curlExample: `curl -X POST '__BASE_URL__/v1/button' \\
  --header 'x-neoxr-token: __YOUR_TOKEN__' \\
  --header 'Content-Type: application/json' \\
  --data-raw '{
    "number": "6281234567890",
    "text": "Please select an option:",
    "button": "[{\\"text\\":\\"Option A\\",\\"command\\":\\".option-a\\"},{\\"text\\":\\"Option B\\",\\"command\\":\\".option-b\\"}]"
  }'`
   },
])

onMounted(async () => {
   let tokenForCurl = 'YOUR_TOKEN' // Default value if fetch fails

   try {
      const response = await $api('/data/token-auth')
      if (response && response.status && response.data && response.data.token) {
         apiToken.value = response.data.token
         tokenForCurl = response.data.token
      } else {
         apiToken.value = 'Failed to load token.'
         console.error('Invalid response from token API:', response)
      }
   } catch (error) {
      console.error('Error fetching API token:', error)
      apiToken.value = 'Failed to load token due to an error.'
   }

   const baseUrl = window.location.origin

   endpoints.value = endpoints.value.map(endpoint => {
      return {
         ...endpoint,
         curlExample: endpoint.curlExample
            .replace(/__BASE_URL__/g, baseUrl)
            .replace(/__YOUR_TOKEN__/g, tokenForCurl)
      }
   })

   nextTick(() => {
      Prism.highlightAll()
   })
})
</script>

<style>
pre[class*="language-"] {
   margin: 0;
   border-radius: 0.375rem;
   /* Match Bootstrap's border-radius */
   border: 1px solid #343a40;
}

.code-container .btn-copy {
   position: absolute;
   top: 0.5rem;
   right: 0.5rem;
   opacity: 0.7;
   transition: opacity 0.2s ease-in-out;
}

.code-container:hover .btn-copy {
   opacity: 1;
}
</style>