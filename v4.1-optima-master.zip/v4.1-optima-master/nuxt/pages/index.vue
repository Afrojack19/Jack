<template>
   <div>
      <header>
         <div class="container px-4 px-lg-5">
            <div class="row gx-5 align-items-center justify-content-center">
               <div class="col-lg-8 col-xl-7 col-xxl-6">
                  <div class="my-5 text-center text-xl-start">
                     <h1 class="display-5 fw-bolder text-dark mb-2">Reliable WhatsApp API Gateway for Your Business</h1>
                     <p class="lead fw-normal text-dark-50 mb-4">The complete solution for WhatsApp API
                        integration. Send notifications, broadcasts, and build chatbots with ease and reliability.</p>
                     <div class="d-grid gap-3 d-sm-flex justify-content-sm-center justify-content-xl-start">
                        <button class="btn btn-success btn-lg px-4" @click.prevent="navigate.login">Login</button>
                     </div>
                  </div>
               </div>
               <div class="col-xl-5 col-xxl-6 d-none d-xl-block text-center">
                  <img class="img-fluid rounded-3" src="https://qu.ax/TKUha.png" alt="WhatsApp Gateway Illustration">
               </div>
            </div>
         </div>
      </header>

      <section class="py-4 py-lg-5" id="features">
         <div class="container px-4 px-lg-5">
            <div class="text-center mb-5">
               <h2 class="fw-bolder">Why Choose Our Gateway?</h2>
               <p class="lead fw-normal text-muted mb-0">Powerful features for all your business communication needs.</p>
            </div>
            <div class="row gx-5">
               <!-- Using v-for to create 6 feature boxes with BoxIcons -->
               <div class="col-lg-4 col-md-6 mb-4" v-for="feature in features" :key="feature.title">
                  <div class="card h-100 shadow border-0">
                     <div class="card-body p-4 text-center">
                        <div class="feature bg-success bg-gradient text-white rounded-3 mb-4 mt-4 mx-auto"
                           style="width: 4rem; height: 4rem; line-height: 4rem;">
                           <i :class="feature.icon" style="font-size: 2rem;"></i>
                        </div>
                        <h5 class="card-title fw-bolder">{{ feature.title }}</h5>
                        <p class="card-text text-muted py-3">{{ feature.description }}</p>
                     </div>
                  </div>
               </div>
            </div>
         </div>
      </section>

   </div>
</template>

<script setup lang="ts">
import { ref } from 'vue'
import { useHead } from '#imports'

const features = ref([
   {
      icon: 'bx bx-code-alt',
      title: 'Complete REST API',
      description: 'Easily integrate with your existing systems using our clear API documentation and ready-to-use code examples.'
   },
   {
      icon: 'bx bx-rocket',
      title: 'Fast & Reliable Delivery',
      description: 'Our robust infrastructure ensures your messages are delivered instantly with a high success rate.'
   },
   {
      icon: 'bx bx-qr-scan',
      title: 'Stable Connection',
      description: 'Scan the QR code just once. Your WhatsApp account stays connected and ready to use 24/7, no re-scans needed.'
   },
   {
      icon: 'bx bx-bot',
      title: 'Broadcast & Automation',
      description: 'Send bulk messages to your contact lists or create automated reply flows to improve your efficiency.'
   },
   {
      icon: 'bx bx-bar-chart-alt-2',
      title: 'Intuitive Dashboard',
      description: 'Monitor delivery status, view message history, and manage your connected devices from one easy-to-use dashboard.'
   },
   {
      icon: 'bx bx-devices',
      title: 'Multi-Device Support',
      description: 'Connect multiple WhatsApp numbers to a single account and manage them all from one centralized platform.'
   }
])

const navigate = {
   login: () => window.location.href = '/auth/login',
}

</script>

<style>
.feature {
   display: inline-flex;
   align-items: center;
   justify-content: center;
}
</style>