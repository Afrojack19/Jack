import { useCookie } from '#app'
import { defineNuxtRouteMiddleware, navigateTo } from '#imports'

export default defineNuxtRouteMiddleware((to, from) => {
   if (!process.client) {
      return
   }

   const session = useCookie<{ token: string, type: string } | null>('session_token')
   const token = session.value?.token
   const type = session.value?.type

   if (to.path.startsWith('/dashboard')) {
      if (!token) {
         return window.location.href = '/auth/login'
      }
   }

   if (to.path.startsWith('/auth')) {
      if (token) {
         if (String(type) != '1' && to.path.startsWith('/dashboard/sessions')) {
            return window.location.href = '/dashboard'
         }
         return window.location.href = '/dashboard'
      }
   }
})