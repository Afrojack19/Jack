export default defineNuxtConfig({
   devtools: { enabled: false },
   vue: {
      compilerOptions: {
         isCustomElement: tag => tag === 'iconify-icon'
      }
   },
   vite: {
      server: {
         allowedHosts: true
      }
   },
   css: [
      '~/assets/css/app.min.css',
      '~/assets/css/vendor.min.css'
   ],
   app: {
      head: {
         title: 'WhatsApp Gateway - Send Automated & Bulk Messages',
         titleTemplate: '%s - WhatsApp Gateway',
         htmlAttrs: {
            lang: 'en',
            'data-bs-theme': 'light',
            'data-menu-color': 'dark',
            'data-topbar-color': 'light'
         },
         meta: [
            { name: 'viewport', content: 'width=device-width, initial-scale=1.0' },
            { name: 'author', content: 'Wildan Izzudin' },
            { name: 'description', content: 'A reliable WhatsApp Gateway API solution for sending notifications, broadcasts, and building chatbots. Easy integration, fast delivery, and a complete dashboard' }
         ],
         link: [
            { rel: 'stylesheet', href: 'https://cdn.jsdelivr.net/npm/boxicons@2.1.4/css/boxicons.min.css', type: 'text/css' },
            { rel: 'stylesheet', href: 'https://cdn.jsdelivr.net/npm/gridjs@6.2.0/dist/theme/mermaid.min.css', type: 'text/css' },
            { rel: 'stylesheet', href: '/css/gridjs.override.css', type: 'text/css' },
            { rel: 'stylesheet', href: '/css/override.css', type: 'text/css' }
         ],
         script: [
            { src: 'https://cdn.jsdelivr.net/npm/simplebar@6.3.1/dist/simplebar.min.js', type: 'text/javascript', defer: true },
            { src: 'https://cdn.jsdelivr.net/npm/gridjs@6.2.0/dist/gridjs.production.min.js', type: 'text/javascript', defer: true },
            { src: '/js/app.js', type: 'text/javascript', defer: true },
            { src: '/js/vendor.js', type: 'text/javascript', defer: true },
            { src: '/js/iconify.js', type: 'text/javascript', defer: true },
         ]
      }
   },
   runtimeConfig: {
      session_expires: 3 * 24 * 60 * 60,
      public: {
         baseURL: 'https://your-site.com'
      }
   }
})