<template>
   <div v-if="!loading && type" class="row">
      <div :class="columnClass" v-for="(card, index) in cardStats" :key="index">
         <div class="card">
            <div class="card-body">
               <div class="row">
                  <div class="col-6">
                     <div class="avatar-md bg-light bg-opacity-50 rounded">
                        <iconify-icon :icon="card.icon" class="fs-32 text-success avatar-title"></iconify-icon>
                     </div>
                  </div>
                  <div class="col-6 text-end">
                     <p class="text-muted mb-0 text-truncate">{{ card.title }}</p>
                     <h3 class="text-dark mt-1 mb-0">{{ card.mainStat }}</h3>
                  </div>
               </div>
            </div>
            <div class="card-footer border-0 py-2 bg-light bg-opacity-50">
               <div class="d-flex align-items-center justify-content-between">
                  <div v-if="card.footerText">
                     <span class="text-success">{{ card.footerStat }}</span>
                     <span class="text-muted ms-1 fs-12">{{ card.footerText }}</span>
                  </div>
                  <div v-else></div>
                  <a @click="$router.push(card.link)" class="text-reset fw-semibold fs-12">View More</a>
               </div>
            </div>
         </div>
      </div>
   </div>

   <div v-else class="text-center py-5">
      <p>Loading stats...</p>
   </div>
</template>

<script setup lang="ts">
import { ref, onMounted, computed } from 'vue'
import { useNuxtApp } from '#imports'
import { useAuth } from '~/composables/useAuth'

const { type } = useAuth()

const users = ref<{ premium: number, banned: number, total: number } | null>(null)
const groups = ref<{ rental: number, total: number } | null>(null)
const chats = ref<{ total: number } | null>(null)
const bots = ref<{ connected: number , total: number } | null>(null)

const loading = ref(true)
const { $api } = useNuxtApp()

const cardStats = computed(() => {
   const stats = [{
      title: 'Users',
      icon: 'solar:users-group-rounded-bold-duotone',
      mainStat: users.value?.total || 0,
      footerStat: users.value?.premium || 0,
      footerText: 'Premium Users',
      link: '/dashboard/users'
   }, {
      title: 'Groups',
      icon: 'solar:users-group-two-rounded-bold-duotone',
      mainStat: groups.value?.total || 0,
      footerStat: groups.value?.rental || 0,
      footerText: 'Groups Rent',
      link: '/dashboard/groups'
   }, {
      title: 'Chats',
      icon: 'solar:chat-round-bold-duotone',
      mainStat: chats.value?.total || 0,
      footerStat: null,
      footerText: '',
      link: '/dashboard/chats'
   }]

   if (String(type.value) === '1') {
      stats.push({
         title: 'Sessions',
         icon: 'solar:layers-bold-duotone',
         mainStat: bots.value?.total || 0,
         footerStat: bots.value?.connected || 0,
         footerText: 'Session Connected',
         link: '/dashboard/sessions'
      })
   }

   return stats
})

const columnClass = computed(() => {
   return cardStats.value.length === 3 ? 'col-md-6 col-xl-4' : 'col-md-6 col-xl-3'
})

onMounted(async () => {
   try {
      loading.value = true
      const json = await $api('/data/all')
      if (!json.status) return
      users.value = json.data.users
      groups.value = json.data.groups
      chats.value = json.data.chats
      bots.value = json.data.bots
   } catch (err) {
      console.error('Gagal mengambil statistik:', err)
   } finally {
      loading.value = false
   }
})
</script>