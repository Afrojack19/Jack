<template>
   <ul class="navbar-nav" id="navbar-nav">

      <li class="menu-title">Menu</li>

      <li class="nav-item">
         <a class="nav-link">
            <span class="nav-icon">
               <iconify-icon icon="solar:home-2-broken"></iconify-icon>
            </span>
            <span class="nav-text" @click.prevent="$router.push('/dashboard')"> Dashboard </span>
         </a>
      </li>

      <li class="nav-item">
         <a class="nav-link menu-arrow" href="#sidebarDatabase" data-bs-toggle="collapse" role="button"
            aria-expanded="false" aria-controls="sidebarDatabase">
            <span class="nav-icon">
               <iconify-icon icon="solar:database-broken"></iconify-icon>
            </span>
            <span class="nav-text"> Database </span>
         </a>
         <div class="collapse" id="sidebarDatabase">
            <ul class="nav sub-navbar-nav">
               <li class="sub-nav-item">
                  <a class="sub-nav-link" @click.prevent="$router.push('/dashboard/users')">Users</a>
               </li>
               <li class="sub-nav-item">
                  <a class="sub-nav-link" @click.prevent="$router.push('/dashboard/groups')">Groups</a>
               </li>
               <li class="sub-nav-item">
                  <a class="sub-nav-link" @click.prevent="$router.push('/dashboard/chats')">Chats</a>
               </li>
               <li class="sub-nav-item" v-if="String(type) === '1'">
                  <a class="sub-nav-link" @click.prevent="$router.push('/dashboard/sessions')">
                     <span class="nav-text">Sessions</span>
                     <span class="badge badge-soft-success badge-pill text-end">Bot</span>
                  </a>
               </li>
            </ul>
         </div>
      </li>

      <li class="nav-item">
         <a class="nav-link" @click.prevent="$router.push('/dashboard/setting')">
            <span class="nav-icon">
               <iconify-icon icon="solar:settings-broken"></iconify-icon>
            </span>
            <span class="nav-text"> Settings </span>
         </a>
      </li>

      <li class="menu-title">Gateway</li>

      <li class="nav-item">
         <a class="nav-link" @click.prevent="$router.push('/dashboard/documentation')">
            <span class="nav-icon">
               <iconify-icon icon="solar:book-broken"></iconify-icon>
            </span>
            <span class="nav-text"> Documentation </span>
         </a>
      </li>

      <li class="menu-title">Others</li>

      <li class="nav-item">
         <a class="nav-link" href="javascript:void(0);">
            <span class="nav-icon">
               <iconify-icon icon="solar:logout-broken"></iconify-icon>
            </span>
            <span class="nav-text" @click.prevent="logout"> Logout </span>
         </a>
      </li>
   </ul>
</template>

<script setup lang="ts">
import { useNuxtApp } from '#imports'
import { useAuth } from '~/composables/useAuth'
const { clearAuth, type } = useAuth() 

const { $api } = useNuxtApp()


const logout = async () => {
   try {
      await $api('/action/logout', {
         method: 'POST',
         body: {}
      })
      clearAuth()
      window.location.href = '/auth/login'
   } catch (err) {
      console.error('Gagal logout:', err)
   }
}
</script>