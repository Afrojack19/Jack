<template>
   <transition name="fade">
      <div v-if="show" class="preloader-overlay">
         <div class="line-loader">
         </div>
      </div>
   </transition>
</template>

<script setup lang="ts">
import { ref, onMounted, onBeforeUnmount } from 'vue'

const show = ref(true)
let timer: ReturnType<typeof setTimeout> | null = null

onMounted(() => {
   timer = setTimeout(() => {
      show.value = false
   }, 2000)
})

onBeforeUnmount(() => {
   if (timer) {
      clearTimeout(timer)
   }
})
</script>