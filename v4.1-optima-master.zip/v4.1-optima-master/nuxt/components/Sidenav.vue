<template>
   <div class="main-nav">
      <div class="logo-box">
         <a @click.prevent="homepage" class="logo-dark">
            <img src="assets/images/logo-sm.png" class="logo-sm" alt="logo sm">
            <img src="assets/images/logo-dark.png" class="logo-lg" alt="logo dark">
         </a>

         <a @click.prevent="homepage" class="logo-light">
            <img src="assets/images/logo-sm.png" class="logo-sm" alt="logo sm">
            <img src="assets/images/logo-light.png" class="logo-lg" alt="logo light">
         </a>
      </div>

      <button type="button" class="button-sm-hover" aria-label="Show Full Sidebar">
         <iconify-icon icon="solar:hamburger-menu-broken" class="button-sm-hover-icon"></iconify-icon>
      </button>

      <ClientOnly>
         <template #fallback>
            <div class="scrollbar" style="max-height: 100vh; overflow-y: auto;">
               <Menu />
            </div>
         </template>

         <div class="scrollbar" data-simplebar style="max-height: 100vh;">
            <Menu />
         </div>
      </ClientOnly>
   </div>
</template>

<script setup lang="ts">
const homepage = () => window.location.href ='/'
</script>