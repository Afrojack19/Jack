<template>
   <footer class="footer">
      <div class="container-fluid">
         <div class="row">
            <div class="col-12 text-center">Crafted by <iconify-icon icon="iconamoon:heart-duotone"
                  class="fs-18 align-middle text-danger"></iconify-icon>&nbsp;<a href="https://neoxr.my.id" class="fw-bold footer-text" target="_blank"> Neoxr
                  Creative </a>
            </div>
         </div>
      </div>
   </footer>
</template>