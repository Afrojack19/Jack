<template>
   <span class="spinner-border" :class="[sizeClass, marginClass]" role="status" aria-hidden="true" />
</template>

<script setup lang="ts">
import { computed } from 'vue'

const props = defineProps<{
   size?: 'sm' | 'md' | 'lg'
   margin?: string
}>()

const sizeClass = computed(() => {
   switch (props.size) {
      case 'lg': return 'spinner-border-lg'
      case 'md': return ''
      case 'sm':
      default: return 'spinner-border-sm'
   }
})

const marginClass = computed(() => props.margin || 'me-1')
</script>