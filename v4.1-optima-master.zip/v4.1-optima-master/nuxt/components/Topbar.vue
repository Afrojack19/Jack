<template>
   <header class="topbar">
      <div class="container-fluid">
         <div class="navbar-header">
            <div class="d-flex align-items-center gap-2">
               <!-- Menu Toggle Button -->
               <div class="topbar-item">
                  <button type="button" class="button-toggle-menu topbar-button">
                     <iconify-icon icon="solar:hamburger-menu-broken" class="fs-24 align-middle"></iconify-icon>
                  </button>
               </div>
            </div>

            <div class="d-flex align-items-center gap-1">
               <!-- Theme Color (Light/Dark) -->
               <div class="topbar-item">
                  <button type="button" class="topbar-button" id="light-dark-mode">
                     <iconify-icon icon="solar:moon-broken" class="fs-24 align-middle light-mode"></iconify-icon>
                     <iconify-icon icon="solar:sun-broken" class="fs-24 align-middle dark-mode"></iconify-icon>
                  </button>
               </div>

               <!-- Category -->
               <div class="dropdown topbar-item d-lg-flex">
                  <button type="button" class="topbar-button" data-toggle="fullscreen">
                     <iconify-icon icon="solar:full-screen-broken" class="fs-24 align-middle fullscreen"></iconify-icon>
                     <iconify-icon icon="solar:quit-full-screen-broken"
                        class="fs-24 align-middle quit-fullscreen"></iconify-icon>
                  </button>
               </div>

               <!-- Theme Setting -->
               <div class="topbar-item d-none d-md-flex">
                  <button type="button" class="topbar-button" id="theme-settings-btn" data-bs-toggle="offcanvas"
                     data-bs-target="#theme-settings-offcanvas" aria-controls="theme-settings-offcanvas">
                     <iconify-icon icon="solar:settings-broken" class="fs-24 align-middle"></iconify-icon>
                  </button>
               </div>

               <!-- User -->
               <div class="dropdown topbar-item">
                  <a type="button" class="topbar-button" id="page-header-user-dropdown" data-bs-toggle="dropdown"
                     aria-haspopup="true" aria-expanded="false">
                     <ClientOnly>
                        <span class="d-flex align-items-center">
                           <img class="rounded-circle" width="32" :src="profilePicture" alt="User Avatar">
                        </span>
                        <template #fallback>
                           <span class="d-flex align-items-center">
                              <div class="rounded-circle bg-secondary" style="width: 32px; height: 32px;"></div>
                           </span>
                        </template>
                     </ClientOnly>
                  </a>
               </div>
            </div>
         </div>
      </div>
   </header>

   <!-- Right Sidebar (Theme Settings) -->
   <div>
      <div class="offcanvas offcanvas-end border-0" tabindex="-1" id="theme-settings-offcanvas">
         <div class="d-flex align-items-center bg-primary p-3 offcanvas-header">
            <h5 class="text-white m-0">Theme Settings</h5>
            <button type="button" class="btn-close btn-close-white ms-auto" data-bs-dismiss="offcanvas"
               aria-label="Close"></button>
         </div>

         <div class="offcanvas-body p-0">
            <div data-simplebar class="h-100">
               <div class="p-3 settings-bar">

                  <div>
                     <h5 class="mb-3 font-16 fw-semibold">Color Scheme</h5>

                     <div class="form-check mb-2">
                        <input class="form-check-input" type="radio" name="data-bs-theme" id="layout-color-light"
                           value="light">
                        <label class="form-check-label" for="layout-color-light">Light</label>
                     </div>

                     <div class="form-check mb-2">
                        <input class="form-check-input" type="radio" name="data-bs-theme" id="layout-color-dark"
                           value="dark">
                        <label class="form-check-label" for="layout-color-dark">Dark</label>
                     </div>
                  </div>

                  <div>
                     <h5 class="my-3 font-16 fw-semibold">Topbar Color</h5>

                     <div class="form-check mb-2">
                        <input class="form-check-input" type="radio" name="data-topbar-color" id="topbar-color-light"
                           value="light">
                        <label class="form-check-label" for="topbar-color-light">Light</label>
                     </div>
                     <div class="form-check mb-2">
                        <input class="form-check-input" type="radio" name="data-topbar-color" id="topbar-color-dark"
                           value="dark">
                        <label class="form-check-label" for="topbar-color-dark">Dark</label>
                     </div>
                  </div>


                  <div>
                     <h5 class="my-3 font-16 fw-semibold">Menu Color</h5>

                     <div class="form-check mb-2">
                        <input class="form-check-input" type="radio" name="data-menu-color" id="leftbar-color-light"
                           value="light">
                        <label class="form-check-label" for="leftbar-color-light">
                           Light
                        </label>
                     </div>

                     <div class="form-check mb-2">
                        <input class="form-check-input" type="radio" name="data-menu-color" id="leftbar-color-dark"
                           value="dark">
                        <label class="form-check-label" for="leftbar-color-dark">
                           Dark
                        </label>
                     </div>
                  </div>

                  <div>
                     <h5 class="my-3 font-16 fw-semibold">Sidebar Size</h5>

                     <div class="form-check mb-2">
                        <input class="form-check-input" type="radio" name="data-menu-size" id="leftbar-size-default"
                           value="default">
                        <label class="form-check-label" for="leftbar-size-default">
                           Default
                        </label>
                     </div>

                     <div class="form-check mb-2">
                        <input class="form-check-input" type="radio" name="data-menu-size" id="leftbar-size-small"
                           value="condensed">
                        <label class="form-check-label" for="leftbar-size-small">
                           Condensed
                        </label>
                     </div>

                     <div class="form-check mb-2">
                        <input class="form-check-input" type="radio" name="data-menu-size" id="leftbar-hidden"
                           value="hidden">
                        <label class="form-check-label" for="leftbar-hidden">
                           Hidden
                        </label>
                     </div>

                     <div class="form-check mb-2">
                        <input class="form-check-input" type="radio" name="data-menu-size"
                           id="leftbar-size-small-hover-active" value="sm-hover-active">
                        <label class="form-check-label" for="leftbar-size-small-hover-active">
                           Small Hover Active
                        </label>
                     </div>

                     <div class="form-check mb-2">
                        <input class="form-check-input" type="radio" name="data-menu-size" id="leftbar-size-small-hover"
                           value="sm-hover">
                        <label class="form-check-label" for="leftbar-size-small-hover">
                           Small Hover
                        </label>
                     </div>
                  </div>

               </div>
            </div>
         </div>
         <div class="offcanvas-footer border-top p-3 text-center">
            <div class="row">
               <div class="col">
                  <button type="button" class="btn btn-danger w-100" id="reset-layout">Reset</button>
               </div>
            </div>
         </div>
      </div>
   </div>
</template>

<script setup lang="ts">
import { onMounted, computed } from 'vue'
import { useAuth } from '~/composables/useAuth'

const { avatar } = useAuth()

const profilePicture = computed(() => avatar.value)

onMounted(async () => {
   const fullScreenBtn = document.querySelector('[data-toggle="fullscreen"]')
   if (fullScreenBtn) {
      fullScreenBtn.addEventListener('click', (e) => {
         e.preventDefault()
         document.body.classList.toggle('fullscreen-enable')

         const docEl = document.documentElement

         if (
            !document.fullscreenElement &&
            !(document as any).mozFullScreenElement &&
            !(document as any).webkitFullscreenElement
         ) {
            if (docEl.requestFullscreen) {
               docEl.requestFullscreen()
            } else if ((docEl as any).mozRequestFullScreen) {
               (docEl as any).mozRequestFullScreen()
            } else if ((docEl as any).webkitRequestFullscreen) {
               (docEl as any).webkitRequestFullscreen((Element as any).ALLOW_KEYBOARD_INPUT)
            }
         } else {
            if ((document as any).cancelFullScreen) {
               (document as any).cancelFullScreen()
            } else if ((document as any).mozCancelFullScreen) {
               (document as any).mozCancelFullScreen()
            } else if ((document as any).webkitCancelFullScreen) {
               (document as any).webkitCancelFullScreen()
            }
         }
      })
   }
})
</script>