<template>
   <NuxtLayout />
</template>

<style>
.swal2-popup {
   background-color: var(--bs-secondary-bg);
   border-radius: .25rem
}

.swal2-popup .swal2-title {
   font-weight: 500;
   font-size: 1.3rem;
   color: var(--bs-dark)
}

.swal2-popup .swal2-content,
.swal2-popup .swal2-html-container {
   font-weight: 400;
   font-size: 1.1rem;
   margin-top: 1.5rem;
   color: var(--bs-tertiary-color)
}

.swal2-popup .swal2-footer {
   border-top-color: var(--bs-border-color) !important
}

.swal2-popup .btn {
   margin: 15px 5px 0
}

.swal2-popup .swal2-styled:focus {
   -webkit-box-shadow: none;
   box-shadow: none
}

.swal2-popup .swal2-actions {
   margin: 1.5rem auto 1rem auto
}

.swal2-container.swal2-shown {
   background-color: var(--bs-tertiary-color);
   opacity: .5
}

.swal2-container .swal2-html-container {
   max-height: 200px;
   overflow: auto
}

.swal2-icon.swal2-warning {
   border-color: #f8ac59;
   color: #f8ac59
}

.swal2-icon.swal2-error {
   border-color: #ed5565;
   color: #ed5565
}

.swal2-icon.swal2-error [class^=swal2-x-mark-line] {
   background-color: rgba(237, 85, 101, .75)
}

.swal2-icon.swal2-success {
   border-color: #1bb394;
   color: #1bb394
}

.swal2-icon.swal2-success [class^=swal2-success-line] {
   background-color: #1bb394
}

.swal2-icon.swal2-success .swal2-success-ring {
   border-color: rgba(27, 179, 148, .3)
}

.swal2-icon.swal2-info {
   border-color: #23c6c8;
   color: #23c6c8
}

.swal2-icon.swal2-question {
   border-color: #1e84c4;
   color: #1e84c4
}

.preloader-overlay {
   position: fixed;
   top: 0;
   left: 0;
   right: 0;
   bottom: 0;
   z-index: 9999;
   background-color: var(--bs-body-bg);
   display: flex;
   align-items: center;
   justify-content: center;
}

.line-loader {
   position: relative;
   width: 250px;
   height: 4px;
   border-radius: 2px;
   background-color: var(--bs-secondary-bg-subtle);
   overflow: hidden;
}

.line-loader::before {
   content: '';
   position: absolute;
   top: 0;
   left: 0;
   width: 100px;
   height: 100%;
   background-color: var(--bs-body-color);
   border-radius: 2px;
   animation: ping-pong-effect 2s ease-in-out infinite;
}

@keyframes ping-pong-effect {
   0% {
      transform: translateX(0px);
   }
   50% {
      transform: translateX(150px);
   }
   100% {
      transform: translateX(0px);
   }
}

.fade-leave-active {
   transition: opacity 0.5s ease-out;
}

.fade-leave-to {
   opacity: 0;
}

.form-check-label {
   cursor: pointer;
}

.badge .btn-close {
   padding: 0.1em;
   line-height: 1;
}
</style>