> [!CAUTION]
> Pelanggaran hak cipta apabila kedapatan **menjual / menyebarkan / membagikan** script ini secara sebagian (per plugin) atau secara keseluruhan **Free Update** akan dihapus tanpa ada pemberitahuan dan tanpa adanya refund.

> [!NOTE]
> Untuk menghindari laporan berulang terkait problem/error, harap buat issue di repository ini. Tujuan dari issue tracking adalah agar ketika suatu masalah telah diperbaiki, pengguna lain tidak perlu menghubungi kreator secara langsung. Cukup dengan melihat closed issues untuk menemukan solusinya dengan lebih efisien.

# BIG UPDATES HISTORY

1. Bot Hosting (13/01/2025) - Finish
2. RPG Games (20/04/2025) - On Process
3. WhatsApp Gateway Intregared (14/06/2025) - Finish

# DOCUMENTATION

> Here : [ID](https://github.com/neoxr/v4.1-optima/blob/master/ID.md) | [EN](https://github.com/neoxr/v4.1-optima/blob/master/EN.md)