exports.run = {
   usage: ['add', 'promote', 'demote', 'kick'],
   use: 'mention or reply',
   category: 'admin tools',
   async: async (m, {
      client,
      text,
      command,
      participants,
      Func
   }) => {
      try {
         const input = m?.mentionedJid?.[0] || m?.quoted?.sender || text
         if (!input) return client.reply(m.chat, Func.texted('bold', `🚩 Mention or reply chat target.`), m)
         const p = await client.onWhatsApp(input.trim())
         if (!p.length) return client.reply(m.chat, Func.texted('bold', `🚩 Invalid number.`), m)
         const jid = client.decodeJid(p[0].jid)
         const number = jid.replace(/@.+/, '')
         if (['kick', 'promote', 'demote'].includes(command)) {
            const member = participants.find(u => u.id == jid)
            if (!member) return client.reply(m.chat, Func.texted('bold', `🚩 @${number} already left or does not exist in this group.`), m)
            const [json] = await client.groupParticipantsUpdate(m.chat, [jid], command === 'kick' ? 'remove' : command)
            if (json.status === '200') return m.reply(Func.texted('bold', `✅ @${number} was ${command === 'kick' ? 'removed' : `${command}d`}`))
            m.reply(Func.texted('bold', '❌ Action failed'))
         } else if (command === 'add') {
            // This command may lead to a high risk of your account being banned by WhatsApp.
            const member = participants.find(u => u.id == jid)
            if (member) return client.reply(m.chat, Func.texted('bold', `🚩 @${number} already in this group.`), m)
            const [json] = await client.groupParticipantsUpdate(m.chat, [jid], command)
            if (json.status === '200') return m.reply(Func.texted('bold', `✅ @${number} was successfully added.`))
            m.reply(Func.texted('bold', '❌ Action failed'))
         }
      } catch (e) {
         console.log(e)
         m.reply(Func.texted('bold', '❌ Error'))
      }
   },
   group: true,
   admin: true,
   botAdmin: true
}