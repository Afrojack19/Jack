const { request } = require('undici')

exports.run = {
   usage: ['fetch'],
   hidden: ['get'],
   use: 'link',
   category: 'downloader',
   async: async (m, {
      client,
      args,
      isPrefix,
      command,
      setting,
      env,
      Func
   }) => {
      try {
         if (!args || !args[0]) return client.reply(m.chat, Func.example(isPrefix, command, setting.cover), m)
         client.sendReact(m.chat, '🕒', m.key)

         const parseUrl = url => new URL(args[0])
         const ipv4 = Array(4).fill(0).map(() => Math.floor(Math.random() * 256)).join('.')

         if (args[0].match('github.com')) {
            let username = args[0].split(`/`)[3]
            let repository = args[0].split(`/`)[4]
            let zipball = `https://api.github.com/repos/${username.trim()}/${repository.trim()}/zipball`
            client.sendFile(m.chat, zipball, `${repository}.zip`, '', m)
         } else {
            const { statusCode, headers, body } = await request(args[0], {
               method: 'GET',
               maxRedirections: 5,
               headers: {
                  'Accept-Language': 'en-US,en;q=0.9,id;q=0.8',
                  'Cache-Control': 'no-cache',
                  'Connection': 'Keep-Alive',
                  'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
                  'DNT': '1',
                  'Origin': parseUrl.origin,
                  'Pragma': 'no-cache',
                  'Referer': parseUrl.href,
                  'User-Agent': 'Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36',
                  'X-Requested-With': 'XMLHttpRequest',
                  'X-Forwarded-For': ipv4,
                  'X-Real-IP': ipv4,
                  'X-CF-Connecting-IP': ipv4,
                  'X-CF-Proxy-Signature': '1',
                  'X-CF-Visitor': `{"scheme":"https","ip":"${ipv4}","port":"443"}`,
                  'X-CF-Request-ID': '1',
                  'X-CF-Ray': Func.makeId(13),
                  'X-Amz-Cf-Id': '1',
                  'X-Amz-User-Agent': 'Mozilla/5.0 (X11; CrOS x86_64 14541.0.0) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/126.0.0.0 Safari/537.36'
               }
            })

            if (statusCode !== 200) {
               return client.reply(m.chat, `💀 Failed to fetch, status code: ${statusCode}`, m)
            }

            const size = headers['content-length'] ? Func.formatSize(headers['content-length']) : '1 KB'
            const chSize = Func.sizeLimit(size, env.max_upload)

            if (chSize.oversize) {
               return client.reply(m.chat, `💀 File size (${size}) exceeds the maximum limit, we can't download the file.`, m)
            }

            const data = await body.arrayBuffer()
            const buffer = Buffer.from(data)

            if (/json/i.test(headers['content-type'])) {
               return m.reply(Func.jsonFormat(buffer.toString()))
            }
            if (/text/i.test(headers['content-type'])) {
               return m.reply(buffer.toString())
            }

            client.sendFile(m.chat, buffer, '', '', m)
         }
      } catch (e) {
         console.error(e)
         client.reply(m.chat, `💀 An error occurred: ${e.message}`, m)
      }
   },
   error: false,
   limit: true,
   cache: true,
   location: __filename
}