const fs = require('fs')

exports.run = {
   usage: ['custom1', 'custom2', 'custom3', 'custom4', 'custom5'],
   category: 'example',
   async: async (m, {
      client,
      command,
      Func
   }) => {
      try {
         switch (command) {
            case 'custom1': {
               client.reply(m.chat, 'Hi!', m, Func.newsletter)
            }
               break

            case 'custom2': {
               client.sendFile(m.chat, fs.readFileSync('./media/image/default.jpg'), 'default.jpg', 'Hi!', m, {}, Func.newsletter)
            }
               break

            case 'custom3': {
               client.sendFile(m.chat, fs.readFileSync('./media/image/default.jpg'), 'default.jpg', 'Hi!', m, {
                  document: true
               }, Func.newsletter)
            }
               break

            case 'custom4': {
               client.sendFile(m.chat, fs.readFileSync('./media/song/1.mp3'), '', '', m, {
                  ptt: true
               }, Func.newsletter)
            }
               break

            case 'custom5': {
               client.sendFile(m.chat, fs.readFileSync('./media/song/1.mp3'), '', '', m, {}, Func.newsletter)
            }
               break
         }
      } catch (e) {
         client.reply(m.chat, Func.jsonFormat(e), m)
      }
   },
   error: false,
   cache: true,
   location: __filename
}