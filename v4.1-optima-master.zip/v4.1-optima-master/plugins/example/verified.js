exports.run = {
   usage: ['verified'],
   category: 'example',
   async: async (m, {
      client,
      Func
   }) => {
      try {
         // changes "m" to "Func.verified()"
         client.reply(m.chat, 'Hi!', Func.verified())
      } catch (e) {
         client.reply(m.chat, Func.jsonFormat(e), m)
      }
   },
   error: false,
   cache: true,
   location: __filename
}