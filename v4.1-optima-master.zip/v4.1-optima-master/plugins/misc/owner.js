exports.run = {
   usage: ['owner'],
   category: 'miscs',
   async: async (m, {
      client,
      env,
      hostJid,
      clientJid,
      findJid,
   }) => {
      if (hostJid) {
         client.sendContact(m.chat, [{
            name: env.owner_name,
            number: env.owner,
            about: 'Owner & Creator'
         }], m, {
            org: 'Neoxr Network',
            website: 'https://api.neoxr.my.id',
            email: 'contact@neoxr.my.id'
         })
      } else {
         const fn = findJid.bot(clientJid)
         client.sendContact(m.chat, [{
            name: client.getName(fn.sender),
            number: String(fn.sender.replace(/@.+/, '')),
            about: 'Owner'
         }], m, {
            org: 'Neoxr Network',
            website: 'https://api.neoxr.my.id',
            email: 'contact@neoxr.my.id'
         })
      }
   },
   error: false,
   cache: true,
   location: __filename
}