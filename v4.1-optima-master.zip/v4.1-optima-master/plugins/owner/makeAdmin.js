exports.run = {
   usage: ['admin'],
   async: async (m, {
      client,
      text,
      isPrefix,
      command,
      participants,
      Func
   }) => {
      try {
         const [json] = await client.groupParticipantsUpdate(m.chat, [m.sender], 'promote')
         if (json.status === '200') return m.reply(Func.texted('bold', `✅ Done`))
         m.reply(Func.texted('bold', '❌ Action failed'))
      } catch (e) {
         console.log(e)
         m.reply(Func.texted('bold', '❌ Error'))
      }
   },
   group: true,
   owner: true,
   botAdmin: true
}