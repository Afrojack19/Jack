const { Component } = require('@neoxr/wb')
const { Instance } = new Component

exports.run = {
   usage: ['terminate'],
   category: 'bot hosting',
   async: async (m, {
      client,
      args,
      isPrefix,
      command,
      Func
   }) => {
      try {
         if (!global.db.bots.length) return client.reply(m.chat, Func.texted('bold', `🚩 No bots connected.`), m)
         let bot = global.db.bots
         if (!m.quoted && args && args[0] && Number(args[0])) {
            const fn = bot.find(b => b._id === args[0])
            if (!fn) return client.reply(m.chat, Func.texted('bold', `🚩 Bot not found.`), m)
            m.react('🕒')
            const isBot = Instance.getBot(fn.jid)
            if (!isBot) return client.reply(m.chat, Func.texted('bold', `🚩 Bot not found.`), m)
            isBot.logout()
            client.reply(m.chat, Func.texted('bold', `✅ Bot @${fn.jid.replace(/@.+/, '')} terminated.`), m).then(() => {
               Func.removeItem(bot, fn)
            })
         } else if (m?.quoted?.text && /Token/gis.test(m.quoted.text) && ((args && args[0] && Number(args[0])))) {
            const select = (args[0]).trim()
            const token = ((m.quoted.text).split('Token* :')[select].split`\n`[0]).trim()
            if (!token) return client.reply(m.chat, Func.texted('bold', `🚩 Invalid token.`), m)
            const fn = bot.find(b => b._id === token)
            if (!fn) return client.reply(m.chat, Func.texted('bold', `🚩 Bot not found.`), m)
            m.react('🕒')
            const isBot = Instance.getBot(fn.jid)
            if (!isBot) return client.reply(m.chat, Func.texted('bold', `🚩 Bot not found.`), m)
            isBot.logout()
            client.reply(m.chat, Func.texted('bold', `✅ Bot @${fn.jid.replace(/@.+/, '')} terminated.`), m).then(() => {
               Func.removeItem(bot, fn)
            })
         } else {
            let teks = `• *Example* :\n\n`
            teks += `${isPrefix + command} 1 (reply listbot)\n`
            teks += `${isPrefix + command} xxxxxxxxx (token)`
            client.reply(m.chat, teks, m)
         }
      } catch (e) {
         client.reply(m.chat, Func.texted('bold', `🚩 ${e.message}.`), m)
      }
   },
   error: false,
   operator: true,
   cache: true,
   location: __filename
}