const { Component } = require('@neoxr/wb')
const { Instance } = new Component
const fs = require('fs')
exports.run = {
   usage: ['listbot', 'botinfo', 'logout'],
   category: 'bot hosting',
   async: async (m, {
      client,
      command,
      env,
      Func
   }) => {
      try {
         if (command === 'listbot') {
            global.db.bots = global.db.bots ? global.db.bots : []
            if (!global.db.bots.length) return client.reply(m.chat, Func.texted('bold', `🚩 No bots connected.`), m)
            let pr = `乂  *L I S T B O T*\n\n`
            global.db.bots.map((v, i) => {
               pr += `*${i + 1}. ${Func.maskNumber(client.decodeJid(v.jid).replace(/@.+/, ''))}*\n`
               pr += `◦ *Name* : ${global.db.users.find(x => x.jid === v.jid) ? global.db.users.find(x => x.jid === v.jid).name : 'No Name'}\n`
               pr += `◦ *Last Connect* : ${Func.timeAgo(v.last_connect)}\n`
               pr += `◦ *Connected* : ${v.is_connected ? '✅' : '❌'}\n`
               pr += `◦ *Token* : ${v._id}\n\n`
            }).join('\n\n')
            pr += global.footer
            client.reply(m.chat, pr, m)
         } else if (command === 'botinfo') {
            if (!global.db.bots.length) return client.reply(m.chat, Func.texted('bold', `🚩 No bots connected.`), m)
            const fn = global.db.bots.find(v => v.jid === client.decodeJid(client.user.id))
            if (!fn) return client.reply(m.chat, Func.texted('bold', `🚩 No information for this bot.`), m)
            let pr = `乂  *B O T I N F O*\n\n`
            pr += `   ◦ *JID* : @${fn.jid.replace(/@.+/, '')}\n`
            pr += `   ◦ *Name* : ${global.db.users.find(x => x.jid === fn.jid) ? global.db.users.find(x => x.jid === fn.jid).name : 'No Name'}\n`
            pr += `   ◦ *Last Connect* : ${Func.timeAgo(fn.last_connect)}\n\n`
            pr += global.footer
            client.reply(m.chat, pr, m)
         } else if (command === 'logout') {
            if (!global.db?.bots || !Array.isArray(global.db.bots)) return client.reply(m.chat, Func.texted('bold', `🚩 Bot database not available.`))
            if (!global.db.bots.length) return client.reply(m.chat, Func.texted('bold', `🚩 No bots connected.`), m)
            const fn = global.db.bots.find(v => v.jid === client.decodeJid(client.user.id) || v.sender === m.sender)
            if (!fn || (fn && fn.sender !== m.sender)) return client.reply(m.chat, Func.texted('bold', `🚩 You can't access this feature.`), m)
            const instance = Instance.getBot(fn.jid)
            Func.removeItem(global.db.bots, fn)
            client.reply(m.chat, Func.texted('bold', `✅ Bot disconnected (Logout).`), m).then(() => {
               instance.logout('Logout')
               if (fs.existsSync(`./${env.bot_hosting.session_dir}/${fn.jid.replace(/@.+/, '')}`)) fs.rmSync(`./${env.bot_hosting.session_dir}/${fn.jid.replace(/@.+/, '')}`, {
                  recursive: true,
                  force: true
               })
            })
         }
      } catch (e) {
         client.reply(m.chat, Func.texted('bold', `🚩 ${e.message}.`), m)
      }
   },
   error: false,
   cache: true,
   location: __filename
}