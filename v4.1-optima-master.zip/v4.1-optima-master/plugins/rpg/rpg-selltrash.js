const { USD } = require('lib/system/rpg-utils')

exports.run = {
   usage: ['selltrash'],
   category: 'rpg',
   async: async (m, {
      client,
      players,
      users,
      Func
   }) => {
      try {
         if (!players?.resource?.trash) return m.reply(Func.texted('bold', `🚩 Kamu tidak mempunyai sampah.`))
         const price = 1 * players.resource.trash
         m.reply(`✅ Sampah berhasil terjual dengan harga *${USD.format(price)}*.`).then(() => {
            users.pocket += Number(price)
            players.resource.trash = 0
         })
      } catch (e) {
         client.reply(m.chat, Func.jsonFormat(e), m)
      }
   },
   error: false,
   group: true,
   limit: true,
   game: true,
   cache: true,
   location: __filename
}