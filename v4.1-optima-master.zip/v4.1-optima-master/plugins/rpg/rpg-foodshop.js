const { USD, emoticon, foodsPet } = require('lib/system/rpg-utils')

exports.run = {
   usage: ['foodshop'],
   category: 'rpg',
   async: async (m, {
      client,
      isPrefix,
      Func
   }) => {
      try {
         let text = `乂  *F O O D S H O P*\n\n`
         text += `Daftar makanan Pet (Hewan Peliharaan) yang bisa kamu beli untuk meningkatkan energy.\n\n`
         for (let v of foodsPet) {
            text += `  ◦  ${emoticon(v.name)}  ${Func.ucword(v.name)}\n`
            text += `     - Price : ${USD.format(v.price)}\n`
            text += `     - Energy : +25\n`
            text += `     - For Pet : ${Func.ucword(v.for)}\n\n`
         }
         text += `> Kirim *${isPrefix}buyfood <name> <quantity>* untuk membeli dan *${isPrefix}feed <pet>* untuk memberi makan Pet.`
         m.reply(text)
      } catch (e) {
         client.reply(m.chat, Func.jsonFormat(e), m)
      }
   },
   error: false,
   group: true,
   game: true,
   limit: true,
   cache: true,
   location: __filename
}