const { emoticon } = require('lib/system/rpg-utils')

exports.run = {
   usage: ['crate'],
   category: 'rpg',
   async: async (m, {
      client,
      isPrefix,
      players,
      Func
   }) => {
      try {
         let pr = `乂  *C R A T E*\n\n`
         pr += `Daftar crate yang bisa kamu buka untuk mendapatkan item.\n\n`
         const itemsName = ['legendary', 'mythic', 'common', 'uncommon', 'superior']
         let itemsIndex = 0
         for (let item in players.resource) {
            if (itemsName.includes(item)) {
               itemsIndex += 1
               pr += `  ◦  ${emoticon(item)}  ${Func.ucword(item)} : ${Func.formatter(players.resource[item])}\n`
            }
         }
         pr += `\n> Kirim *${isPrefix}opencrate <crate name>* untuk membuka crate.`
         m.reply(pr.trim())
      } catch (e) {
         m.reply(Func.jsonFormat(e))
      }
   },
   error: false,
   group: true,
   game: true,
   cache: true,
   location: __filename
}