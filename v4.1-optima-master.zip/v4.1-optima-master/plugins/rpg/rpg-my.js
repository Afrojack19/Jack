const fs = require('fs')
const { USD, playerLvl } = require('lib/system/rpg-utils')

exports.run = {
   usage: ['my'],
   category: 'rpg',
   async: async (m, {
      client,
      players,
      users,
      Func
   }) => {
      try {
         try {
            var pic = await client.profilePictureUrl(m.sender, 'image')
            if (!pic) {
               var pic = fs.readFileSync('./media/image/default.jpg')
            }
         } catch (e) {
            var pic = fs.readFileSync('./media/image/default.jpg')
         }
         const clan = global.db?.clans?.find(v => v.leader === m.sender) || global.db?.clans?.find(v => v.request.find(v => v.jid === m.sender && v.state === 'JOINED'))
         let caption = `乂  *P R O F I L E*\n\n`
         caption += `   ◦  *Name* : ${players.name}\n`
         caption += `   ◦  *Pocket* : ${USD.format(users.pocket)}\n`
         caption += `   ◦  *Balance* : ${USD.format(users.balance)}\n`
         caption += `   ◦  *EXP* : ${Func.formatNumber(players.exp)}\n`
         caption += `   ◦  *Agility* : ${Func.formatNumber(players.agility)}\n`
         caption += `   ◦  *Defense* : ${Func.formatNumber(players.defense)}\n`
         caption += `   ◦  *Health* : ${Func.formatNumber(players.health)}%\n`
         caption += `   ◦  *Lucky* : ${Func.formatNumber(players.lucky)}\n`
         caption += `   ◦  *Stamina* : ${Func.formatNumber(players.stamina)}\n`
         caption += `   ◦  *Strength* : ${Func.formatNumber(players.strength)}\n\n`
         caption += `乂  *S T A T S*\n\n`
         caption += `   ◦  *Clan* : ${clan ? Func.ucword(clan.name) : 'N/A'}\n`
         caption += `   ◦  *Berserker*\n`
         caption += `       ▦  Lose : ${players.berserker.lose}x\n`
         caption += `       ▦  Winner : ${players.berserker.winner}x\n`
         caption += `   ◦  *Pet Battle*\n`
         caption += `       ▦  Lose : ${players.petbattle.lose}x\n`
         caption += `       ▦  Winner : ${players.petbattle.winner}x\n`
         caption += `   ◦  *Quest* : ${players.quest.length}\n`
         caption += `   ◦  *Level* : ${playerLvl(players.exp)}\n\n`
         caption += global.footer
         client.sendMessageModify(m.chat, caption, m, {
            largeThumb: true,
            thumbnail: pic
         })
      } catch (e) {
         m.reply(Func.jsonFormat(e))
      }
   },
   error: false,
   group: true,
   game: true,
   cache: true,
   location: __filename
}