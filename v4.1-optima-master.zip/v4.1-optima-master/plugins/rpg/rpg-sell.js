const { USD, fishs, vegetas, animals } = require('lib/system/rpg-utils')

exports.run = {
   usage: ['sell'],
   use: 'item',
   category: 'rpg',
   async: async (m, {
      client,
      text,
      isPrefix,
      command,
      players,
      users,
      Func
   }) => {
      try {
         players.inventory.fishing = players.inventory.fishing ? players.inventory.fishing : []
         players.inventory.farming = players.inventory.farming ? players.inventory.farming : []
         players.inventory.hunting = players.inventory.hunting ? players.inventory.hunting : []
         if (!text) return m.reply(Func.example(isPrefix, command, 'kepiting'))
         const item = text.toLowerCase()
         if (fishs.price.map(v => v.name).includes(item) && players.inventory.fishing.length < 1) return m.reply(`⚠️ Kolam kosong, tidak ada ikan untuk dijual.\n\n> Kirim *${isPrefix}fishing* untuk memancing.`)
         if (vegetas.price.map(v => v.name).includes(item) && players.inventory.farming.length < 1) return m.reply(`⚠️ Gudang kosong, tidak ada buah untuk dijual.\n\n> Kirim *${isPrefix}farming* untuk bertani.`)
         if (animals.price.map(v => v.name).includes(item) && players.inventory.hunting.length < 1) return m.reply(`⚠️ Kandang kosong, tidak ada hewan untuk dijual.\n\n> Kirim *${isPrefix}hunting* untuk berburu.`)
         const items = players.inventory.fishing.concat(players.inventory.farming).concat(players.inventory.hunting).find(v => v.name == item)
         if (!items) return m.reply(Func.texted('bold', `🚩 Item tidak ada.`))
         if (items.count < 1) return m.reply(Func.texted('italic', `🚩 Maaf, kamu tidak mempunyai ${Func.ucword(items.name)}.`))
         const fromItems = fishs.price.concat(vegetas.price).concat(animals.price).find(v => v.name === item)
         m.reply(`✅ Berhasil menjual *${Func.formatter(items.count)} ${Func.ucword(items.name)}* (${items.emoji}) dengan total : ${USD.format(Number(items.count * fromItems.price))}`).then(() => {
            users.pocket += Number(items.count * fromItems.price)
            items.count = 0
         })
      } catch (e) {
         client.reply(m.chat, Func.jsonFormat(e), m)
      }
   },
   error: false,
   group: true,
   limit: true,
   game: true,
   cache: true,
   location: __filename
}