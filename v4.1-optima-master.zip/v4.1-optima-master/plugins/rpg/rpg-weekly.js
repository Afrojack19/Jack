const { USD, emoticon } = require('lib/system/rpg-utils')

exports.run = {
   usage: ['weekly'],
   category: 'rpg',
   async: async (m, {
      client,
      players,
      users,
      Func
   }) => {
      try {
         const rewards = {
            exp: Func.randomInt(100, 20 * 7),
            money: Func.randomInt(100, 500 * 7),
            potion: Func.randomInt(1, 20 * 7)
         }
         const cooldown = 604800000
         const timeout = new Date(players.last.weekly + cooldown) - new Date()
         if (new Date - players.last.weekly > cooldown) {
            let p = ''
            for (let reward of Object.keys(rewards)) {
               if (!(reward in players)) continue
               if (/potion/.test(reward)) {
                  players.resource[reward] += rewards[reward]
               } else if (/money/.test(reward)) {
                  users.pocket += rewards[reward]
               } else {
                  players[reward] += rewards[reward]
               }
               p += `${emoticon(reward)} : +${/money/.test(reward) ? USD.format(rewards[reward]) : Func.formatter(rewards[reward])} ${reward}\n`
            }
            m.reply(p.trim()).then(() => players.last.weekly = +new Date())
         } else {
            const fn = Func.readTime(timeout)
            const addZero = i => i < 10 ? '0' + i : i.toString()
            client.reply(m.chat, `❌ Kamu sudah melakukan weekly claim, silahkan tunggu *${fn.days} hari* lagi : *(${addZero(fn.hours)}:${addZero(fn.minutes)}:${addZero(fn.seconds)})*`, m)
         }
      } catch (e) {
         client.reply(m.chat, Func.jsonFormat(e), m)
      }
   },
   error: false,
   group: true,
   game: true,
   cache: true,
   location: __filename
}