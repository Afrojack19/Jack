exports.run = {
   usage: ['fakta', 'galau', 'fml', 'truth', 'dare', 'bucin', 'dilan', 'pantun', 'puisi', 'sad-anime', 'senja', 'sindiran', 'cekkhodam'],
   category: 'random',
   async: async (m, {
      client,
      command,
      Func
   }) => {
      try {
         client.sendReact(m.chat, '🕒', m.key)
         const json = await Api.neoxr(`/${command === 'cekkhodam' ? 'khodam' : command.toLowerCase()}`)
         if (!json.status) return client.reply(m.chat, Func.jsonFormat(json), m)
         let pr = ''
         for (const v in json.data) pr += `◦ *${Func.ucword(v)}* : ${json.data[v]}\n`
         m.reply(pr.trim())
      } catch (e) {
         client.reply(m.chat, Func.jsonFormat(e), m)
      }
   },
   error: false,
   limit: true,
   cache: true,
   location: __filename
}