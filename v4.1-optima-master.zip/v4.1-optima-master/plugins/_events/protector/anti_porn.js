const Sightengine = new (require('lib/sightengine'))

exports.run = {
   async: async (m, {
      client,
      groupSet,
      isAdmin,
      isBotAdmin,
      Func
   }) => {
      try {
         if (!m.fromMe && (!m.isGroup || (m.isGroup && groupSet.antiporn)) && /image/.test(m.mtype)) {
            const image = await Func.getFile(await m.download())
            const isTrue = await Sightengine.isPornImage(image.file)
            if (isTrue) return m.reply(Func.texted('bold', `💀 Prohibited content.`)).then(() => {
               if (!m.isGroup) client.updateBlockStatus(m.sender, 'block')
               if (m.isGroup && !isAdmin && isBotAdmin) return client.sendMessage(m.chat, {
                  delete: {
                     remoteJid: m.chat,
                     fromMe: false,
                     id: m.key.id,
                     participant: m.sender
                  }
               }).then(() => client.groupParticipantsUpdate(m.chat, [m.sender], 'remove'))
            })
         }

         if (!m.fromMe && (!m.isGroup || (m.isGroup && groupSet.antiporn)) && /video/.test(m.mtype) && m?.msg?.seconds <= 60) {
            const video = await Func.getFile(await m.download())
            const isTrue = await Sightengine.isPornVideo(video.file)
            if (isTrue) return m.reply(Func.texted('bold', `💀 Prohibited content`)).then(() => {
               if (!m.isGroup) return client.updateBlockStatus(m.sender, 'block')
               if (m.isGroup && !isAdmin && isBotAdmin) return client.sendMessage(m.chat, {
                  delete: {
                     remoteJid: m.chat,
                     fromMe: false,
                     id: m.key.id,
                     participant: m.sender
                  }
               }).then(() => client.groupParticipantsUpdate(m.chat, [m.sender], 'remove'))
            })
         }
      } catch (e) {}
   },
   error: false,
   cache: true,
   location: __filename
}