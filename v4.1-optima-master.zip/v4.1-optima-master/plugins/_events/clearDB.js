exports.run = {
   async: async (m, {
      client,
      hostJid,
      clientJid,
      findJid,
      env,
      Func
   }) => {
      try {
         let database
         if (hostJid) {
            database = global.db
         } else if (findJid.bot(clientJid)) {
            database = findJid.bot(clientJid).data
         } else {
            database = global.db
         }

         const INACTIVE_THRESHOLD_MS = 3 * 24 * 60 * 60 * 1000 // 3 days
         const now = Date.now()

         if (database.users) {
            database.users = database.users.filter(user => {
               const isRecent = (now - user.lastseen) <= INACTIVE_THRESHOLD_MS
               const isProtected = user.premium || user.banned || user.point >= 1000000
               return isRecent || isProtected
            })
         }

         if (database.chats) {
            database.chats = database.chats.filter(chat => (now - chat.lastseen) <= INACTIVE_THRESHOLD_MS)
         }

         if (database.groups) {
            database.groups = database.groups.filter(group => (now - group.activity) <= INACTIVE_THRESHOLD_MS)
         }

         if (global.db.instance) {
            const pairingJid = `${env.pairing.number}@s.whatsapp.net`
            const registeredBots = global.db.bots?.map(v => v.jid) ?? []
            global.db.instance = global.db.instance.filter(
               inst => inst.jid === pairingJid || registeredBots.includes(inst.jid)
            )
         }

         if (global.db.players) {
            global.db.players = global.db.players.filter(player => 
               'lastseen' in player && (now - player.lastseen) <= INACTIVE_THRESHOLD_MS
            )
         }
      } catch (e) {
         console.error(e)
         client.reply(m.chat, Func.jsonFormat(e), m)
      }
   },
   error: false,
   cache: true,
   location: __filename
}