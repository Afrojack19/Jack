const canvacord = require('canvacord') // have to install canvacord
const fs = require('fs')

exports.run = {
   async: async (m, {
      client,
      users,
      body,
      setting,
      hostJid,
      clientJid,
      findJid,
      env,
      Func,
      Scraper
   }) => {
      try {
         let user = hostJid ? global.db.users : findJid.bot(clientJid) ? findJid.bot(clientJid)?.data?.users : global.db.users
         let levelAwal = Func.level(users.point, env.multiplier)[0]
         if (users && body) users.point += Func.randomInt(1, 100)
         let levelAkhir = Func.level(users.point, env.multiplier)[0]
         if (levelAwal != levelAkhir && setting.levelup) {
            const pic = await client.profilePictureUrl(m.sender, 'image')
            const avatar = pic ? await Func.fetchBuffer(pic) : fs.readFileSync('./media/image/default.jpg')
            const cdn = await Scraper.uploadImageV2(avatar)
            if (!cdn.status) return
            const point = user.sort((a, b) => b.point - a.point).map(v => v.jid)
            const rank = new canvacord.Rank()
               .setRank(point.indexOf(m.sender) + 1)
               .setLevel(Func.level(users.point, env.multiplier)[0])
               .setAvatar(cdn.data.url)
               .setCurrentXP(users.point)
               .setRequiredXP(Func.level(users.point, env.multiplier)[1])
               .setStatus('online')
               .setProgressBar('#FFFFFF', 'COLOR')
               .setUsername(String(m.pushName || 'N/A'))
               .setDiscriminator(Func.randomInt(1000, 9999))
            client.sendFile(m.chat, await rank.build(), 'level.jpg', `乂  *L E V E L - U P*\n\nFrom : [ *${levelAwal}* ] ➠ [ *${levelAkhir}* ]\n*Congratulations!*, you have leveled up 🎉🎉🎉`, m)
         }
      } catch (e) {
         console.log(e)
         return client.reply(m.chat, Func.jsonFormat(e), m)
      }
   },
   error: false,
   group: true,
   cache: true,
   location: __filename
}