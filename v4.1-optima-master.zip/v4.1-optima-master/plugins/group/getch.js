const moment = require('moment-timezone')
exports.run = {
   usage: ['getch'],
   use: 'link',
   category: 'group',
   async: async (m, {
      client,
      args,
      isPrefix,
      command,
      Func
   }) => {
      try {
         if (!args || !args[0]) return m.reply(Func.example(isPrefix, command, 'https://whatsapp.com/channel/0029Va4K0PZ5a245NkngBA2M'))
         const match = args[0].match(/\/channel\/([a-zA-Z0-9]+)/)
         if (!match) return m.reply(global.status.invalid)
         const meta = await client.newsletterMetadata('INVITE', match[1])
         let caption = `乂  *C H A N N E L*\n\n`
         caption += `	◦  *Name* : ${meta.name}\n`
         caption += `	◦  *Subscribers* : ${Func.formatter(meta.subscribers)}\n`
         caption += `	◦  *Status* : ${meta.state}\n`
         caption += `	◦  *Verification* : ${meta.verification}\n`
         caption += `	◦  *Description* : ${meta.description}\n`
         caption += `	◦  *Created* : ${moment(meta.creation_time * 1000).format('DD/MM/YY HH:mm:ss')}`
         const buttons = [{
            name: "cta_copy",
            buttonParamsJson: JSON.stringify({
               display_text: "Copy ID",
               copy_code: meta.id
            })
         }]
         client.sendIAMessage(m.chat, buttons, m, {
            header: '',
            content: caption,
            footer: global.footer,
            media: 'https://pps.whatsapp.net' + meta.preview
         })
      } catch {
         client.reply(m.chat, Func.texted('bold', `🚩 Invalid channel`), m)
      }
   },
   error: false,
   group: true
}