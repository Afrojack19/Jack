const moment = require('moment-timezone')

exports.run = {
   usage: ['reader'],
   category: 'group',
   async: async (m, {
      client,
      ctx,
      Func
   }) => {
      try {
         if (!m.quoted || (m.quoted && !m.quoted.fromMe)) return client.reply(m.chat, Func.texted('bold', `🚩 Reply chat from BOT`), m)
         const msg = await ctx.store.loadMessage(m.chat, m.quoted.id)
         if (!msg) return client.reply(m.chat, Func.texted('bold', `🚩 Message not found.`), m)
         let received = msg.userReceipt.filter(v => v.receiptTimestamp) || []
         let read = msg.userReceipt.filter(v => v.readTimestamp) || []
         if (received.length < 1 && read.length < 1) return client.reply(m.chat, Func.texted('bold', `🚩 Data empty.`), m)

         let text = ''
         if (received.length > 0) {
            text += `📍 Received : *${received.length}*\n`
            for (const v of received) {
               text += `┌ @${v.userJid.replace(/@.+/, '')}\n`
               text += `└ At : ${moment(v.receiptTimestamp * 1000).format('dddd, DD/MM HH:mm')}\n`
            }
         }
         if (read.length > 0) {
            text += '\n'
            text += `📍 Read By : *${read.length}*\n`
            for (const v of read) {
               text += `┌ @${v.userJid.replace(/@.+/, '')}\n`
               text += `└ At : ${moment(v.readTimestamp * 1000).format('dddd, DD/MM HH:mm')}\n`
            }
         }

         m.reply(text?.trim())

      } catch (e) {
         console.log(e)
         client.reply(m.chat, global.status.error, m)
      }
   },
   error: false,
   group: true
}