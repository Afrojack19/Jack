/*
 * This feature only works when the channel activates any emoji reaction. 
 */
exports.run = {
   usage: ['reactch'],
   hidden: ['rch'],
   use: 'link',
   category: 'group',
   async: async (m, {
      client,
      args,
      isPrefix,
      command,
      Func
   }) => {
      try {
         if (!args) return m.reply(Func.example(isPrefix, command, 'https://whatsapp.com/channel/0029Vb5ekjf4dTnMuADBHX1j/122 wow nice'))
         const [url, ...text] = args
         if (!/https:\/\/whatsapp\.com\/channel\/[A-Za-z0-9]+\/[0-9]/.test(url)) return m.reply(global.status.invalid)
         const { id } = await client.newsletterMetadata('INVITE', url.split('/')[4])
         const postId = url.split('/')?.[5]
         if (!id) throw new Error('❌ Channel not found')
         client.sendReact(m.chat, '🕒', m.key)
      
         /**
          * Replaces characters in a given text with their corresponding circled versions.
          * Additionally, spaces are replaced with "―" to maintain a unique formatting style.
          *
          * @param {string} text - The input text to be transformed.
          * @returns {string} - The transformed text with circled characters and modified spaces.
          * 
          * Change font? here : https://www.namecheap.com/visual/font-generator/circled/ 
          */
         const react = (function replaceWithCircledText(text) {
            const normalChars = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
            const circledChars = "ⒶⒷⒸⒹⒺⒻⒼⒽⒾⒿⓀⓁⓂⓃⓄⓅⓆⓇⓈⓉⓊⓋⓌⓍⓎⓏⓐⓑⓒⓓⓔⓕⓖⓗⓘⓙⓚⓛⓜⓝⓞⓟⓠⓡⓢⓣⓤⓥⓦⓧⓨⓩ①②③④⑤⑥⑦⑧⑨⓪"
            return text.split('').map(char => {
               if (char === ' ') return '―'
               const index = normalChars.indexOf(char)
               return index !== -1 ? circledChars[index] : char
            }).join('')
         })(text.join(' '))

         await client.newsletterReactMessage(id, String(postId), react)
         client.reply(m.chat, `✅ Done!`, m)
      } catch (e) {
         console.log(e)
         client.reply(m.chat, Func.texted('bold', `🚩 Invalid channel`), m)
      }
   },
   error: false,
   group: true
}