const { imgbb, imgkub, upload, tmpfiles, bashupload, catbox } = require('@neoxr/helper')
exports.run = {
   usage: ['tourl'],
   use: 'reply file / media',
   category: 'converter',
   async: async (m, {
      client,
      isPrefix,
      command,
      Func,
   }) => {
      try {
         let quoted = m.quoted ? m.quoted : m.msg.viewOnce ? m : null
         if (!quoted) return client.reply(m.chat, Func.texted('bold', `🚩 Give a caption or reply to the photo with the ${isPrefix + command} command`), m)
         let type = quoted.mtype || Object.keys(quoted.message || {})[0]
         let mime = (quoted.msg || quoted).mimetype || ''
         let isImage = /image/.test(type) || /image/.test(mime)
         client.sendReact(m.chat, '🕒', m.key)
         let buffer = quoted.download ? await quoted.download() : await client.downloadMediaMessage(quoted.message[type] || quoted.msg)
         if (!buffer) return client.reply(m.chat, Func.texted('bold', `🚩 Failed download file.`), m)
         const json = await Promise.all([
            tmpfiles(buffer),
            bashupload(buffer),
            // catbox(buffer), <---- Down njir :v
            upload(buffer),
            ...(isImage ? [imgbb(buffer), imgkub(buffer)] : [])
         ])
         const isHasExpiry = url => /neoxr|tmpfiles/.test(url)
         const isSuccess = await json.filter(v => v.status)
         if (!isSuccess.length) return m.reply(Func.texted('bold', `🚩 Upload failed`))
         client.reply(m.chat, isSuccess.map(v => `◦ ${v.data.url} ${isHasExpiry(v.data.url) ? '(Temporary)' : ''}`)?.join('\n')?.trim(), m)
      } catch (e) {
         client.reply(m.chat, Func.jsonFormat(e), m)
      }
   },
   error: false,
   limit: true
}