const { writeFileSync: create, readFileSync: read }= require('fs')
exports.run = {
   usage: ['backup'],
   category: 'operator',
   async: async (m, {
      client,
      database,
      env,
      Func
   }) => {
      try {
         await client.sendReact(m.chat, '🕒', m.key)
         await database.save(global.db)
         create(env.database + '.json', JSON.stringify(global.db, null, 3), 'utf-8')
         await client.sendFile(m.chat, read('./' + env.database + '.json'), env.database + '.json', '', m)
      } catch (e) {
         return client.reply(m.chat, Func.jsonFormat(e), m)
      }
   },
   operator: true,
   cache: true,
   location: __filename
}