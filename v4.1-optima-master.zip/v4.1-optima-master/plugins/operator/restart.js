exports.run = {
   usage: ['restart'],
   category: 'operator',
   async: async (m, {
      client,
      database,
      Func
   }) => {
      await client.reply(m.chat, Func.texted('bold', 'Restarting . . .'), m).then(async () => {
         await database.save(global.db)
         process.send('reset')
      })
   },
   operator: true
}