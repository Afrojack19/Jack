const { Component } = require('@neoxr/wb')
const { Create } = new Component
const express = require('express')
const path = require('path')
const bodyParser = require('body-parser')
const cookie = require('cookie-parser')
const session = require('cookie-session')
const chalk = require('chalk')
const ip = require('request-ip')
const morgan = require('morgan')
const cors = require('cors')
const http = require('http')
const { Server } = require('socket.io')
const middleware = require('./middleware')
const PORT = process.env.PORT || 3000

module.exports = async () => {
   const app = express()
   const server = http.createServer(app)
   const io = new Server(server, {
      path: '/socket.io',
      cors: {
         origin: '*'
      }
   })

   io.on('connection', (socket) => {
      console.log('🟢 Client connected:', socket.id)

      socket.on('ping', (msg) => {
         console.log('📨 Received ping:', msg)
         socket.emit('pong', 'Halo dari server Express + Socket.IO!')
      })

      socket.on('disconnect', () => {
         console.log('🔴 Client disconnected:', socket.id)
      })
   })

   // Express middleware setup
   morgan.token('clientIp', (req) => req.clientIp)
   app.set('json spaces', 3)
      .use(cors({
         origin: '*',
         methods: ['GET', 'POST', 'PUT', 'DELETE'],
         allowedHeaders: '*',
         preflightContinue: false,
         optionsSuccessStatus: 204,
         exposedHeaders: '*',
         credentials: true
      }))
      .use(session({
         name: 'token',
         keys: ['whatsapp'],
         maxAge: 72 * 60 * 60 * 1000, // 3 days
         httpOnly: false,
         sameSite: 'strict'
      }))
      .use(express.json())
      .use(ip.mw())
      .use(morgan(':clientIp :method :url :status :res[content-length] - :response-time ms'))
      .use(bodyParser.json({ limit: '50mb' }))
      .use(bodyParser.urlencoded({
         limit: '50mb',
         extended: true,
         parameterLimit: 50000
      }))
      .use(cookie())
      .use(express.static(path.join(process.cwd(), 'nuxt/.output/public')))
      .use((req, res, next) => {
         req.io = io
         next()
      })

   await (new (Create)(app, middleware)).load(path.join(process.cwd(), 'routers'))

   app.get('*', (req, res) => res.status(404).json({
      creator: global.creator,
      status: false,
      msg: 'The page you are looking for was not found'
   }))

   // Custom header & start server
   app.disable('x-powered-by')
      .use((req, res, next) => {
         res.setHeader('X-Powered-By', 'Neoxr Creative')
         next()
      })

   // Start the server with HTTP server instead of app.listen
   server.listen(PORT, () => {
      console.log(chalk.yellowBright.bold('Server listening on PORT --->', `http://localhost:${PORT}`))
   })
}