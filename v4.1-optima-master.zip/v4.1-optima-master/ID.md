## NEOXR-BOT V4.1 (PREMIUM)

Dokumentasi dan Tutorial dalam bahasa indonesia, silahkan baca dan pahami, jika ada kendala atau ada hal yang tidak dipahami hubungi kreator.

Follow saluran ini untuk notifikasi update. [Update Notification](https://whatsapp.com/channel/0029Vb5ekjf4dTnMuADBHX1j)

### Requirements

- [x] NodeJS >= 20 (Rekomendasi v20.18.1)
- [x] FFMPEG
- [x] Server medukung instalasi Canvas
- [x] Server medukung instalasi Sharp
- [x] Server vCPU/RAM 1/2GB (Min)

### Server

- [x] NAT VPS [Hostdata](https://hostdata.id/nat-vps-usa/)
- [x] Hosting Panel [The Hoster](https://thehoster.net/)
- [x] VPS [OVH Hosting](https://www.ovhcloud.com/asia/vps/)
- [x] RDP Windows [RDP Win](https://www.rdpwin.com/rdpbot.php)

### Cloud Database

- [x] PostgreSQL [Supabase](https://supabase.com/pricing) ~ [Setup Tutorial](https://youtu.be/kdyF7cP9E7k?si=YjlxI5OMHBdkSxkw)
- [x] PostgreSQL [Aiven](https://aiven.io) ~ Hapus ```?sslmode=required```
- [x] MongoDB [MongoDB](https://www.mongodb.com) ~ [Setup Tutorial](https://youtu.be/-9lfyWz0SdE?si=nmyA6qeBYKbO4R45) (Rekomendasi)

> [!NOTE]
> Jika jumlah pengguna / user bot cukup banyak gunakan local db (sqlite) kemudian aktifkan auto bakcup. Cloud database mempunyai batasan saat fetch (karena gratis) dan akan membuat bot delay.

### External Session

**External Session** adalah fitur yang berfungsi untuk menyimpan session bot kedalam database ekternal, terdapat 5 provider yang bisa digunakan, silahkan baca di [https://github.com/neoxr/session](https://github.com/neoxr/session).

Contoh :

Dibawah ini adalah contoh ketika ingin menggunakan 2 provider yaitu mongo dan postgres yang otomatis akan menyesuaikan dengan environment `DATABASE_URL`

```Javascript
const session = process?.env?.DATABASE_URL ? /mongo/.test(process.env.DATABASE_URL)
   ? require('@neoxr/session/mongo').useMongoAuthState
   : /postgres/.test(process.env.DATABASE_URL)
      ? require('@neoxr/session/postgres').usePostgresAuthState
      : null
   : null
```

Bagaimana jika ingin menghemat resource dengan hanya menggunakan 1 provider saja? misal hanya ingin menggunakan mongo maka tambahkan module ini pada `dependencies` yang ada di file `package.json` :

```JSON
{
   "dependencies": {
      "@neoxr/session/mongo": "github:neoxr/session#mongo"
   }
}
```
Dan untuk kode tadi hanya tinggal di sederhanakan menjadi :

```Javascript
const session = process?.env?.DATABASE_URL ? /mongo/.test(process.env.DATABASE_URL)
   ? require('@neoxr/session/mongo').useMongoAuthState
   : null
```

### Database

**Database** adalah fitur yang berfungsi untuk menyimpan data bot kedalam database ekternal atau lokal, terdapat 6 provider yang bisa digunakan, silahkan baca di [https://github.com/neoxr/database](https://github.com/neoxr/database).

Contoh :

```Javascript
const database = await (process?.env?.DATABASE_URL ? /mongo/.test(process.env.DATABASE_URL)
   ? require('@neoxr/database/mongo').createDatabase(process.env.DATABASE_URL, env.database, 'database')
   : /postgres/.test(process.env.DATABASE_URL)
      ? require('@neoxr/database/postgres').createDatabase(process.env.DATABASE_URL, env.database)
      : require('@neoxr/database/local').createDatabase(process.env.DATABASE_URL, env.database)
   : require('@neoxr/database/local').createDatabase(env.database))
```

Bagaimana jika ingin menghemat resource dengan hanya menggunakan 2 provider saja? misal hanya ingin menggunakan mongo dan local maka tambahkan module ini pada `dependencies` yang ada di file `package.json` :

```JSON
{
   "dependencies": {
      "@neoxr/database/local": "github:neoxr/database#local",
      "@neoxr/database/mongo": "github:neoxr/database#mongo"
   }
}
```
Dan untuk kode tadi hanya tinggal di sederhanakan menjadi :

```Javascript
const database = await (process?.env?.DATABASE_URL ? /mongo/.test(process.env.DATABASE_URL)
   ? require('@neoxr/database/mongo').createDatabase(process.env.DATABASE_URL, env.database, 'database')
   : require('@neoxr/database/local').createDatabase(env.database))
```

### Konfigurasi

Ada 3 konfigurasi yang perlu diatur terlebih dahulu sebelum menjalankan bot yaitu pada file `config.json`, `.env` dan `config.js` (opsional).

<details>
  <summary>File : config.json</summary>

  Yang wajib untuk di set adalah `owner`, `owner_name` dan `pairing.number`, selebihnya bisa dibiarkan default saja.

  ```JSON
  {
   "owner": "6285887776722",
   "owner_name": "Wildan Izzudin",
   "database": "data",
   "limit": 10,
   "limit_game": 50,
   "multiplier": 89,
   "min_reward": 100000,
   "max_reward": 500000,
   "ram_limit": "1.5gb",
   "max_upload": 80,
   "max_upload_free": 25,
   "cooldown": 3,
   "timer": 180000,
   "timeout": 1800000,
   "permanent_threshold": 3,
   "notify_threshold": 4,
   "banned_threshold": 5,
   "blocks": ["994", "221", "263"],
   "evaluate_chars":  ["=>", "~>", "<", ">", "$"],
   "pairing": {
      "state": true,
      "number": 62857035017443,
      "browser": ["Ubuntu", "Chrome", "22.04.4"],
      "version": [2, 3000, 1017531287]
   },
   "bot_hosting": {
      "slot": 5,
      "session_dir": "sessions",
      "delay": 1500,
      "interval": 3000,
      "host": "127.0.0.1"
   }
}
  ```
</details>

<details>
  <summary>File : .env</summary>

  Silahkan isi sesuai website yang tertera di atasnya, untuk ```DATABASE_URL``` jika dikosongkan database dan session bot akan disimpan secara lokal ke dalam file json.
  
  ```.env
# Email (Optional)
USER_EMAIL_PROVIDER = 'zoho'
USER_NAME = ''
USER_EMAIL = ''
USER_APP_PASSWORD = ''

# Neoxr API : https://api.neoxr.my.id
API_ENDPOINT = 'https://api.neoxr.my.id/api'
API_KEY = 'your_apikey'

# Database : Mongo / PostgreSql (Optional)
# Leave it empty to use SQLite by default.
DATABASE_URL = ''

# Google API : https://aistudio.google.com
GOOGLE_API = ''

# Prompt System (Choose: "en" or "id")
PROMPT_LANG = 'en'

# Timezone (Important)
TZ = 'Asia/Jakarta'

# Anti Porn : https://api.sightengine.com (Optional)
API_USER = ''
API_SECRET = ''

### Annotations (Optional)
NEWSLETTER_ID = '120363399865638619@newsletter'
### PostID : https://whatsapp.com/channel/0029Vb5ekjf4dTnMuADBHX1j/376 ~> 376
NEWSLETTER_POSTID = 376
NEWSLETTER_NAME = 'NEOXR MUSIC'

### WhatsApp Dashboard (Optional)
DOMAIN = 'https://your-site.com'
PORT = 3001
JWT_SECRET = 'neoxr'
JWT_EXPIRY = '72h'
  ```
</details>

<details>
  <summary>File : config.js</summary>
  Opsional, silahkan buka saja filenya bebas edit tanpa ada aturan tertentu ^_^
</details>

> [!NOTE]
> Keterangan "optional" artinya tidak wajib diisi.

### Instalasi & Verifikasi

Pastikan server sudah sesuai dengan requirement yang sudah disebutkan diatas, lalu jalankan perintah berikut :

```bash
$ yarn install
```

atau

```bash
$ npm i
```

Setelah berhasil terinstall lakukan verifikasi server untuk menggenerate lisensi dengan mengirimkan : 

```bash
$ node .
```

Setelah itu masukkan passcode yang sudah terdaftar dan stop dengan `CTRL+C`, proses ini hanya dilakukan 1x saja jika tidak pindah/ganti server.

### Running

Apabila menjalankan bot di VPS gunakan `pm2` :

```bash
$ npm i -g pm2
```

Gunakan perintah berikut ini untuk mode reguler (tanpa WhatsApp Geteway) :

```bash
$ pm2 start pm2.config.js --only bot && pm2 logs bot
```

atau gunakan mode advance (dengan WhatsApp Geteway) :

```bash
$ pm2 start pm2.config.js --only gateway && pm2 logs gateway
```

Perintah lainnya cek sendiri di halaman pm2 [https://www.npmjs.com/package/pm2](https://www.npmjs.com/package/pm2)


### Apa itu WhatsApp Gateway ?

**WhatsApp Gateway** adalah perantara (interface) yang memungkinkan sistem atau aplikasi lain untuk mengirim dan menerima pesan WhatsApp secara otomatis melalui API (Application Programming Interface). Ini sangat berguna untuk keperluan seperti :

- Notifikasi transaksi (e.g. bukti pembayaran)
- Reminder jadwal
- OTP (One-Time Password)
- dll

> [!NOTE]
> Fitur ini hanya bisa digunakan jika menjalankan bot di VPS dengan melakukan setup web server seperti apache atau nginx.

### Web Interface (Dashboard)

Web Interface bisa kalian pasang atau tidak tergantung jika kalian ingin mengatur database via web silahkan pasang.

<p align="center"><img align="center" width="100%" src="https://qu.ax/SQJDq.png" /></p>

> [!CAUTION]
> Wajib! mempunyai domain dan menjalankan bot di VPS

Untuk konfigurasi dashboard ganti domain di file `./nuxt/nuxt.config.ts` dan di file `.env` beserta `JWT_SECRET` (untuk keamanan)

Setelah itu masuk ke server dimana script bot berada kemudian masuk ke folder nuxt, misal :

```Bash
$ cd v4.1-optima/nuxt
```

Kemudian generate file static untuk dashboardnya :

```Bash
$ yarn && yarn run generate
```

Selesai. Langkah terkahir adalah setup web server seperti Apache/Nginx, tutorial tidak tersedia karena setiap server cara setupnya berbeda beda karena banyak faktor seperti spesifikasi, os, versi os, firewall dll.

Jadi silahkan gunakan AI untuk minta bantuan teknis seputar setup web server menggunakan Apache/Nginx dan sesuaikan dengan spesifikasi server kalian.

> [!INFO]
> Silahkan jalankan `$ bash setup.sh <domain> <port>` mungkin work untuk beberapa server saja.

Apabila semua sudah di lakukan jalankan bot menggunakan pm2 seperti ini 

```Bash
$ pm2 start pm2.config.js --only gateway
```

### Command Plugin

**Command Plugin** adalah plugin yang akan berjalan menggunakan perintah (command).

```Javascript
exports.run = {
   usage: ['ytmp4', 'ytmp3'],
   hidden: ['ytv', 'yta'],
   use: 'link',
   category: 'downloader',
   async: async (m, {
      client,
      args,
      text,
      isPrefix,
      command,
      env,
      Scraper,
      Func
   }) => {
      try {
         // do something
      } catch (e) {
         console.log(e)
         client.reply(m.chat, Func.jsonFormat(e), m)
      }
   },
   error: Boolean,
   limit: Number,
   premium: Boolean,
   restrict: Boolean,
   private: Boolean,
   group: Boolean,
   admin: Boolean,
   botAdmin: Boolean,
   operator: Boolean,
   owner: Boolean,
   moderator: Boolean
}
```

### Event Plugin

**Event Plugin** adalah plugin yang berjalan tanpa command (perintah).

```Javascript
exports.run = {
   async: async (m, {
      client,
      body,
      prefixes
   }) => {
      try {
         // do something
      } catch (e) {
         return client.reply(m.chat, Func.jsonFormat(e), m)
      }
   },
   error: Boolean,
   premium: Boolean,
   private: Boolean,
   group: Boolean,
   admin: Boolean,
   botAdmin: Boolean,
   operator: Boolean,
   owner: Boolean,
   moderator: Boolean
}
```

### Disclaimer & TNC

Dilarang menjual / membagikan script ini kepada orang lain jika itu dilakukan konsekuensi **free update akan dihapus** dan **apikey akan dibanned**.

Tidak menerima request fitur, tapi jika ada saran fitur untuk di tambahkan atau error silahkan buat issue, terima kasih.