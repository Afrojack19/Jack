const v1 = require('./lib/connector/v1')
const v2 = require('./lib/connector/v2')

module.exports = async (jid, client, config) => {
   const { session, database } = config
   if (!session.isExternal) {
      await v1(jid, client, session, database)
   } else {
      await v2(jid, client, session, database)
   }
}