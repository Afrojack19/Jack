require('dotenv').config()
const { Component } = require('@neoxr/wb')
const { Config: env } = new Component()

const db = async () => {
   const database = await (process?.env?.DATABASE_URL ? /mongo/.test(process.env.DATABASE_URL)
      ? require('@database/mongo').createDatabase(process.env.DATABASE_URL, env.database, 'database')
      : /postgres/.test(process.env.DATABASE_URL)
         ? require('@database/postgres').createDatabase(process.env.DATABASE_URL, env.database)
         : require('@database/sqlite').createDatabase(env.database)
      : require('@database/sqlite').createDatabase(env.database))

   const json = await database.fetch()

   console.log(json)
}

module.exports = db