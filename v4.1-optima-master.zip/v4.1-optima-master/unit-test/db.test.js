const mockFetch = jest.fn(() => Promise.resolve({ test: true }))
const mockCreateDatabase = jest.fn(() => Promise.resolve({ fetch: mockFetch }))

jest.mock('@database/mongo', () => ({ createDatabase: mockCreateDatabase }))
jest.mock('@database/postgres', () => ({ createDatabase: mockCreateDatabase }))
jest.mock('@database/sqlite', () => ({ createDatabase: mockCreateDatabase }))

const ORIGINAL_ENV = process.env

beforeEach(() => {
   jest.clearAllMocks()
   process.env = { ...ORIGINAL_ENV }
})

afterAll(() => {
   process.env = ORIGINAL_ENV
})

describe('db function', () => {
   it('should use mongo if DATABASE_URL contains "mongo"', async () => {
      const run = require('./db')
      await run()

      expect(mockCreateDatabase).toHaveBeenCalled()
      expect(mockFetch).toHaveBeenCalled()
   })
})
