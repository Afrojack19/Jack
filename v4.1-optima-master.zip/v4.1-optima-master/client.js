"use strict"
require('./error'), require('events').EventEmitter.defaultMaxListeners = 100
const { Component } = require('@neoxr/wb')
const { Client: Baileys, Connector, Function: Func, Config: env, JID } = new Component
require('./lib/system/scraper'), require('./lib/system/functions'), require('./lib/system/config')
const cron = require('node-cron')
const fs = require('fs')
const colors = require('colors')
const { premiumAndRent, menfessNotifier } = require('./lib/system/scheduler')
const server = require('./server')

const connect = async () => {
   try {
      // Documentation : https://github.com/neoxr/session
      const session = (process?.env?.DATABASE_URL && /mongo/.test(process.env.DATABASE_URL))
         ? require('@session/mongo').useMongoAuthState
         : (process?.env?.DATABASE_URL && /postgres/.test(process.env.DATABASE_URL))
            ? require('@session/postgres').usePostgresAuthState
            : null

      // Documentation : https://github.com/neoxr/database
      const database = await (process?.env?.DATABASE_URL ? /mongo/.test(process.env.DATABASE_URL)
         ? require('@database/mongo').createDatabase(process.env.DATABASE_URL, env.database, 'database')
         : /postgres/.test(process.env.DATABASE_URL)
            ? require('@database/postgres').createDatabase(process.env.DATABASE_URL, env.database)
            : require('@database/sqlite').createDatabase(env.database)
         : require('@database/sqlite').createDatabase(env.database))

      /* bot hosting options */
      const options = {
         session: {
            execute: session ? session : env.bot_hosting.session_dir,
            config: process.env.DATABASE_URL,
            isExternal: session instanceof Function
         },
         database,
         batch: env.bot_hosting.bacth,
         delay: env.bot_hosting.delay,
         interval: env.bot_hosting.interval
      }

      const client = new Baileys({
         type: '--neoxr-v1',
         plugsdir: 'plugins',
         session: session ? session(process.env.DATABASE_URL, 'session') : 'session',
         online: true,
         bypass_disappearing: true,
         bot: Func.isBot,
         server: process.argv.includes('--server'),
         code: env.pairing.code || '',
         version: env.pairing.version
      }, {
         ...(env.pairing?.browser ? { browser: env.pairing.browser } : {}),
         shouldIgnoreJid: jid => {
            return /(newsletter|bot)/.test(jid)
         }
      })

      /* print error */
      client.once('error', async error => {
         console.error(colors.red(error.message))
         if (error && typeof error === 'object' && error.message) Func.logFile(error.message)
      })

      /* starting to connect */
      client.once('connect', async res => {
         /* load database */
         global.db = { users: [], chats: [], players: [], groups: [], statistic: {}, sticker: {}, setting: {}, setup: {}, bots: [], instance: [], anon: {}, menfess: [], ...(await database.fetch() || {}) }
         /* reset all connect bots */
         if (global.db.bots.length > 0) {
            for (let v of global.db.bots) {
               v.is_connected = false
            }
         }
         /* save database */
         await database.save(global.db)
         /* write connection log */
         if (res && typeof res === 'object' && res.message) Func.logFile(res.message)
      })

      /* bot is connected */
      client.once('ready', async () => {
         /* web server intialization */
         if (process.argv.includes('--server')) {
            env.bot_hosting.server = true
            const isOn = await Func.isPortInUse(env.bot_hosting.host)
            if (!isOn) server(client.sock).catch(() => server(client.sock))
         }

         /* auto restart if ram usage is over */
         const ramCheck = setInterval(() => {
            var ramUsage = process.memoryUsage().rss
            if (ramUsage >= require('bytes')(env.ram_limit)) {
               clearInterval(ramCheck)
               process.send('reset')
            }
         }, 60 * 1000)

         /* create temp directory if doesn't exists */
         if (!fs.existsSync('./temp')) fs.mkdirSync('./temp')

         /* clear temp folder and session every 10 minutes */
         setInterval(async () => {
            try {
               const tmpFiles = fs.readdirSync('./temp')
               if (tmpFiles.length > 0) {
                  tmpFiles.filter(v => !v.endsWith('.file')).map(v => fs.unlinkSync('./temp/' + v))
               }
            } catch { }
         }, 60 * 1000 * 10)

         /* save database every 1 minutes */
         setInterval(async () => {
            if (global.db) await database.save(global.db)
         }, 60_000)

         /* backup database every day at 12:00 PM (send .json file to owner) */
         cron.schedule('0 12 * * *', async () => {
            if (global?.db?.setting?.autobackup) {
               await database.save(global.db)
               fs.writeFileSync(env.database + '.json', JSON.stringify(global.db, null, 3), 'utf-8')
               await client.sock.sendFile(env.owner + '@s.whatsapp.net', fs.readFileSync('./' + env.database + '.json'), env.database + '.json', '', null)
            }
         })

         /* premium and rent notifier */
         setInterval(async () => {
            if (global.db) {
               await menfessNotifier(client.sock, Func)
               await premiumAndRent(client.sock, {
                  ...JID(client.sock)
               }, Func)
            }
         }, 60 * 1000 * 30) // check every 30 minutes

         /* auto connect bot (jadibot) */
         const license = fs.existsSync('./license.json') ? JSON.parse(fs.readFileSync('./license.json')) : {}
         if (Object.keys(license)?.length) new Connector('connector', client.sock, options)
      })

      /* listener wrapper */
      require('./lib/system/listener-wrapper')(client, database, options)
   } catch {}
}

connect().catch(() => connect())