exports.routes = {
   category: 'data',
   path: '/data/chats',
   method: 'get',
   execution: async (req, res, next) => {
      try {
         const { jid, type } = req.session
         let data

         if (type === 1) {
            data = global?.db?.chats || []
         } else if (type === 2) {
            const bot = global?.db?.bots?.find(v =>
               v.jid === jid || v.sender === jid
            )
            if (!bot) {
               return res.status(404).json({
                  creator: global.creator,
                  status: false,
                  message: 'Bot not found'
               })
            }

            data = bot?.data?.chats || []
         }

         res.json({
            creator: global.creator,
            status: true,
            data: {
               stats: {
                  personal: (data.filter(v => v.jid.endsWith('.net')) || [])?.length,
                  group: (data.filter(v => v.jid.endsWith('g.us')) || [])?.length,
                  total: data.length
               },
               chats: data?.sort((a, b) => (b.lastseen || b.lastchat || 0) - (a.lastseen || a.lastchat || 0))
            }
         })
      } catch (e) {
         res.status(500).json({
            creator: global.creator,
            status: false,
            message: e.message
         })
      }
   },
   error: false,
   login: true
}
