exports.routes = {
   category: 'main',
   path: '/data/all',
   method: 'get',
   execution: async (req, res, next) => {
      try {
         const { jid, type } = req.session
         let users, chats, groups, bots

         if (type === 1) {
            users = global?.db?.users || []
            chats = global?.db?.chats || []
            groups = global?.db?.groups || []
            bots = global?.db?.bots || []
         } else if (type === 2) {
            const bot = global?.db?.bots?.find(v =>
               v.jid === jid || v.sender === jid
            )
            if (!bot) {
               return res.status(404).json({
                  creator: global.creator,
                  status: false,
                  message: 'Bot not found'
               })
            }

            users = bot.data.users || []
            chats = bot.data.chats || []
            groups = bot.data.groups || []
            bots = []
         }

         res.json({
            creator: global.creator,
            status: true,
            data: {
               users: {
                  premium: (users?.filter(v => v.premium) || [])?.length || 0,
                  banned: (users?.filter(v => v.banned) || [])?.length || 0,
                  total: users?.length || 0
               },
               groups: {
                  rental: (groups?.filter(v => v.expired > 1) || [])?.length || 0,
                  total: groups?.length || 0
               },
               chats: {
                  total: chats?.length || 0
               },
               bots: {
                  connected: (bots?.filter(v => v.is_connected) || [])?.length || 0,
                  disconnected: (bots?.filter(v => !v.is_connected) || [])?.length || 0,
                  total: bots?.length || 0
               }
            }
         })
      } catch (e) {
         res.status(500).json({
            creator: global.creator,
            status: false,
            message: e.message
         })
      }
   },
   error: false,
   login: true
}
