exports.routes = {
   category: 'data',
   path: '/data/users',
   method: 'get',
   execution: async (req, res, next) => {
      try {
         const { jid, type } = req.session
         let data

         if (type === 1) {
            data = global?.db?.users || []
         } else if (type === 2) {
            const bot = global?.db?.bots?.find(v =>
               v.jid === jid || v.sender === jid
            )
            if (!bot) {
               return res.status(404).json({
                  creator: global.creator,
                  status: false,
                  message: 'Bot not found'
               })
            }

            data = bot?.data?.users || []
         }

         res.json({
            creator: global.creator,
            status: true,
            data: {
               stats: {
                  banned: (data.filter(v => v.banned) || [])?.length,
                  premium: (data.filter(v => v.premium) || [])?.length,
                  total: data.length
               },
               users: data.sort((a, b) => b.usebot - a.usebot)
            }
         })
      } catch (e) {
         res.status(500).json({
            creator: global.creator,
            status: false,
            message: e.message
         })
      }
   },
   error: false,
   login: true
}
