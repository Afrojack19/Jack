const { Component } = require('@neoxr/wb')
const { Instance, Config: env } = new Component

exports.routes = {
   category: 'data',
   path: '/data/token-auth',
   method: 'get',
   execution: async (req, res, next) => {
      try {
         const { jid, type } = req.session
         const mainJid = `${env.pairing.number}@s.whatsapp.net`
         let instanceJid

         if (type === 2) {
            const bot = global?.db?.bots?.find(v =>
               v.jid === jid || v.sender === jid
            )
            if (!bot)
               return res.status(404).json({
                  creator: global.creator,
                  status: false,
                  message: 'Bot not found'
               })

            instanceJid = bot.jid
         }

         const instance = type === 1 ? Instance.getData(mainJid) : Instance.getData(instanceJid)
         if (!instance)
            return res.status(404).json({
               creator: global.creator,
               status: false,
               message: 'Instance not found'
            })

         res.json({
            creator: global.creator,
            status: true,
            data: {
               token: instance.hash
            }
         })
      } catch (e) {
         res.status(500).json({
            creator: global.creator,
            status: false,
            message: e.message
         })
      }
   },
   error: false,
   login: true
}
