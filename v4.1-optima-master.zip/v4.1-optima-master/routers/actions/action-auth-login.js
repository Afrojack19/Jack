const { Component } = require('@neoxr/wb')
const { Instance, Config: env, Function: Func } = new Component
const jwt = require('jsonwebtoken')

exports.routes = {
   category: 'action',
   path: '/action/login',
   method: 'post',
   parameter: ['type'],
   execution: async (req, res, next) => {
      try {
         const { type, username, password, token } = req.body
         const operatorJid = `${env.owner}@s.whatsapp.net`
         const mainJid = `${env.pairing.number}@s.whatsapp.net`
         let instanceJid

         if (!type || (type !== 1 && type !== 2))
            return res.status(400).json({
               creator: global.creator,
               status: false,
               message: 'Invalid login type'
            })

         if (type === 1) {
            if (!username || !password)
               return res.status(400).json({
                  creator: global.creator,
                  status: false,
                  message: 'Username and password can\'t leave empty'
               })

            const creds = global.db.setup
            if (creds?.username !== username || creds?.password != password)
               return res.status(400).json({
                  creator: global.creator,
                  status: false,
                  message: 'Invalid username or password'
               })
         }

         if (type === 2) {
            if (!token)
               return res.status(400).json({
                  creator: global.creator,
                  status: false,
                  message: 'Token can\'t leave empty'
               })
         }

         const instance = type === 1 ? Instance.getData(mainJid) : Instance.getDataByHash(token)
         if (!instance)
            return res.status(404).json({
               creator: global.creator,
               status: false,
               message: 'Bot not found'
            })

         if (type === 2) {
            if (instance.jid === mainJid)
               return res.status(403).json({
                  creator: global.creator,
                  status: false,
                  message: 'You are the main bot account. Please login using your username and password.'
               })

            instanceJid = global?.db?.bots?.find(v =>
               v.jid === instance.jid
            )
         }

         if (type === 2 && !instanceJid?.sender)
            return res.status(404).json({
               creator: global.creator,
               status: false,
               message: 'Account not found'
            })

         const client = Instance.getBotByHash(instance.hash)
         if (!client)
            return res.status(404).json({
               creator: global.creator,
               status: false,
               message: 'Bot not found'
            })

         const jid = type === 1 ? operatorJid : instanceJid.sender
         const profilePicture = await client.profilePictureUrl(jid, 'image')
         const imageUrl = profilePicture || 'https://qu.ax/mnUAl.jpg'
         const jwtToken = jwt.sign({ jid, type, username, password, hash: token }, process.env.JWT_SECRET, { expiresIn: process.env.JWT_EXPIRY })
         req.session.login = true
         req.session.type = type
         req.session.jid = jid
         req.session.token = jwtToken
         res.json({
            creator: global.creator,
            status: true,
            data: {
               avatar: imageUrl,
               token: jwtToken,
               type,
               created_at: Date.now(),
               expired_at: Func.toMs(process.env.JWT_EXPIRY)
            }
         })
      } catch (e) {
         res.status(500).json({
            creator: global.creator,
            status: false,
            message: e.message
         })
      }
   },
   error: false
}