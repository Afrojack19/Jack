const { Component } = require('@neoxr/wb')
const { Instance, Config: env } = new Component
const multer = require('multer')
const upload = multer()

const getMentions = async (client, jid) => {
   try {
      const metadata = await client.groupMetadata(jid)
      if (!metadata || !metadata.participants) return []
      return metadata.participants.map(p => p.id)
   } catch (e) {
      console.error('Failed to get group metadata for hidetag:', e)
      return []
   }
}

exports.routes = {
   category: 'action',
   path: '/action/group-message',
   method: 'post',
   middleware: [upload.single('file')],
   execution: async (req, res, next) => {
      try {
         const { jid: groupId, type, message, caption, hidetag } = req.body
         const file = req.file

         const { type: sessionType, jid: sessionJid } = req.session
         const mainJid = `${env.pairing.number}@s.whatsapp.net`

         let client

         if (sessionType === 1) {
            client = Instance.getBot(mainJid)
         } else if (sessionType === 2) {
            const bot = global?.db?.bots?.find(v =>
               v.jid === sessionJid || v.sender === sessionJid
            )
            if (!bot) {
               return res.status(404).json({
                  creator: global.creator,
                  status: false,
                  message: 'Bot not found for your session'
               })
            }

            if (!Instance.getBot(bot.jid))
               return res.status(404).json({
                  creator: global.creator,
                  status: false,
                  message: 'Instance data for your bot not found'
               })

            client = Instance.getBot(bot.jid)
         }

         if (!client) {
            return res.status(400).json({
               creator: global.creator,
               status: false,
               message: 'Could not determine a client instance'
            })
         }

         const enableHidetag = hidetag === 'true'
         const mentions = enableHidetag ? await getMentions(client, groupId) : []
         const watermark = `This message was sent via ${req.protocol}s://${req.get('Host')}`

         switch (type) {
            case 'text':
               await client.reply(groupId, (message + '\n\n> ' + watermark)?.trim(), null, {
                  mentions: mentions
               })
               break

            case 'media':
               await client.sendFile(groupId, file.buffer, file.originalname, (caption + '\n\n> ' + watermark)?.trim(), null, {
                  document: false,
               }, { mentions })
               break

            case 'file':
               await client.sendFile(groupId, file.buffer, file.originalname, (caption + '\n\n> ' + watermark)?.trim(), null, {
                  document: true,
               }, { mentions })
               break

            case 'voice':
               await client.sendFile(groupId, file.buffer, file.originalname, '', null, {
                  ptt: true,
               }, { mentions })
               break

            default:
               return res.status(400).json({
                  creator: global.creator,
                  status: false,
                  message: 'Invalid message type provided'
               })
         }

         res.json({
            creator: global.creator,
            status: true,
            message: 'Message sent successfully!'
         })
      } catch (e) {
         console.error(e)
         res.status(500).json({
            creator: global.creator,
            status: false,
            message: e.message
         })
      }
   },
   error: false,
   login: true
}