exports.routes = {
   category: 'action',
   path: '/action/update-setting',
   method: 'post',
   parameter: ['data'],
   execution: async (req, res, next) => {
      try {
         const { data: newSettings } = req.body

         if (!newSettings || typeof newSettings !== 'object') {
            return res.status(400).json({
               creator: global.creator,
               status: false,
               message: 'Invalid settings data provided'
            })
         }

         const { jid, type } = req.session
         let setting

         if (type === 1) {
            if (!global.db.setting) global.db.setting = {}
            setting = global.db.setting
         } else if (type === 2) {
            const bot = global?.db?.bots?.find(v =>
               v.jid === jid || v.sender === jid
            )
            if (!bot) {
               return res.status(404).json({
                  creator: global.creator,
                  status: false,
                  message: 'Bot not found'
               })
            }
            setting = bot?.data?.setting || {}
         }

         if (!setting) {
            return res.status(404).json({
               creator: global.creator,
               status: false,
               message: 'Target settings object not found'
            })
         }

         for (const key in newSettings) {
            if (Object.prototype.hasOwnProperty.call(setting, key)) {
               setting[key] = newSettings[key]
            }
         }

         res.json({
            creator: global.creator,
            status: true,
            message: 'Settings updated successfully'
         })
      } catch (e) {
         console.error(e)
         res.status(500).json({
            creator: global.creator,
            status: false,
            message: e.message
         })
      }
   },
   error: false,
   login: true
}