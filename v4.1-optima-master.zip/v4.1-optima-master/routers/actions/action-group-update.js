exports.routes = {
   category: 'action',
   path: '/action/update-group',
   method: 'post',
   parameter: ['jid'],
   execution: async (req, res, next) => {
      try {
         const { jid: id, ...settings } = req.body
         const { type, jid } = req.session

         let target

         if (type === 1) {
            target = global.db.groups?.find(v => v.jid === id)
            if (!target) {
               return res.status(404).json({
                  creator: global.creator,
                  status: false,
                  message: 'Group not found in the global database'
               })
            }
         } else if (type === 2) {
            const bot = global.db.bots?.find(v => 
               v.jid === jid || v.sender === jid
            )
            if (!bot) {
               return res.status(404).json({
                  creator: global.creator,
                  status: false,
                  message: 'Bot session not found'
               })
            }

            target = bot.data.groups?.find(v => v.jid === id)
            if (!target) {
               return res.status(404).json({
                  creator: global.creator,
                  status: false,
                  message: 'Group not found in this bot session'
               })
            }
         }

         if (target) {
            for (const key in settings) {
               if (Object.hasOwnProperty.call(target, key)) {
                  target[key] = settings[key]
               }
            }

            return res.json({
               creator: global.creator,
               status: true,
               message: 'Group settings updated successfully'
            })
         }

         return res.status(400).json({
            creator: global.creator,
            status: false,
            message: 'Invalid payload'
         })
      } catch (e) {
         console.error(e)
         res.status(500).json({
            creator: global.creator,
            status: false,
            message: e.message
         })
      }
   },
   error: false,
   login: true
}