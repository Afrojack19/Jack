const { Component } = require('@neoxr/wb')
const { Instance, Function: Func } = new Component

exports.routes = {
   category: 'action',
   path: '/action/terminate',
   method: 'post',
   parameter: ['id'],
   execution: async (req, res, next) => {
      try {
         const { id } = req.body

         const bot = global?.db?.bots?.find(v => v._id === id)
         if (!bot)
            return res.status(404).json({
               creator: global.creator,
               status: false,
               message: 'Bot not found'
            })

         const client = Instance.getBot(bot.jid)
         if (!client)
            return res.status(404).json({
               creator: global.creator,
               status: false,
               message: 'Bot not found'
            })

         Func.removeItem(global.db.bots, bot)
         await client.logout()
         return res.json({
            creator: global.creator,
            status: true,
            message: 'Bot terminated successfully'
         })
      } catch (e) {
         res.status(500).json({
            creator: global.creator,
            status: false,
            message: e.message
         })
      }
   },
   error: false,
   login: '401-operator'
}