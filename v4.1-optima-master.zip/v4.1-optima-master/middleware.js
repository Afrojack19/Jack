const { Component } = require('@neoxr/wb')
const { AllowedIPs, ReqUtils, Instance, Config: env } = new Component
const requestIp = require('request-ip')
const jwt = require('jsonwebtoken')

const requestLimit = Number(process.env.REQUEST_LIMIT || 100)
const ipRequests = {}

module.exports = (route) => {
   const middlewares = []

   // Restrict IP
   if (route.restrict) {
      middlewares.push((req, res, next) => {
         const userIP = requestIp.getClientIp(req) || ''
         if (!AllowedIPs.includes(userIP)) {
            return res.status(403).json({
               creator: global.creator,
               status: false,
               msg: 'Your IP is not allowed to access this page'
            })
         }
         next()
      })
   }

   // Rate Limit per Minute
   if (route.rpm) {
      middlewares.push((req, res, next) => {
         const userIP = requestIp.getClientIp(req) || ''
         const currentTime = Date.now()

         if (!ipRequests[userIP]) {
            ipRequests[userIP] = []
         }

         ipRequests[userIP] = ipRequests[userIP].filter(ts => currentTime - ts < 60000)

         if (ipRequests[userIP].length >= requestLimit) {
            return res.status(429).json({
               creator: global.creator,
               status: false,
               msg: 'Too many requests. Please try again later.'
            })
         }

         ipRequests[userIP].push(currentTime)
         next()
      })
   }

   // Error Middleware
   if (route.error) {
      middlewares.push((req, res) => {
         return res.json({
            creator: global.creator,
            status: false,
            msg: 'Sorry, this feature is currently error and will be fixed soon'
         })
      })
   }

   // Login Middleware
   if (route.login) {
      middlewares.push(async (req, res, next) => {
         try {
            const authorization = req.headers['authorization']
            const token = authorization?.split(' ')?.[1]?.trim()
            const operator = `${env.owner}@s.whatsapp.net`

            if (!token) {
               return res.status(401).json({
                  creator: global.creator,
                  status: false,
                  msg: 'Authentication credentials are required'
               })
            }

            let payload
            try {
               payload = jwt.verify(token, process.env.JWT_SECRET)
            } catch (err) {
               return res.status(401).json({
                  creator: global.creator,
                  status: false,
                  msg: 'Unauthorized: Invalid or expired token'
               })
            }

            const { jid, type, hash } = payload
            const isAdmin = (jid === operator)

            if (!type || (type !== 1 && type !== 2)) {
               return res.status(401).json({
                  creator: global.creator,
                  status: false,
                  msg: 'Unauthorized: Invalid session type'
               })
            }

            if (!isAdmin && !Instance.getBotByHash(hash)) {
               return res.status(401).json({
                  creator: global.creator,
                  status: false,
                  msg: 'Unauthorized: Invalid or expired session'
               })
            }

            if (route.login === '401-operator' && !isAdmin) {
               return res.status(403).json({
                  creator: global.creator,
                  status: false,
                  msg: 'Forbidden: You must be an admin to access this resource'
               })
            }

            if (route.login === '301-operator' && !isAdmin) {
               return res.redirect('/auth/login')
            }

            next()
         } catch (err) {
            console.error('Authentication Middleware Error:', err)
            res.status(500).json({
               creator: global.creator,
               status: false,
               msg: 'Internal Server Error'
            })
         }
      })
   }

   // Parameter Validation
   if (!route.requires) {
      middlewares.push((req, res, next) => {
         const reqFn = route.method === 'get' ? 'reqGet' : 'reqPost'
         const check = ReqUtils[reqFn](req, route.parameter ?? [])
         if (!check.status) return res.status(400).json(check)

         const reqType = route.method === 'get' ? 'query' : 'body'
         if ('url' in req[reqType]) {
            const isUrl = ReqUtils.url(req[reqType].url)
            if (!isUrl.status) return res.status(400).json(isUrl)
         }

         next()
      })
   } else {
      middlewares.push(route.requires)
   }

   // Custom Validator (optional)
   middlewares.push(route.validator || ((req, _res, next) => next()))

   return middlewares
}